import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/ThemeProvider";
import { ClientProviders } from "@/components/ClientProviders";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "SpinWin - Spin, Earn, Withdraw Real Cash!",
  description: "Pakistan's most trusted points-earning platform. Spin the wheel, complete tasks, refer friends, and withdraw real cash via Easypaisa, JazzCash, or Bank Transfer.",
  keywords: ["SpinWin", "earn money", "Easypaisa", "JazzCash", "Pakistan", "spin wheel", "rewards", "points"],
  authors: [{ name: "SpinWin Team" }],
  openGraph: {
    title: "SpinWin - Earn Real Cash",
    description: "Spin the wheel, earn points, withdraw real cash!",
    siteName: "SpinWin",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem
          disableTransitionOnChange
        >
          <ClientProviders>
            {children}
          </ClientProviders>
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
