'use client';

import { useEffect } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { AuthScreen } from '@/components/spinwin/AuthScreen';
import { Header } from '@/components/spinwin/Header';
import { BottomNav } from '@/components/spinwin/BottomNav';
import { HomeView } from '@/components/spinwin/HomeView';
import { SpinView } from '@/components/spinwin/SpinView';
import { WalletView } from '@/components/spinwin/WalletView';
import { TasksView } from '@/components/spinwin/TasksView';
import { ProfileView } from '@/components/spinwin/ProfileView';
import { ReferralView } from '@/components/spinwin/ReferralView';
import { AchievementsView } from '@/components/spinwin/AchievementsView';
import { LeaderboardView } from '@/components/spinwin/LeaderboardView';
import { AdminView } from '@/components/spinwin/AdminView';
import { Loader2 } from 'lucide-react';

export default function HomePage() {
  const { 
    isAuthenticated, 
    isLoading, 
    fetchUser, 
    currentView 
  } = useAppStore();
  
  useEffect(() => {
    fetchUser();
  }, [fetchUser]);
  
  // Loading state
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-emerald-50 to-amber-50">
        <div className="text-center">
          <Loader2 className="h-12 w-12 animate-spin text-emerald-600 mx-auto mb-4" />
          <p className="text-muted-foreground">Loading SpinWin...</p>
        </div>
      </div>
    );
  }
  
  // Auth screen if not logged in
  if (!isAuthenticated) {
    return <AuthScreen />;
  }
  
  // Main app
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      
      <main className="flex-1 p-4 pb-24 overflow-y-auto">
        {currentView === 'home' && <HomeView />}
        {currentView === 'spin' && <SpinView />}
        {currentView === 'wallet' && <WalletView />}
        {currentView === 'tasks' && <TasksView />}
        {currentView === 'profile' && <ProfileView />}
        {currentView === 'referral' && <ReferralView />}
        {currentView === 'achievements' && <AchievementsView />}
        {currentView === 'leaderboard' && <LeaderboardView />}
        {currentView === 'admin' && <AdminView />}
      </main>
      
      <BottomNav />
    </div>
  );
}
