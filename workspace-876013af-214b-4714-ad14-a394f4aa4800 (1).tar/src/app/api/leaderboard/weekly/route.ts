
import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { db } from '@/lib/db';

// Level names for display
const LEVEL_NAMES: Record<number, string> = {
  0: 'Bronze',
  1: 'Silver',
  2: 'Gold',
  3: 'Platinum',
  4: 'Diamond',
  5: 'Master',
  6: 'Legend',
  7: 'Grandmaster',
};

/**
 * GET /api/leaderboard/weekly
 * Get top 50 weekly earners
 * Returns: ranked list of top earners for current week
 */
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser(request);

    // Calculate week start (Monday PKT midnight)
    const now = new Date();
    const pktOffset = 5 * 60 * 60 * 1000; // PKT is UTC+5
    const pktTime = new Date(now.getTime() + pktOffset);
    pktTime.setUTCHours(0, 0, 0, 0);
    const todayMidnightPKT = new Date(pktTime.getTime() - pktOffset);

    // Get start of current week (Monday)
    const weekStart = new Date(todayMidnightPKT);
    const dayOfWeek = weekStart.getUTCDay();
    const daysToMonday = dayOfWeek === 0 ? 6 : dayOfWeek - 1;
    weekStart.setUTCDate(weekStart.getUTCDate() - daysToMonday);

    // Get weekly earnings per user from transactions
    const weeklyEarnings = await db.transaction.groupBy({
      by: ['userId'],
      where: {
        createdAt: {
          gte: weekStart,
        },
        points: {
          gt: 0, // Only positive points (earnings)
        },
        status: 'completed',
      },
      _sum: {
        points: true,
      },
      _count: {
        id: true,
      },
      orderBy: {
        _sum: {
          points: 'desc',
        },
      },
      take: 50,
    });

    // Get user details for top earners
    const userIds = weeklyEarnings.map(e => e.userId);
    const users = await db.user.findMany({
      where: {
        id: {
          in: userIds,
        },
      },
      select: {
        id: true,
        name: true,
        level: true,
        pointsBalance: true,
      },
    });

    // Create user map
    const userMap = new Map(users.map(u => [u.id, u]));

    // Format leaderboard
    const leaderboard = weeklyEarnings.map((entry, index) => {
      const userData = userMap.get(entry.userId);
      return {
        rank: index + 1,
        userId: entry.userId,
        name: userData?.name || 'Anonymous',
        level: userData?.level || 0,
        levelName: LEVEL_NAMES[userData?.level || 0] || 'Bronze',
        weeklyPoints: entry._sum.points || 0,
        transactions: entry._count.id,
        totalPoints: userData?.pointsBalance || 0,
        isCurrentUser: user?.id === entry.userId,
      };
    });

    // Calculate week info
    const weekEnd = new Date(weekStart);
    weekEnd.setUTCDate(weekEnd.getUTCDate() + 7);
    const weekProgress = Math.round(((now.getTime() - weekStart.getTime()) / (weekEnd.getTime() - weekStart.getTime())) * 100);

    return NextResponse.json({
      success: true,
      data: {
        leaderboard,
        weekInfo: {
          startDate: weekStart.toISOString(),
          endDate: weekEnd.toISOString(),
          progress: Math.min(100, Math.max(0, weekProgress)),
          daysRemaining: Math.ceil((weekEnd.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)),
        },
        totalParticipants: weeklyEarnings.length,
        currentUserId: user?.id || null,
      },
    });
  } catch (error) {
    console.error('Get weekly leaderboard error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to get leaderboard' },
      { status: 500 }
    );
  }
}
