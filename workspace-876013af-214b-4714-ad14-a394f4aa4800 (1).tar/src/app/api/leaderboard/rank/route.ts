
import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { db } from '@/lib/db';

/**
 * GET /api/leaderboard/rank
 * Get current user's rank in the weekly leaderboard
 * Returns: rank, weeklyPoints, nearby competitors, percentile
 */
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser(request);

    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Calculate week start (Monday PKT midnight)
    const now = new Date();
    const pktOffset = 5 * 60 * 60 * 1000; // PKT is UTC+5
    const pktTime = new Date(now.getTime() + pktOffset);
    pktTime.setUTCHours(0, 0, 0, 0);
    const todayMidnightPKT = new Date(pktTime.getTime() - pktOffset);

    // Get start of current week (Monday)
    const weekStart = new Date(todayMidnightPKT);
    const dayOfWeek = weekStart.getUTCDay();
    const daysToMonday = dayOfWeek === 0 ? 6 : dayOfWeek - 1;
    weekStart.setUTCDate(weekStart.getUTCDate() - daysToMonday);

    // Get all weekly earnings to calculate rank
    const allWeeklyEarnings = await db.transaction.groupBy({
      by: ['userId'],
      where: {
        createdAt: {
          gte: weekStart,
        },
        points: {
          gt: 0,
        },
        status: 'completed',
      },
      _sum: {
        points: true,
      },
      orderBy: {
        _sum: {
          points: 'desc',
        },
      },
    });

    // Find user's rank
    const userRankIndex = allWeeklyEarnings.findIndex(e => e.userId === user.id);
    const rank = userRankIndex !== -1 ? userRankIndex + 1 : null;
    const userWeeklyPoints = userRankIndex !== -1 
      ? allWeeklyEarnings[userRankIndex]._sum.points || 0 
      : 0;

    // Get nearby competitors (2 above and 2 below)
    const nearbyUserIds: string[] = [];
    const nearbyStart = Math.max(0, (userRankIndex || 0) - 2);
    const nearbyEnd = Math.min(allWeeklyEarnings.length, (userRankIndex || 0) + 3);

    for (let i = nearbyStart; i < nearbyEnd; i++) {
      if (allWeeklyEarnings[i]) {
        nearbyUserIds.push(allWeeklyEarnings[i].userId);
      }
    }

    const nearbyUsers = await db.user.findMany({
      where: {
        id: {
          in: nearbyUserIds,
        },
      },
      select: {
        id: true,
        name: true,
        level: true,
      },
    });

    const userMap = new Map(nearbyUsers.map(u => [u.id, u]));

    // Build nearby competitors list
    const nearbyCompetitors = [];
    for (let i = nearbyStart; i < nearbyEnd; i++) {
      const entry = allWeeklyEarnings[i];
      if (entry) {
        const userData = userMap.get(entry.userId);
        nearbyCompetitors.push({
          rank: i + 1,
          userId: entry.userId,
          name: userData?.name || 'Anonymous',
          level: userData?.level || 0,
          weeklyPoints: entry._sum.points || 0,
          isCurrentUser: entry.userId === user.id,
          pointsBehind: userRankIndex !== -1 && i > userRankIndex 
            ? userWeeklyPoints - (entry._sum.points || 0)
            : null,
          pointsAhead: userRankIndex !== -1 && i < userRankIndex
            ? (entry._sum.points || 0) - userWeeklyPoints
            : null,
        });
      }
    }

    // Calculate percentile
    const totalParticipants = allWeeklyEarnings.length;
    const percentile = rank 
      ? Math.round(((totalParticipants - rank) / totalParticipants) * 100) 
      : 0;

    // Get points to next rank
    let pointsToNextRank = null;
    let nextRankUser = null;
    
    if (userRankIndex !== null && userRankIndex > 0) {
      const nextRankEntry = allWeeklyEarnings[userRankIndex - 1];
      if (nextRankEntry) {
        pointsToNextRank = (nextRankEntry._sum.points || 0) - userWeeklyPoints;
        const nextUserData = await db.user.findUnique({
          where: { id: nextRankEntry.userId },
          select: { name: true },
        });
        nextRankUser = nextUserData?.name || 'Anonymous';
      }
    }

    return NextResponse.json({
      success: true,
      data: {
        rank,
        weeklyPoints: userWeeklyPoints,
        totalParticipants,
        percentile,
        topPercent: percentile >= 90,
        nearbyCompetitors,
        nextRank: rank && rank > 1 ? {
          rank: rank - 1,
          pointsNeeded: pointsToNextRank,
          userName: nextRankUser,
        } : null,
      },
    });
  } catch (error) {
    console.error('Get user rank error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to get user rank' },
      { status: 500 }
    );
  }
}
