import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth';
import { db } from '@/lib/db';
import { realtime } from '@/lib/realtime';

/**
 * GET /api/admin/tasks/[taskId]
 * Get a single task's details (admin only)
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ taskId: string }> }
) {
  try {
    const authResult = await requireAdmin(request);
    
    if (authResult instanceof Response) {
      return authResult;
    }
    
    const { taskId } = await params;
    
    const task = await db.task.findUnique({
      where: { taskId },
      include: {
        _count: {
          select: { taskCompletions: true },
        },
        taskCompletions: {
          take: 20,
          orderBy: { completedAt: 'desc' },
          select: {
            id: true,
            pointsAwarded: true,
            xpAwarded: true,
            completedAt: true,
            user: {
              select: {
                id: true,
                name: true,
                email: true,
              },
            },
          },
        },
      },
    });
    
    if (!task) {
      return NextResponse.json(
        { success: false, error: 'Task not found' },
        { status: 404 }
      );
    }
    
    return NextResponse.json({
      success: true,
      data: { task },
    });
  } catch (error) {
    console.error('Admin task fetch error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch task' },
      { status: 500 }
    );
  }
}

/**
 * PUT /api/admin/tasks/[taskId]
 * Update a task (admin only)
 */
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ taskId: string }> }
) {
  try {
    const authResult = await requireAdmin(request);
    
    if (authResult instanceof Response) {
      return authResult;
    }
    
    const { taskId } = await params;
    const body = await request.json();
    
    const {
      name,
      description,
      pointsReward,
      xpReward,
      type,
      category,
      link,
      isActive,
    } = body;
    
    // Check if task exists
    const existingTask = await db.task.findUnique({
      where: { taskId },
    });
    
    if (!existingTask) {
      return NextResponse.json(
        { success: false, error: 'Task not found' },
        { status: 404 }
      );
    }
    
    // Build update data
    const updateData: Record<string, unknown> = {};
    
    if (name !== undefined) updateData.name = name;
    if (description !== undefined) updateData.description = description;
    if (pointsReward !== undefined) updateData.pointsReward = parseInt(pointsReward);
    if (xpReward !== undefined) updateData.xpReward = parseInt(xpReward);
    if (type !== undefined) updateData.type = type;
    if (category !== undefined) updateData.category = category;
    if (link !== undefined) updateData.link = link || null;
    if (isActive !== undefined) updateData.isActive = isActive;
    
    const task = await db.task.update({
      where: { taskId },
      data: updateData,
    });
    
    // Emit real-time event for task update
    realtime.taskUpdated({
      action: 'updated',
      task,
    });
    
    return NextResponse.json({
      success: true,
      data: { task },
      message: 'Task updated successfully',
    });
  } catch (error) {
    console.error('Admin task update error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to update task' },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/admin/tasks/[taskId]
 * Delete a task (admin only)
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ taskId: string }> }
) {
  try {
    const authResult = await requireAdmin(request);
    
    if (authResult instanceof Response) {
      return authResult;
    }
    
    const { taskId } = await params;
    
    // Check if task exists
    const task = await db.task.findUnique({
      where: { taskId },
    });
    
    if (!task) {
      return NextResponse.json(
        { success: false, error: 'Task not found' },
        { status: 404 }
      );
    }
    
    // Delete task completions first
    await db.taskCompletion.deleteMany({
      where: { taskId: task.id },
    });
    
    // Delete task
    await db.task.delete({
      where: { taskId },
    });
    
    // Emit real-time event for task deletion
    realtime.taskUpdated({
      action: 'deleted',
      task: { taskId, ...task },
    });
    
    return NextResponse.json({
      success: true,
      message: 'Task deleted successfully',
    });
  } catch (error) {
    console.error('Admin task delete error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to delete task' },
      { status: 500 }
    );
  }
}
