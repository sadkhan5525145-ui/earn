import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth';
import { db } from '@/lib/db';
import { realtime } from '@/lib/realtime';

/**
 * GET /api/admin/tasks
 * List all tasks (admin only)
 */
export async function GET(request: NextRequest) {
  try {
    const authResult = await requireAdmin(request);
    
    if (authResult instanceof Response) {
      return authResult;
    }
    
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type') || '';
    const active = searchParams.get('active');
    
    const where: {
      type?: string;
      isActive?: boolean;
    } = {};
    
    if (type) {
      where.type = type;
    }
    
    if (active !== null && active !== undefined) {
      where.isActive = active === 'true';
    }
    
    const tasks = await db.task.findMany({
      where,
      orderBy: [
        { type: 'asc' },
        { pointsReward: 'desc' },
      ],
      include: {
        _count: {
          select: { taskCompletions: true },
        },
      },
    });
    
    // Get completion stats
    const totalCompletions = await db.taskCompletion.count();
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const completionsToday = await db.taskCompletion.count({
      where: { completedAt: { gte: today } },
    });
    
    return NextResponse.json({
      success: true,
      data: {
        tasks,
        stats: {
          totalTasks: tasks.length,
          activeTasks: tasks.filter(t => t.isActive).length,
          totalCompletions,
          completionsToday,
        },
      },
    });
  } catch (error) {
    console.error('Admin tasks fetch error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch tasks' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/admin/tasks
 * Create a new task (admin only)
 */
export async function POST(request: NextRequest) {
  try {
    const authResult = await requireAdmin(request);
    
    if (authResult instanceof Response) {
      return authResult;
    }
    
    const body = await request.json();
    const {
      taskId,
      name,
      description,
      pointsReward,
      xpReward,
      type,
      category,
      link,
      isActive,
    } = body;
    
    // Validate required fields
    if (!taskId || !name || !description || !pointsReward || !type) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      );
    }
    
    // Check if taskId already exists
    const existingTask = await db.task.findUnique({
      where: { taskId },
    });
    
    if (existingTask) {
      return NextResponse.json(
        { success: false, error: 'Task ID already exists' },
        { status: 400 }
      );
    }
    
    const task = await db.task.create({
      data: {
        taskId,
        name,
        description,
        pointsReward: parseInt(pointsReward),
        xpReward: parseInt(xpReward || '0'),
        type, // daily, onetime, weekly
        category: category || 'social',
        link: link || null,
        isActive: isActive !== false,
      },
    });
    
    // Emit real-time event for task creation
    realtime.taskUpdated({
      action: 'created',
      task,
    });
    
    return NextResponse.json({
      success: true,
      data: { task },
      message: 'Task created successfully',
    });
  } catch (error) {
    console.error('Admin task create error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to create task' },
      { status: 500 }
    );
  }
}
