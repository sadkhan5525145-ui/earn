import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth';
import { db } from '@/lib/db';

/**
 * GET /api/admin/users/[id]
 * Get a single user's full details (admin only)
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authResult = await requireAdmin(request);
    
    if (authResult instanceof Response) {
      return authResult;
    }
    
    const { id } = await params;
    
    // Get user with all related data
    const user = await db.user.findUnique({
      where: { id },
      select: {
        id: true,
        name: true,
        email: true,
        phone: true,
        isAdmin: true,
        isVerified: true,
        authProvider: true,
        referralCode: true,
        referredBy: true,
        level: true,
        xp: true,
        pointsBalance: true,
        totalPointsEarned: true,
        totalPointsWithdrawn: true,
        dailySpinsRemaining: true,
        totalSpinsCompleted: true,
        streakDays: true,
        lastLoginDate: true,
        lastBonusClaim: true,
        lastSpinReset: true,
        createdAt: true,
        updatedAt: true,
        easypaisaNumber: true,
        jazzcashNumber: true,
        bankAccountNumber: true,
        bankName: true,
        accountTitle: true,
        cnicLast6: true,
        // Related data
        referrals: {
          select: {
            id: true,
            name: true,
            email: true,
            createdAt: true,
            totalSpinsCompleted: true,
          },
          take: 50,
          orderBy: { createdAt: 'desc' },
        },
        withdrawals: {
          select: {
            id: true,
            method: true,
            pointsRequested: true,
            rsAmount: true,
            accountNumber: true,
            status: true,
            adminNote: true,
            createdAt: true,
            processedAt: true,
          },
          take: 50,
          orderBy: { createdAt: 'desc' },
        },
        spinLogs: {
          select: {
            id: true,
            segmentIndex: true,
            pointsWon: true,
            xpEarned: true,
            createdAt: true,
          },
          take: 100,
          orderBy: { createdAt: 'desc' },
        },
        taskCompletions: {
          select: {
            id: true,
            pointsAwarded: true,
            xpAwarded: true,
            completedAt: true,
            task: {
              select: {
                name: true,
                type: true,
              },
            },
          },
          take: 50,
          orderBy: { completedAt: 'desc' },
        },
        achievements: {
          select: {
            id: true,
            unlockedAt: true,
            pointsClaimed: true,
            achievement: {
              select: {
                badgeId: true,
                name: true,
                icon: true,
                pointsReward: true,
                category: true,
              },
            },
          },
          take: 20,
          orderBy: { unlockedAt: 'desc' },
        },
        transactions: {
          select: {
            id: true,
            type: true,
            points: true,
            rsEquivalent: true,
            status: true,
            description: true,
            reference: true,
            createdAt: true,
          },
          take: 100,
          orderBy: { createdAt: 'desc' },
        },
        _count: {
          select: {
            referrals: true,
            withdrawals: true,
            spinLogs: true,
            taskCompletions: true,
            achievements: true,
          },
        },
      },
    });
    
    if (!user) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }
    
    return NextResponse.json({
      success: true,
      data: { user },
    });
  } catch (error) {
    console.error('Admin user fetch error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch user' },
      { status: 500 }
    );
  }
}

/**
 * PUT /api/admin/users/[id]
 * Update a user's details (admin only)
 */
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authResult = await requireAdmin(request);
    
    if (authResult instanceof Response) {
      return authResult;
    }
    
    const { id } = await params;
    const body = await request.json();
    
    const {
      pointsBalance,
      level,
      xp,
      isVerified,
      isAdmin,
      dailySpinsRemaining,
      easypaisaNumber,
      jazzcashNumber,
      bankAccountNumber,
      bankName,
      cnicLast6,
    } = body;
    
    // Build update data
    const updateData: Record<string, unknown> = {};
    
    if (typeof pointsBalance === 'number') updateData.pointsBalance = pointsBalance;
    if (typeof level === 'number') updateData.level = level;
    if (typeof xp === 'number') updateData.xp = xp;
    if (typeof isVerified === 'boolean') updateData.isVerified = isVerified;
    if (typeof isAdmin === 'boolean') updateData.isAdmin = isAdmin;
    if (typeof dailySpinsRemaining === 'number') updateData.dailySpinsRemaining = dailySpinsRemaining;
    if (easypaisaNumber !== undefined) updateData.easypaisaNumber = easypaisaNumber;
    if (jazzcashNumber !== undefined) updateData.jazzcashNumber = jazzcashNumber;
    if (bankAccountNumber !== undefined) updateData.bankAccountNumber = bankAccountNumber;
    if (bankName !== undefined) updateData.bankName = bankName;
    if (cnicLast6 !== undefined) updateData.cnicLast6 = cnicLast6;
    
    const user = await db.user.update({
      where: { id },
      data: updateData,
    });
    
    return NextResponse.json({
      success: true,
      data: { user },
      message: 'User updated successfully',
    });
  } catch (error) {
    console.error('Admin user update error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to update user' },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/admin/users/[id]
 * Delete a user (admin only)
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authResult = await requireAdmin(request);
    
    if (authResult instanceof Response) {
      return authResult;
    }
    
    const { id } = await params;
    
    // Check if user exists
    const user = await db.user.findUnique({ where: { id } });
    
    if (!user) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }
    
    // Prevent deleting yourself
    if (user.id === authResult.id) {
      return NextResponse.json(
        { success: false, error: 'Cannot delete your own account' },
        { status: 400 }
      );
    }
    
    // Delete user (cascading deletes should handle related data)
    await db.user.delete({ where: { id } });
    
    return NextResponse.json({
      success: true,
      message: 'User deleted successfully',
    });
  } catch (error) {
    console.error('Admin user delete error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to delete user' },
      { status: 500 }
    );
  }
}
