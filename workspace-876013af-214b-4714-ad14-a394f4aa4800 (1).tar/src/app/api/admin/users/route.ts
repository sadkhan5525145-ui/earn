import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth';
import { db } from '@/lib/db';

/**
 * GET /api/admin/users
 * List all users with their details (admin only)
 * 
 * Query params:
 * - page: page number (default 1)
 * - limit: items per page (default 20, max 50)
 * - search: search by name, email, or phone
 * - sortBy: field to sort by (createdAt, pointsBalance, totalSpinsCompleted)
 * - sortOrder: asc or desc
 */
export async function GET(request: NextRequest) {
  try {
    const authResult = await requireAdmin(request);
    
    if (authResult instanceof Response) {
      return authResult;
    }
    
    const admin = authResult;
    
    const { searchParams } = new URL(request.url);
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(50, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const search = searchParams.get('search') || '';
    const validSortFields = ['createdAt', 'pointsBalance', 'totalSpinsCompleted', 'level', 'xp', 'name'] as const;
    const sortByParam = searchParams.get('sortBy') || 'createdAt';
    const sortBy = validSortFields.includes(sortByParam as typeof validSortFields[number]) 
      ? sortByParam as typeof validSortFields[number] 
      : 'createdAt';
    const sortOrder = searchParams.get('sortOrder') === 'asc' ? 'asc' : 'desc';
    
    const skip = (page - 1) * limit;
    
    // Build where clause for search
    const where: {
      OR?: Array<{
        name?: { contains: string; mode: 'insensitive' };
        email?: { contains: string; mode: 'insensitive' };
        phone?: { contains: string; mode: 'insensitive' };
      }>;
    } = {};
    
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } },
        { phone: { contains: search, mode: 'insensitive' } },
      ];
    }
    
    // Get total count
    const totalCount = await db.user.count({ where });
    const totalPages = Math.ceil(totalCount / limit);
    
    // Get users with all their details
    const users = await db.user.findMany({
      where,
      orderBy: {
        [sortBy]: sortOrder,
      } as Record<string, 'asc' | 'desc'>,
      skip,
      take: limit,
      select: {
        id: true,
        name: true,
        email: true,
        phone: true,
        isAdmin: true,
        isVerified: true,
        authProvider: true,
        referralCode: true,
        referredBy: true,
        level: true,
        xp: true,
        pointsBalance: true,
        totalPointsEarned: true,
        totalPointsWithdrawn: true,
        dailySpinsRemaining: true,
        totalSpinsCompleted: true,
        streakDays: true,
        lastLoginDate: true,
        lastBonusClaim: true,
        lastSpinReset: true,
        createdAt: true,
        updatedAt: true,
        easypaisaNumber: true,
        jazzcashNumber: true,
        bankAccountNumber: true,
        bankName: true,
        cnicLast6: true,
        _count: {
          select: {
            referrals: true,
            withdrawals: true,
            spinLogs: true,
            taskCompletions: true,
            achievements: true,
          },
        },
      },
    });
    
    // Get overall stats
    const stats = await db.user.aggregate({
      _count: { _all: true },
      _sum: {
        pointsBalance: true,
        totalPointsEarned: true,
        totalPointsWithdrawn: true,
      },
    });
    
    // Get recent activity stats
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const activeToday = await db.user.count({
      where: {
        lastLoginDate: {
          gte: today,
        },
      },
    });
    
    const newThisWeek = await db.user.count({
      where: {
        createdAt: {
          gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
        },
      },
    });
    
    return NextResponse.json({
      success: true,
      data: {
        users,
        pagination: {
          page,
          limit,
          totalCount,
          totalPages,
          hasMore: page < totalPages,
        },
        stats: {
          totalUsers: stats._count._all,
          totalPointsInSystem: stats._sum.pointsBalance || 0,
          totalPointsEarned: stats._sum.totalPointsEarned || 0,
          totalPointsWithdrawn: stats._sum.totalPointsWithdrawn || 0,
          activeToday,
          newThisWeek,
        },
        admin: {
          id: admin.id,
          name: admin.name,
        },
      },
    });
  } catch (error) {
    console.error('Admin users fetch error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch users' },
      { status: 500 }
    );
  }
}
