import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth';
import { db } from '@/lib/db';

/**
 * GET /api/admin/stats
 * Get comprehensive admin dashboard stats
 */
export async function GET(request: NextRequest) {
  try {
    const authResult = await requireAdmin(request);
    
    if (authResult instanceof Response) {
      return authResult;
    }
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const thisWeek = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const thisMonth = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    
    // User stats
    const totalUsers = await db.user.count();
    const newUsersToday = await db.user.count({
      where: { createdAt: { gte: today } },
    });
    const newUsersThisWeek = await db.user.count({
      where: { createdAt: { gte: thisWeek } },
    });
    const newUsersThisMonth = await db.user.count({
      where: { createdAt: { gte: thisMonth } },
    });
    const activeUsersToday = await db.user.count({
      where: { lastLoginDate: { gte: today } },
    });
    
    // Points stats
    const pointsStats = await db.user.aggregate({
      _sum: {
        pointsBalance: true,
        totalPointsEarned: true,
        totalPointsWithdrawn: true,
      },
    });
    
    // Withdrawal stats
    const withdrawalStats = await db.withdrawal.aggregate({
      _count: { _all: true },
      _sum: { pointsRequested: true, rsAmount: true },
      where: { status: 'pending' },
    });
    
    const totalWithdrawals = await db.withdrawal.count();
    const processedWithdrawals = await db.withdrawal.count({
      where: { status: 'processed' },
    });
    const totalRsWithdrawn = await db.withdrawal.aggregate({
      _sum: { rsAmount: true },
      where: { status: 'processed' },
    });
    
    // Spin stats
    const spinStats = await db.spinLog.aggregate({
      _count: { _all: true },
      _sum: { pointsWon: true },
    });
    
    const spinsToday = await db.spinLog.count({
      where: { createdAt: { gte: today } },
    });
    
    const pointsWonToday = await db.spinLog.aggregate({
      _sum: { pointsWon: true },
      where: { createdAt: { gte: today } },
    });
    
    // Task stats
    const taskCompletions = await db.taskCompletion.count();
    const taskCompletionsToday = await db.taskCompletion.count({
      where: { completedAt: { gte: today } },
    });
    
    // Referral stats
    const totalReferrals = await db.referralRecord.count();
    const rewardedReferrals = await db.referralRecord.count({
      where: { status: 'rewarded' },
    });
    
    // Achievement stats
    const achievementsUnlocked = await db.userAchievement.count();
    
    // Level distribution
    const levelDistribution = await db.user.groupBy({
      by: ['level'],
      _count: { _all: true },
      orderBy: { level: 'asc' },
    });
    
    // Recent activity (last 10 actions)
    const recentSpins = await db.spinLog.findMany({
      take: 5,
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        pointsWon: true,
        createdAt: true,
        user: { select: { name: true, email: true } },
      },
    });
    
    const recentWithdrawals = await db.withdrawal.findMany({
      take: 5,
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        method: true,
        rsAmount: true,
        status: true,
        createdAt: true,
        user: { select: { name: true, email: true } },
      },
    });
    
    const recentUsers = await db.user.findMany({
      take: 5,
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        name: true,
        email: true,
        createdAt: true,
        level: true,
      },
    });
    
    return NextResponse.json({
      success: true,
      data: {
        users: {
          total: totalUsers,
          newToday: newUsersToday,
          newThisWeek: newUsersThisWeek,
          newThisMonth: newUsersThisMonth,
          activeToday: activeUsersToday,
        },
        points: {
          inSystem: pointsStats._sum.pointsBalance || 0,
          totalEarned: pointsStats._sum.totalPointsEarned || 0,
          totalWithdrawn: pointsStats._sum.totalPointsWithdrawn || 0,
        },
        withdrawals: {
          total: totalWithdrawals,
          pending: withdrawalStats._count._all,
          pendingRs: withdrawalStats._sum.rsAmount || 0,
          pendingPoints: withdrawalStats._sum.pointsRequested || 0,
          processed: processedWithdrawals,
          totalRsWithdrawn: totalRsWithdrawn._sum.rsAmount || 0,
        },
        spins: {
          total: spinStats._count._all,
          today: spinsToday,
          pointsWonToday: pointsWonToday._sum.pointsWon || 0,
          totalPointsWon: spinStats._sum.pointsWon || 0,
        },
        tasks: {
          total: taskCompletions,
          today: taskCompletionsToday,
        },
        referrals: {
          total: totalReferrals,
          rewarded: rewardedReferrals,
        },
        achievements: {
          total: achievementsUnlocked,
        },
        levelDistribution: levelDistribution.map(l => ({
          level: l.level,
          count: l._count._all,
        })),
        recentActivity: {
          spins: recentSpins,
          withdrawals: recentWithdrawals,
          users: recentUsers,
        },
      },
    });
  } catch (error) {
    console.error('Admin stats fetch error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch stats' },
      { status: 500 }
    );
  }
}
