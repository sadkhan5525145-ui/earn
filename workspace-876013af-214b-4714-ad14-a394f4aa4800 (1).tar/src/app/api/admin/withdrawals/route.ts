import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth';
import { db } from '@/lib/db';

/**
 * GET /api/admin/withdrawals
 * List all withdrawals (admin only)
 * 
 * Query params:
 * - page: page number (default 1)
 * - limit: items per page (default 20, max 50)
 * - status: filter by status (pending, approved, rejected, processed)
 */
export async function GET(request: NextRequest) {
  try {
    const authResult = await requireAdmin(request);
    
    if (authResult instanceof Response) {
      return authResult;
    }
    
    const admin = authResult;
    
    const { searchParams } = new URL(request.url);
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(50, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const status = searchParams.get('status') || 'pending'; // Default to pending
    
    const skip = (page - 1) * limit;
    
    // Build where clause
    const where: { status?: string } = {};
    
    if (status && status !== 'all') {
      where.status = status;
    }
    
    // Get total count
    const totalCount = await db.withdrawal.count({ where });
    const totalPages = Math.ceil(totalCount / limit);
    
    // Get withdrawals with user info
    const withdrawals = await db.withdrawal.findMany({
      where,
      orderBy: {
        createdAt: 'asc', // Oldest first for processing
      },
      skip,
      take: limit,
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            phone: true,
            createdAt: true,
            totalSpinsCompleted: true,
            pointsBalance: true,
          },
        },
      },
    });
    
    // Get summary stats
    const stats = await db.withdrawal.aggregate({
      _count: {
        _all: true,
      },
      _sum: {
        pointsRequested: true,
        rsAmount: true,
      },
      where: {
        status: 'pending',
      },
    });
    
    return NextResponse.json({
      success: true,
      data: {
        withdrawals,
        pagination: {
          page,
          limit,
          totalCount,
          totalPages,
          hasMore: page < totalPages,
        },
        stats: {
          pendingCount: stats._count._all,
          pendingPoints: stats._sum.pointsRequested || 0,
          pendingRs: stats._sum.rsAmount || 0,
        },
        admin: {
          id: admin.id,
          name: admin.name,
        },
      },
    });
  } catch (error) {
    console.error('Admin withdrawals fetch error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch withdrawals' },
      { status: 500 }
    );
  }
}
