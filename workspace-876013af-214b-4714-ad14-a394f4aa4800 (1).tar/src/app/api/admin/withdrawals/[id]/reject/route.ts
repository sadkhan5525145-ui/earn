import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth';
import { db } from '@/lib/db';
import { realtime } from '@/lib/realtime';

interface RouteParams {
  params: Promise<{ id: string }>;
}

interface RejectRequestBody {
  adminNote: string;
}

/**
 * POST /api/admin/withdrawals/[id]/reject
 * Reject a withdrawal request with a note (admin only)
 * 
 * This refunds the points to the user's balance.
 */
export async function POST(request: NextRequest, { params }: RouteParams) {
  try {
    const authResult = await requireAdmin(request);
    
    if (authResult instanceof Response) {
      return authResult;
    }
    
    const admin = authResult;
    const { id } = await params;
    
    // Parse request body
    let body: RejectRequestBody;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json(
        { success: false, error: 'Invalid request body' },
        { status: 400 }
      );
    }
    
    // Validate admin note
    if (!body.adminNote || body.adminNote.trim().length < 5) {
      return NextResponse.json(
        { success: false, error: 'Please provide a reason for rejection (minimum 5 characters)' },
        { status: 400 }
      );
    }
    
    // Check if withdrawal exists
    const withdrawal = await db.withdrawal.findUnique({
      where: { id },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            pointsBalance: true,
          },
        },
      },
    });
    
    if (!withdrawal) {
      return NextResponse.json(
        { success: false, error: 'Withdrawal not found' },
        { status: 404 }
      );
    }
    
    // Check if already processed
    if (withdrawal.status !== 'pending') {
      return NextResponse.json(
        { success: false, error: `Withdrawal already ${withdrawal.status}` },
        { status: 400 }
      );
    }
    
    // Update withdrawal status, refund points, and delete transaction in a transaction
    const result = await db.$transaction(async (tx) => {
      // Update withdrawal
      const updatedWithdrawal = await tx.withdrawal.update({
        where: { id },
        data: {
          status: 'rejected',
          adminNote: body.adminNote.trim(),
          processedBy: admin.id,
          processedAt: new Date(),
        },
      });
      
      // Refund points to user
      await tx.user.update({
        where: { id: withdrawal.userId },
        data: {
          pointsBalance: { increment: withdrawal.pointsRequested },
        },
      });
      
      // Update transaction status
      await tx.transaction.updateMany({
        where: {
          type: 'withdrawal',
          reference: withdrawal.id,
        },
        data: {
          status: 'rejected',
          description: `Withdrawal rejected: ${body.adminNote}`,
        },
      });
      
      return updatedWithdrawal;
    });
    
    // Emit real-time events to user
    realtime.withdrawalUpdate({
      withdrawalId: withdrawal.id,
      userId: withdrawal.userId,
      status: 'rejected',
      adminNote: body.adminNote.trim(),
    });
    
    realtime.balanceUpdate({
      userId: withdrawal.userId,
      pointsBalance: withdrawal.user.pointsBalance + withdrawal.pointsRequested,
      rsEquivalent: (withdrawal.user.pointsBalance + withdrawal.pointsRequested) * 0.1,
      change: withdrawal.pointsRequested,
      reason: 'Withdrawal refund',
    });
    
    return NextResponse.json({
      success: true,
      data: {
        withdrawal: result,
        user: {
          id: withdrawal.user.id,
          name: withdrawal.user.name,
          refundedPoints: withdrawal.pointsRequested,
          newBalance: withdrawal.user.pointsBalance + withdrawal.pointsRequested,
        },
      },
      message: `Withdrawal rejected. ${withdrawal.pointsRequested} points refunded to ${withdrawal.user.name}.`,
    });
  } catch (error) {
    console.error('Withdrawal rejection error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to reject withdrawal' },
      { status: 500 }
    );
  }
}
