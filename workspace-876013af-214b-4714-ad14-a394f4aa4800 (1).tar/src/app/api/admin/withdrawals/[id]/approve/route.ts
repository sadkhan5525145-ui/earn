import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth';
import { db } from '@/lib/db';
import { realtime } from '@/lib/realtime';

interface RouteParams {
  params: Promise<{ id: string }>;
}

/**
 * POST /api/admin/withdrawals/[id]/approve
 * Approve a withdrawal request (admin only)
 * 
 * This marks the withdrawal as approved and ready for processing.
 * The actual payment is done externally by the admin.
 */
export async function POST(request: NextRequest, { params }: RouteParams) {
  try {
    const authResult = await requireAdmin(request);
    
    if (authResult instanceof Response) {
      return authResult;
    }
    
    const admin = authResult;
    const { id } = await params;
    
    // Check if withdrawal exists
    const withdrawal = await db.withdrawal.findUnique({
      where: { id },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            pointsBalance: true,
          },
        },
      },
    });
    
    if (!withdrawal) {
      return NextResponse.json(
        { success: false, error: 'Withdrawal not found' },
        { status: 404 }
      );
    }
    
    // Check if already processed
    if (withdrawal.status !== 'pending') {
      return NextResponse.json(
        { success: false, error: `Withdrawal already ${withdrawal.status}` },
        { status: 400 }
      );
    }
    
    // Update withdrawal status and user's total withdrawn in a transaction
    const result = await db.$transaction(async (tx) => {
      // Update withdrawal
      const updatedWithdrawal = await tx.withdrawal.update({
        where: { id },
        data: {
          status: 'approved',
          processedBy: admin.id,
          processedAt: new Date(),
        },
      });
      
      // Update user's total withdrawn
      await tx.user.update({
        where: { id: withdrawal.userId },
        data: {
          totalPointsWithdrawn: { increment: withdrawal.pointsRequested },
        },
      });
      
      // Update transaction status
      await tx.transaction.updateMany({
        where: {
          type: 'withdrawal',
          reference: withdrawal.id,
        },
        data: {
          status: 'completed',
        },
      });
      
      return updatedWithdrawal;
    });
    
    // Emit real-time event to user
    realtime.withdrawalUpdate({
      withdrawalId: withdrawal.id,
      userId: withdrawal.userId,
      status: 'approved',
    });
    
    return NextResponse.json({
      success: true,
      data: {
        withdrawal: result,
        user: {
          id: withdrawal.user.id,
          name: withdrawal.user.name,
        },
      },
      message: `Withdrawal of Rs. ${withdrawal.rsAmount} approved for ${withdrawal.user.name}. Payment should be processed via ${withdrawal.method}.`,
    });
  } catch (error) {
    console.error('Withdrawal approval error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to approve withdrawal' },
      { status: 500 }
    );
  }
}
