import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/auth';
import { db } from '@/lib/db';

// Level definitions with XP requirements and perks
const LEVELS = [
  { level: 0, name: 'Bronze', xpRequired: 0, dailySpins: 5, bonusPoints: 0, perks: ['Basic spin wheel access'] },
  { level: 1, name: 'Silver', xpRequired: 500, dailySpins: 6, bonusPoints: 200, perks: ['+200 pts bonus on level-up', 'Extra daily spin'] },
  { level: 2, name: 'Gold', xpRequired: 1200, dailySpins: 7, bonusPoints: 500, perks: ['+500 pts bonus on level-up', 'Better spin odds', 'Extra daily spins'] },
  { level: 3, name: 'Platinum', xpRequired: 2500, dailySpins: 8, bonusPoints: 750, perks: ['+750 pts bonus on level-up', 'Even better odds', 'Priority support'] },
  { level: 4, name: 'Diamond', xpRequired: 5000, dailySpins: 10, bonusPoints: 1000, perks: ['+1000 pts bonus on level-up', 'Premium odds', 'Exclusive rewards'] },
  { level: 5, name: 'Master', xpRequired: 9000, dailySpins: 12, bonusPoints: 2000, perks: ['+2000 pts bonus on level-up', 'VIP status', 'Maximum spins'] },
  { level: 6, name: 'Legend', xpRequired: 15000, dailySpins: 15, bonusPoints: 3000, perks: ['+3000 pts bonus on level-up', 'Legendary status', 'All perks unlocked'] },
  { level: 7, name: 'Grandmaster', xpRequired: 25000, dailySpins: -1, bonusPoints: 5000, perks: ['+5000 pts bonus on level-up', 'Unlimited spins', 'Grandmaster badge', 'Highest rewards'] },
];

/**
 * Calculate the level for a given XP amount
 */
function calculateLevel(xp: number): { level: number; levelData: typeof LEVELS[0]; nextLevel: typeof LEVELS[0] | null } {
  let currentLevel = LEVELS[0];
  let nextLevel: typeof LEVELS[0] | null = null;
  
  for (let i = LEVELS.length - 1; i >= 0; i--) {
    if (xp >= LEVELS[i].xpRequired) {
      currentLevel = LEVELS[i];
      nextLevel = i < LEVELS.length - 1 ? LEVELS[i + 1] : null;
      break;
    }
  }
  
  return { level: currentLevel.level, levelData: currentLevel, nextLevel };
}

/**
 * GET /api/level
 * Get current level info, XP progress, and next level requirements
 * 
 * Returns:
 * - currentLevel: Level number
 * - levelName: Level name (Bronze, Silver, etc.)
 * - currentXP: User's current XP
 * - nextLevelXP: XP required for next level (null if max)
 * - xpProgress: Percentage progress to next level
 * - dailySpins: Daily spins allowed (-1 for unlimited)
 * - perks: List of perks for current level
 */
export async function GET(request: NextRequest) {
  try {
    const authResult = await requireAuth(request);
    
    if (authResult instanceof Response) {
      return authResult;
    }
    
    const user = authResult;
    
    const { levelData, nextLevel } = calculateLevel(user.xp);
    
    // Calculate XP progress
    let xpProgress = 100;
    let xpToNextLevel = 0;
    
    if (nextLevel) {
      const currentLevelXP = levelData.xpRequired;
      const nextLevelXP = nextLevel.xpRequired;
      const xpInCurrentLevel = user.xp - currentLevelXP;
      const xpNeededForNext = nextLevelXP - currentLevelXP;
      xpProgress = Math.min(100, Math.round((xpInCurrentLevel / xpNeededForNext) * 100));
      xpToNextLevel = nextLevelXP - user.xp;
    }
    
    // Check if user level is out of sync with calculated level
    if (user.level !== levelData.level) {
      // Update user's level in background (non-blocking)
      db.user.update({
        where: { id: user.id },
        data: { level: levelData.level },
      }).catch(err => console.error('Failed to update level:', err));
    }
    
    // Get XP earned today
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const todayTransactions = await db.transaction.findMany({
      where: {
        userId: user.id,
        createdAt: { gte: today },
        type: { in: ['spin_win', 'task', 'streak', 'daily_bonus', 'referral', 'achievement'] },
      },
    });
    
    const xpEarnedToday = todayTransactions.reduce((sum, t) => {
      // Rough XP estimation based on transaction types
      if (t.type === 'spin_win') return sum + 5; // Base XP per spin
      if (t.type === 'task') return sum + 20;
      if (t.type === 'daily_bonus') return sum + 30;
      if (t.type === 'referral') return sum + 100;
      if (t.type === 'streak') return sum + 200;
      return sum;
    }, 0);
    
    return NextResponse.json({
      success: true,
      data: {
        currentLevel: levelData.level,
        levelName: levelData.name,
        currentXP: user.xp,
        nextLevelXP: nextLevel?.xpRequired || null,
        xpToNextLevel: xpToNextLevel || null,
        xpProgress,
        dailySpins: levelData.dailySpins === -1 ? 'unlimited' : levelData.dailySpins,
        bonusPoints: levelData.bonusPoints,
        perks: levelData.perks,
        stats: {
          totalSpinsCompleted: user.totalSpinsCompleted,
          streakDays: user.streakDays,
          xpEarnedToday,
        },
        nextLevelInfo: nextLevel ? {
          level: nextLevel.level,
          name: nextLevel.name,
          xpRequired: nextLevel.xpRequired,
          dailySpins: nextLevel.dailySpins === -1 ? 'unlimited' : nextLevel.dailySpins,
          bonusPoints: nextLevel.bonusPoints,
          perks: nextLevel.perks,
        } : null,
      },
    });
  } catch (error) {
    console.error('Level fetch error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch level info' },
      { status: 500 }
    );
  }
}
