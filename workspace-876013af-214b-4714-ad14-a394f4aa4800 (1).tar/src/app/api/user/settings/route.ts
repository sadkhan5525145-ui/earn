import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getCurrentUser, apiSuccess, apiError } from '@/lib/auth';

// Allowed withdrawal settings fields
interface WithdrawalSettings {
  easypaisaNumber?: string | null;
  jazzcashNumber?: string | null;
  bankAccountNumber?: string | null;
  bankName?: string | null;
  cnicLast6?: string | null;
}

// Validate Pakistani mobile number
function isValidPakistaniMobile(number: string): boolean {
  return /^(\+92|0)?[3][0-9]{9}$/.test(number.replace(/\s/g, ''));
}

// Validate CNIC last 6 digits
function isValidCnicLast6(cnic: string): boolean {
  return /^[0-9]{6}$/.test(cnic);
}

// Validate bank account number (basic validation)
function isValidBankAccount(account: string): boolean {
  return /^[0-9]{10,20}$/.test(account.replace(/[\s-]/g, ''));
}

// GET - Retrieve user withdrawal settings
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser(request);

    if (!user) {
      return apiError('Not authenticated', 401);
    }

    // Get user's withdrawal settings
    const userData = await db.user.findUnique({
      where: { id: user.id },
      select: {
        cnicLast6: true,
        easypaisaNumber: true,
        jazzcashNumber: true,
        bankAccountNumber: true,
        bankName: true
      }
    });

    if (!userData) {
      return apiError('User not found', 404);
    }

    return apiSuccess({ settings: userData });
  } catch (error) {
    console.error('Get settings error:', error);
    return apiError('An error occurred', 500);
  }
}

// PUT - Update user withdrawal settings
export async function PUT(request: NextRequest) {
  try {
    const user = await getCurrentUser(request);

    if (!user) {
      return apiError('Not authenticated', 401);
    }

    const body: WithdrawalSettings = await request.json();
    const { easypaisaNumber, jazzcashNumber, bankAccountNumber, bankName, cnicLast6 } = body;

    // Build update object
    const updateData: WithdrawalSettings = {};
    const errors: string[] = [];

    // Validate and set easypaisaNumber
    if (easypaisaNumber !== undefined) {
      if (easypaisaNumber && !isValidPakistaniMobile(easypaisaNumber)) {
        errors.push('Invalid Easypaisa number format');
      } else {
        updateData.easypaisaNumber = easypaisaNumber || null;
      }
    }

    // Validate and set jazzcashNumber
    if (jazzcashNumber !== undefined) {
      if (jazzcashNumber && !isValidPakistaniMobile(jazzcashNumber)) {
        errors.push('Invalid JazzCash number format');
      } else {
        updateData.jazzcashNumber = jazzcashNumber || null;
      }
    }

    // Validate and set bankAccountNumber
    if (bankAccountNumber !== undefined) {
      if (bankAccountNumber && !isValidBankAccount(bankAccountNumber)) {
        errors.push('Invalid bank account number format');
      } else {
        updateData.bankAccountNumber = bankAccountNumber || null;
      }
    }

    // Validate and set bankName
    if (bankName !== undefined) {
      if (bankName && bankAccountNumber === undefined && !updateData.bankAccountNumber) {
        errors.push('Bank account number is required when providing bank name');
      } else {
        updateData.bankName = bankName || null;
      }
    }

    // Validate and set cnicLast6
    if (cnicLast6 !== undefined) {
      if (cnicLast6 && !isValidCnicLast6(cnicLast6)) {
        errors.push('CNIC last 6 digits must be exactly 6 numbers');
      } else {
        updateData.cnicLast6 = cnicLast6 || null;
      }
    }

    // Return validation errors if any
    if (errors.length > 0) {
      return apiError(errors.join('. '));
    }

    // Check if there's anything to update
    if (Object.keys(updateData).length === 0) {
      return apiError('No valid fields to update');
    }

    // Update user settings
    const updatedUser = await db.user.update({
      where: { id: user.id },
      data: updateData,
      select: {
        id: true,
        cnicLast6: true,
        easypaisaNumber: true,
        jazzcashNumber: true,
        bankAccountNumber: true,
        bankName: true
      }
    });

    return apiSuccess({ 
      message: 'Withdrawal settings updated successfully',
      settings: updatedUser
    });
  } catch (error) {
    console.error('Update settings error:', error);
    return apiError('An error occurred while updating settings', 500);
  }
}
