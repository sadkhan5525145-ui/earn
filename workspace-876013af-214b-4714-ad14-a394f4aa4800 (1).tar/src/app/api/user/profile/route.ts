import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getCurrentUser, apiSuccess, apiError, sanitizeUser } from '@/lib/auth';

// GET - Retrieve current user profile
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser(request);

    if (!user) {
      return apiError('Not authenticated', 401);
    }

    // Get fresh user data from database
    const freshUser = await db.user.findUnique({
      where: { id: user.id },
      include: {
        _count: {
          select: { 
            referrals: true,
            spinLogs: true,
            achievements: true
          }
        }
      }
    });

    if (!freshUser) {
      return apiError('User not found', 404);
    }

    const { passwordHash: _passwordHash, ...userWithoutPassword } = freshUser;

    return apiSuccess({ 
      user: userWithoutPassword,
      stats: {
        totalReferrals: freshUser._count.referrals,
        totalSpins: freshUser._count.spinLogs,
        achievementsUnlocked: freshUser._count.achievements
      }
    });
  } catch (error) {
    console.error('Get profile error:', error);
    return apiError('An error occurred', 500);
  }
}

// PUT - Update user profile
export async function PUT(request: NextRequest) {
  try {
    const user = await getCurrentUser(request);

    if (!user) {
      return apiError('Not authenticated', 401);
    }

    const body = await request.json();
    const { name, phone } = body;

    // Build update object with only allowed fields
    const updateData: { name?: string; phone?: string | null } = {};
    
    if (name !== undefined) {
      if (typeof name !== 'string' || name.trim().length < 2) {
        return apiError('Name must be at least 2 characters');
      }
      updateData.name = name.trim();
    }

    if (phone !== undefined) {
      // Validate phone format (Pakistani mobile number)
      if (phone && !/^(\+92|0)?[3][0-9]{9}$/.test(phone.replace(/\s/g, ''))) {
        return apiError('Invalid Pakistani mobile number format');
      }
      updateData.phone = phone || null;
    }

    // Check if there's anything to update
    if (Object.keys(updateData).length === 0) {
      return apiError('No valid fields to update');
    }

    // Update user
    const updatedUser = await db.user.update({
      where: { id: user.id },
      data: updateData
    });

    return apiSuccess({ 
      message: 'Profile updated successfully',
      user: sanitizeUser(updatedUser)
    });
  } catch (error) {
    console.error('Update profile error:', error);
    return apiError('An error occurred while updating profile', 500);
  }
}
