import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'
import { WHEEL_SEGMENTS } from '@/lib/spin-wheel'

interface SpinHistoryItem {
  id: string
  segmentIndex: number
  pointsWon: number
  xpEarned: number
  label: string
  color: string
  isJackpot: boolean
  createdAt: string
}

interface SpinHistoryResponse {
  success: boolean
  data?: {
    spins: SpinHistoryItem[]
    total: number
    summary: {
      totalSpins: number
      totalPointsWon: number
      totalXpEarned: number
      jackpotCount: number
      tryAgainCount: number
    }
  }
  message?: string
  error?: string
}

// GET /api/spin/history - Get last 20 spin logs for user
export async function GET(request: NextRequest): Promise<NextResponse<SpinHistoryResponse>> {
  try {
    const user = await getCurrentUser(request)

    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      )
    }

    // Get last 20 spins
    const spins = await db.spinLog.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      take: 20,
      select: {
        id: true,
        segmentIndex: true,
        pointsWon: true,
        xpEarned: true,
        createdAt: true,
      },
    })

    // Get summary statistics
    const stats = await db.spinLog.aggregate({
      where: { userId: user.id },
      _count: true,
      _sum: {
        pointsWon: true,
        xpEarned: true,
      },
    })

    // Count jackpots (segment 6) and try again (segments 2, 5, 10)
    const jackpotCount = await db.spinLog.count({
      where: {
        userId: user.id,
        segmentIndex: 6, // Jackpot segment
      },
    })

    const tryAgainCount = await db.spinLog.count({
      where: {
        userId: user.id,
        segmentIndex: { in: [2, 5, 10] }, // Try Again segments
      },
    })

    // Map spins with segment details
    const spinsWithDetails: SpinHistoryItem[] = spins.map(spin => {
      const segment = WHEEL_SEGMENTS[spin.segmentIndex]
      return {
        id: spin.id,
        segmentIndex: spin.segmentIndex,
        pointsWon: spin.pointsWon,
        xpEarned: spin.xpEarned,
        label: segment?.label || 'Unknown',
        color: segment?.color || 'unknown',
        isJackpot: segment?.isJackpot || false,
        createdAt: spin.createdAt.toISOString(),
      }
    })

    return NextResponse.json({
      success: true,
      data: {
        spins: spinsWithDetails,
        total: spins.length,
        summary: {
          totalSpins: stats._count,
          totalPointsWon: stats._sum.pointsWon || 0,
          totalXpEarned: stats._sum.xpEarned || 0,
          jackpotCount,
          tryAgainCount,
        },
      },
    })
  } catch (error) {
    console.error('Get spin history error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to get spin history' },
      { status: 500 }
    )
  }
}
