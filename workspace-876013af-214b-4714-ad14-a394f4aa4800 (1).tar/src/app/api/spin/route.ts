import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import {
  spinWheel,
  calculateXP,
  needsDailyReset,
  getSpinsForLevel,
  getSpinMessage,
  calculateLevelFromXP,
  WHEEL_SEGMENTS,
} from '@/lib/spin-wheel'
import { realtime } from '@/lib/realtime'

interface SpinResponse {
  success: boolean
  data?: {
    segmentIndex: number
    pointsWon: number
    xpEarned: number
    remainingSpins: number
    newBalance: number
    newLevel: number
    leveledUp?: boolean
  }
  message?: string
  error?: string
}

interface SpinStatusResponse {
  success: boolean
  data?: {
    remainingSpins: number
    totalSpins: number
    level: number
    levelName: string
    xp: number
    xpToNextLevel: number
    lastSpins: Array<{
      segmentIndex: number
      pointsWon: number
      createdAt: string
    }>
  }
  message?: string
  error?: string
}

// GET /api/spin - Get spin status
export async function GET(request: NextRequest): Promise<NextResponse<SpinStatusResponse>> {
  try {
    const user = await getCurrentUser(request)

    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      )
    }

    // Check for daily reset
    if (needsDailyReset(user.lastSpinReset)) {
      const spinsForLevel = getSpinsForLevel(user.level)
      
      await db.user.update({
        where: { id: user.id },
        data: {
          dailySpinsRemaining: spinsForLevel,
          lastSpinReset: new Date(),
        },
      })
      
      user.dailySpinsRemaining = spinsForLevel
    }

    // Get last 5 spins for quick history
    const lastSpins = await db.spinLog.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      take: 5,
      select: {
        segmentIndex: true,
        pointsWon: true,
        createdAt: true,
      },
    })

    // Calculate XP to next level
    const levelThresholds = [0, 100, 300, 600, 1000, 2000, 4000, 8000]
    const nextLevel = Math.min(user.level + 1, 7)
    const xpToNextLevel = (levelThresholds[nextLevel] || 8000) - user.xp

    // Level names
    const levelNames = ['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond', 'Master', 'Legend', 'Grandmaster']

    return NextResponse.json({
      success: true,
      data: {
        remainingSpins: user.dailySpinsRemaining,
        totalSpins: user.totalSpinsCompleted,
        level: user.level,
        levelName: levelNames[user.level] || 'Bronze',
        xp: user.xp,
        xpToNextLevel: Math.max(0, xpToNextLevel),
        lastSpins: lastSpins.map(spin => ({
          segmentIndex: spin.segmentIndex,
          pointsWon: spin.pointsWon,
          createdAt: spin.createdAt.toISOString(),
        })),
      },
    })
  } catch (error) {
    console.error('Get spin status error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to get spin status' },
      { status: 500 }
    )
  }
}

// POST /api/spin - Execute a spin
export async function POST(request: NextRequest): Promise<NextResponse<SpinResponse>> {
  try {
    const user = await getCurrentUser(request)

    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      )
    }

    // Check for daily reset first
    if (needsDailyReset(user.lastSpinReset)) {
      const spinsForLevel = getSpinsForLevel(user.level)
      
      await db.user.update({
        where: { id: user.id },
        data: {
          dailySpinsRemaining: spinsForLevel,
          lastSpinReset: new Date(),
        },
      })
      
      user.dailySpinsRemaining = spinsForLevel
    }

    // Validate user has spins remaining
    if (user.dailySpinsRemaining <= 0) {
      return NextResponse.json(
        { 
          success: false, 
          error: 'No spins remaining. Come back tomorrow for more spins!',
          data: {
            segmentIndex: -1,
            pointsWon: 0,
            xpEarned: 0,
            remainingSpins: 0,
            newBalance: user.pointsBalance,
            newLevel: user.level,
          }
        },
        { status: 400 }
      )
    }

    // Generate spin result using server-side RNG
    const result = spinWheel()
    const pointsWon = result.points
    const xpEarned = calculateXP(pointsWon)

    // Get client IP for logging
    const forwardedFor = request.headers.get('x-forwarded-for')
    const ipAddress = forwardedFor ? forwardedFor.split(',')[0].trim() : 'unknown'

    // Use transaction to ensure data consistency
    const updatedUser = await db.$transaction(async (tx) => {
      // Log the spin
      await tx.spinLog.create({
        data: {
          userId: user.id,
          segmentIndex: result.index,
          pointsWon,
          xpEarned,
          ipAddress,
        },
      })

      // Create transaction record if points were won
      if (pointsWon > 0) {
        await tx.transaction.create({
          data: {
            userId: user.id,
            type: 'spin_win',
            points: pointsWon,
            rsEquivalent: pointsWon * 0.1, // 100 points = Rs. 10
            status: 'completed',
            description: `Won ${pointsWon} points from spin wheel${result.isJackpot ? ' (JACKPOT!)' : ''}`,
          },
        })
      }

      // Calculate new XP and level
      const newXP = user.xp + xpEarned
      const newLevel = calculateLevelFromXP(newXP)
      const leveledUp = newLevel > user.level

      // Update user
      const updated = await tx.user.update({
        where: { id: user.id },
        data: {
          pointsBalance: { increment: pointsWon },
          totalPointsEarned: { increment: pointsWon },
          xp: newXP,
          level: newLevel,
          dailySpinsRemaining: { decrement: 1 },
          totalSpinsCompleted: { increment: 1 },
        },
      })

      // If user leveled up, create a level_up transaction
      if (leveledUp) {
        const levelBonus = newLevel * 50 // 50 points per level
        await tx.transaction.create({
          data: {
            userId: user.id,
            type: 'level_up',
            points: levelBonus,
            rsEquivalent: levelBonus * 0.1,
            status: 'completed',
            description: `Leveled up to ${['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond', 'Master', 'Legend', 'Grandmaster'][newLevel]}! Bonus: ${levelBonus} points`,
          },
        })

        // Add the level bonus to user's balance
        await tx.user.update({
          where: { id: user.id },
          data: {
            pointsBalance: { increment: levelBonus },
            totalPointsEarned: { increment: levelBonus },
          },
        })
      }

      return { ...updated, leveledUp, newLevel }
    })

    // Build response
    const message = getSpinMessage(pointsWon, result.isJackpot)

    // Emit real-time events
    realtime.spinResult({
      userId: user.id,
      pointsWon,
      xpEarned,
      newBalance: updatedUser.pointsBalance,
      segmentIndex: result.index,
    })

    realtime.balanceUpdate({
      userId: user.id,
      pointsBalance: updatedUser.pointsBalance,
      rsEquivalent: updatedUser.pointsBalance * 0.1,
      change: pointsWon,
      reason: 'Spin Win',
    })

    if (updatedUser.leveledUp) {
      const levelNames = ['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond', 'Master', 'Legend', 'Grandmaster']
      realtime.levelUp({
        userId: user.id,
        newLevel: updatedUser.newLevel,
        levelName: levelNames[updatedUser.newLevel] || 'Bronze',
        rewards: { bonus: updatedUser.newLevel * 50 },
      })
    }

    return NextResponse.json({
      success: true,
      data: {
        segmentIndex: result.index,
        pointsWon,
        xpEarned,
        remainingSpins: updatedUser.dailySpinsRemaining,
        newBalance: updatedUser.pointsBalance,
        newLevel: updatedUser.newLevel,
        leveledUp: updatedUser.leveledUp,
      },
      message: updatedUser.leveledUp 
        ? `${message} You also leveled up to ${['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond', 'Master', 'Legend', 'Grandmaster'][updatedUser.newLevel]}!`
        : message,
    })
  } catch (error) {
    console.error('Spin error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to process spin. Please try again.' },
      { status: 500 }
    )
  }
}

// Export wheel configuration for frontend use
export { WHEEL_SEGMENTS }
