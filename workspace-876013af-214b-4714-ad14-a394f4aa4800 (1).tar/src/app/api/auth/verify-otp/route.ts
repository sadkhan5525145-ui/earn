import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { verifyOTP, apiSuccess, apiError, sanitizeUser } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, code } = body;

    // Validate required fields
    if (!email || !code) {
      return apiError('Email and OTP code are required');
    }

    // Verify OTP
    const result = await verifyOTP(email, code, 'verification');
    
    if (!result.valid) {
      return apiError(result.error || 'Invalid OTP');
    }

    // Update user verification status
    const user = await db.user.update({
      where: { email },
      data: { isVerified: true }
    });

    return apiSuccess({ 
      message: 'Email verified successfully',
      user: sanitizeUser(user)
    });
  } catch (error) {
    console.error('Verify OTP error:', error);
    return apiError('An error occurred during verification', 500);
  }
}
