import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { 
  hashPassword, 
  getUniqueReferralCode, 
  createSession, 
  setSessionCookie, 
  apiSuccess, 
  apiError, 
  sanitizeUser 
} from '@/lib/auth';
import { realtime } from '@/lib/realtime';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, name, phone, password, referralCode } = body;

    // Validate required fields
    if (!email || !name || !password) {
      return apiError('Email, name, and password are required');
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return apiError('Invalid email format');
    }

    // Validate password length
    if (password.length < 6) {
      return apiError('Password must be at least 6 characters');
    }

    // Check if user already exists
    const existingUser = await db.user.findUnique({
      where: { email }
    });

    if (existingUser) {
      return apiError('An account with this email already exists');
    }

    // Generate unique referral code
    const userReferralCode = await getUniqueReferralCode();

    // Hash password
    const passwordHash = await hashPassword(password);

    // Check referral code validity if provided
    let referrerId: string | null = null;
    if (referralCode) {
      const referrer = await db.user.findUnique({
        where: { referralCode: referralCode.toUpperCase() }
      });
      if (referrer) {
        referrerId = referrer.id;
      }
    }

    // Create user
    const user = await db.user.create({
      data: {
        email,
        name,
        phone: phone || null,
        passwordHash,
        referralCode: userReferralCode,
        referredBy: referrerId,
        authProvider: 'email',
        isVerified: false,
        level: 0,
        xp: 0,
        pointsBalance: 0,
        totalPointsEarned: 0,
        totalPointsWithdrawn: 0,
        dailySpinsRemaining: 5,
        totalSpinsCompleted: 0,
        streakDays: 0
      }
    });

    // Create referral record if referred
    if (referrerId) {
      await db.referralRecord.create({
        data: {
          referrerId,
          referredId: user.id,
          code: referralCode.toUpperCase(),
          status: 'pending'
        }
      });
      
      // Emit real-time event to referrer
      realtime.referralNew({
        referrerId,
        referredName: name,
        status: 'pending',
      });
    }

    // Create session
    const token = await createSession(user.id);

    // Prepare response
    const response = apiSuccess({
      user: sanitizeUser(user),
      token
    }, 201);

    // Set session cookie
    setSessionCookie(response, token);

    return response;
  } catch (error) {
    console.error('Registration error:', error);
    return apiError('An error occurred during registration', 500);
  }
}
