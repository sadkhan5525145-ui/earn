import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { 
  verifyPassword, 
  createSession, 
  setSessionCookie, 
  apiSuccess, 
  apiError, 
  sanitizeUser 
} from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, password } = body;

    // Validate required fields
    if (!email || !password) {
      return apiError('Email and password are required');
    }

    // Find user by email
    const user = await db.user.findUnique({
      where: { email }
    });

    if (!user) {
      return apiError('Invalid email or password');
    }

    // Check if user has password (not social login only)
    if (!user.passwordHash) {
      return apiError('Please sign in with your social account');
    }

    // Verify password
    const isValidPassword = await verifyPassword(password, user.passwordHash);
    if (!isValidPassword) {
      return apiError('Invalid email or password');
    }

    // Update last login date for streak tracking
    await db.user.update({
      where: { id: user.id },
      data: { lastLoginDate: new Date() }
    });

    // Create session
    const token = await createSession(user.id);

    // Prepare response
    const response = apiSuccess({
      user: sanitizeUser(user),
      token
    });

    // Set session cookie
    setSessionCookie(response, token);

    return response;
  } catch (error) {
    console.error('Login error:', error);
    return apiError('An error occurred during login', 500);
  }
}
