import { NextRequest } from 'next/server';
import { 
  getSessionToken, 
  invalidateSession, 
  clearSessionCookie, 
  apiSuccess, 
  apiError 
} from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const token = getSessionToken(request);

    if (token) {
      // Invalidate session in database
      await invalidateSession(token);
    }

    // Prepare response
    const response = apiSuccess({ message: 'Logged out successfully' });

    // Clear session cookie
    clearSessionCookie(response);

    return response;
  } catch (error) {
    console.error('Logout error:', error);
    return apiError('An error occurred during logout', 500);
  }
}
