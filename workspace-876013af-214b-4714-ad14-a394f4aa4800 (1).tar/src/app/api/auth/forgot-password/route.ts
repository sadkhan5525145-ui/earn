import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { createOTP, apiSuccess, apiError } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email } = body;

    // Validate required fields
    if (!email) {
      return apiError('Email is required');
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return apiError('Invalid email format');
    }

    // Check if user exists
    const user = await db.user.findUnique({
      where: { email }
    });

    if (!user) {
      // For security, don't reveal if email exists or not
      return apiSuccess({ message: 'If an account exists, a reset code has been sent' });
    }

    // Rate limiting: Check if there's a recent OTP (within 1 minute)
    const recentOTP = await db.oTP.findFirst({
      where: {
        email,
        type: 'password_reset',
        createdAt: {
          gte: new Date(Date.now() - 60 * 1000) // 1 minute ago
        }
      }
    });

    if (recentOTP) {
      return apiError('Please wait before requesting another reset code');
    }

    // Create and store OTP
    const otp = await createOTP(email, 'password_reset');

    // In a real application, send email here
    console.log(`[DEV] Password reset OTP for ${email}: ${otp}`);

    // TODO: Send actual email with OTP
    // await sendPasswordResetEmail(email, otp);

    return apiSuccess({ 
      message: 'If an account exists, a reset code has been sent',
      // Only return OTP in development
      ...(process.env.NODE_ENV === 'development' && { otp })
    });
  } catch (error) {
    console.error('Forgot password error:', error);
    return apiError('An error occurred', 500);
  }
}
