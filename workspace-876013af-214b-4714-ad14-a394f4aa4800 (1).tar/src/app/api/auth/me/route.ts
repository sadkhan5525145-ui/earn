import { NextRequest } from 'next/server';
import { 
  getCurrentUser, 
  apiSuccess, 
  apiError, 
  sanitizeUser 
} from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser(request);

    if (!user) {
      return apiError('Not authenticated', 401);
    }

    return apiSuccess({ user: sanitizeUser(user) });
  } catch (error) {
    console.error('Get current user error:', error);
    return apiError('An error occurred', 500);
  }
}
