import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { createOTP, apiSuccess, apiError } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email } = body;

    // Validate required fields
    if (!email) {
      return apiError('Email is required');
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return apiError('Invalid email format');
    }

    // Check if user exists
    const user = await db.user.findUnique({
      where: { email }
    });

    if (!user) {
      return apiError('No account found with this email');
    }

    // Rate limiting: Check if there's a recent OTP (within 1 minute)
    const recentOTP = await db.oTP.findFirst({
      where: {
        email,
        type: 'verification',
        createdAt: {
          gte: new Date(Date.now() - 60 * 1000) // 1 minute ago
        }
      }
    });

    if (recentOTP) {
      return apiError('Please wait before requesting another OTP');
    }

    // Create and store OTP
    const otp = await createOTP(email, 'verification');

    // In a real application, send email here
    // For now, we'll return the OTP in development
    console.log(`[DEV] OTP for ${email}: ${otp}`);

    // TODO: Send actual email with OTP
    // await sendOTPEmail(email, otp);

    return apiSuccess({ 
      message: 'OTP sent to your email',
      // Only return OTP in development
      ...(process.env.NODE_ENV === 'development' && { otp })
    });
  } catch (error) {
    console.error('Send OTP error:', error);
    return apiError('An error occurred while sending OTP', 500);
  }
}
