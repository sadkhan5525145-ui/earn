import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { verifyOTP, hashPassword, apiSuccess, apiError } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, code, newPassword } = body;

    // Validate required fields
    if (!email || !code || !newPassword) {
      return apiError('Email, OTP code, and new password are required');
    }

    // Validate password length
    if (newPassword.length < 6) {
      return apiError('Password must be at least 6 characters');
    }

    // Verify OTP
    const result = await verifyOTP(email, code, 'password_reset');
    
    if (!result.valid) {
      return apiError(result.error || 'Invalid OTP');
    }

    // Hash new password
    const passwordHash = await hashPassword(newPassword);

    // Update user password
    await db.user.update({
      where: { email },
      data: { passwordHash }
    });

    // Invalidate all existing sessions for this user (optional security measure)
    const user = await db.user.findUnique({
      where: { email },
      select: { id: true }
    });

    if (user) {
      await db.session.deleteMany({
        where: { userId: user.id }
      });
    }

    return apiSuccess({ message: 'Password reset successfully. Please login with your new password.' });
  } catch (error) {
    console.error('Reset password error:', error);
    return apiError('An error occurred during password reset', 500);
  }
}
