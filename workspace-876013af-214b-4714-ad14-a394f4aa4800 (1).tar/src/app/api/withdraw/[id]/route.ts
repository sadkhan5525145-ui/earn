import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/auth';
import { db } from '@/lib/db';

interface RouteParams {
  params: Promise<{ id: string }>;
}

/**
 * GET /api/withdraw/[id]
 * Get specific withdrawal status
 */
export async function GET(request: NextRequest, { params }: RouteParams) {
  try {
    const authResult = await requireAuth(request);
    
    if (authResult instanceof Response) {
      return authResult;
    }
    
    const user = authResult;
    const { id } = await params;
    
    const withdrawal = await db.withdrawal.findFirst({
      where: {
        id,
        userId: user.id, // Ensure user owns this withdrawal
      },
    });
    
    if (!withdrawal) {
      return NextResponse.json(
        { success: false, error: 'Withdrawal not found' },
        { status: 404 }
      );
    }
    
    // Get associated transaction
    const transaction = await db.transaction.findFirst({
      where: {
        userId: user.id,
        type: 'withdrawal',
        reference: withdrawal.id,
      },
    });
    
    return NextResponse.json({
      success: true,
      data: {
        withdrawal,
        transaction,
      },
    });
  } catch (error) {
    console.error('Withdrawal fetch error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch withdrawal' },
      { status: 500 }
    );
  }
}
