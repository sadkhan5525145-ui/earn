import { NextRequest, NextResponse } from 'next/server';
import { requireAuth, getAuthUser, pointsToRupees } from '@/lib/auth';
import { db } from '@/lib/db';
import { realtime } from '@/lib/realtime';

// Constants for withdrawal rules
const MIN_WITHDRAWAL_POINTS = 3000; // Minimum 3000 points (Rs. 300)
const MAX_WITHDRAWAL_POINTS = 50000; // Maximum 50000 points (Rs. 5000)
const MAX_WITHDRAWALS_PER_WEEK = 2;
const MIN_ACCOUNT_AGE_DAYS = 7;
const MIN_SPINS_REQUIRED = 10;

// Mobile number pattern for Pakistan (03xx-xxxxxxx)
const MOBILE_NUMBER_PATTERN = /^03\d{2}-?\d{7}$/;
// CNIC last 6 digits pattern
const CNIC_PATTERN = /^\d{6}$/;

interface WithdrawalRequestBody {
  method: 'easypaisa' | 'jazzcash' | 'bank';
  points: number;
  accountNumber: string;
  cnicLast6?: string;
  accountName?: string;
  bankName?: string;
}

/**
 * Validate withdrawal request body
 */
function validateWithdrawalRequest(body: WithdrawalRequestBody): { valid: boolean; error?: string } {
  // Validate method
  if (!['easypaisa', 'jazzcash', 'bank'].includes(body.method)) {
    return { valid: false, error: 'Invalid withdrawal method. Use easypaisa, jazzcash, or bank.' };
  }
  
  // Validate points
  if (!body.points || typeof body.points !== 'number' || body.points < MIN_WITHDRAWAL_POINTS) {
    return { valid: false, error: `Minimum withdrawal is ${MIN_WITHDRAWAL_POINTS} points (Rs. ${pointsToRupees(MIN_WITHDRAWAL_POINTS)}).` };
  }
  
  if (body.points > MAX_WITHDRAWAL_POINTS) {
    return { valid: false, error: `Maximum single withdrawal is ${MAX_WITHDRAWAL_POINTS} points (Rs. ${pointsToRupees(MAX_WITHDRAWAL_POINTS)}).` };
  }
  
  // Validate account number based on method
  if (body.method === 'easypaisa' || body.method === 'jazzcash') {
    // Remove dashes for validation
    const cleanNumber = body.accountNumber.replace(/-/g, '');
    if (!MOBILE_NUMBER_PATTERN.test(body.accountNumber) && !/^03\d{9}$/.test(cleanNumber)) {
      return { valid: false, error: 'Invalid mobile number format. Use 03xx-xxxxxxx or 03xxxxxxxxx format.' };
    }
    
    // Validate CNIC last 6 digits for mobile methods
    if (!body.cnicLast6 || !CNIC_PATTERN.test(body.cnicLast6)) {
      return { valid: false, error: 'CNIC last 6 digits are required for mobile wallet transfers.' };
    }
  }
  
  if (body.method === 'bank') {
    if (!body.accountNumber || body.accountNumber.length < 10) {
      return { valid: false, error: 'Invalid bank account number. Must be at least 10 digits.' };
    }
    if (!body.accountName || body.accountName.trim().length < 2) {
      return { valid: false, error: 'Account holder name is required for bank transfers.' };
    }
    if (!body.bankName || body.bankName.trim().length < 2) {
      return { valid: false, error: 'Bank name is required for bank transfers.' };
    }
  }
  
  return { valid: true };
}

/**
 * POST /api/withdraw
 * Submit a withdrawal request
 * 
 * Validates:
 * - Minimum 3000 points
 * - Maximum 2 withdrawals per week
 * - Minimum 7 days account age
 * - User has completed 10 spins
 */
export async function POST(request: NextRequest) {
  try {
    const authResult = await requireAuth(request);
    
    if (authResult instanceof Response) {
      return authResult;
    }
    
    const user = authResult;
    
    // Parse request body
    let body: WithdrawalRequestBody;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json(
        { success: false, error: 'Invalid request body' },
        { status: 400 }
      );
    }
    
    // Validate request body
    const validation = validateWithdrawalRequest(body);
    if (!validation.valid) {
      return NextResponse.json(
        { success: false, error: validation.error },
        { status: 400 }
      );
    }
    
    // Validate user has enough points
    if (user.pointsBalance < body.points) {
      return NextResponse.json(
        { success: false, error: `Insufficient points. You have ${user.pointsBalance} points.` },
        { status: 400 }
      );
    }
    
    // Validate account age (minimum 7 days)
    const accountAge = Date.now() - user.createdAt.getTime();
    const accountAgeDays = accountAge / (1000 * 60 * 60 * 24);
    if (accountAgeDays < MIN_ACCOUNT_AGE_DAYS) {
      const daysRemaining = Math.ceil(MIN_ACCOUNT_AGE_DAYS - accountAgeDays);
      return NextResponse.json(
        { success: false, error: `Account must be at least ${MIN_ACCOUNT_AGE_DAYS} days old. Please wait ${daysRemaining} more day(s).` },
        { status: 400 }
      );
    }
    
    // Validate minimum spins completed
    if (user.totalSpinsCompleted < MIN_SPINS_REQUIRED) {
      const spinsRemaining = MIN_SPINS_REQUIRED - user.totalSpinsCompleted;
      return NextResponse.json(
        { success: false, error: `Complete ${spinsRemaining} more spin(s) to enable withdrawals. Minimum ${MIN_SPINS_REQUIRED} spins required.` },
        { status: 400 }
      );
    }
    
    // Validate weekly withdrawal limit (max 2 per week)
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    
    const weeklyWithdrawals = await db.withdrawal.count({
      where: {
        userId: user.id,
        createdAt: {
          gte: oneWeekAgo,
        },
        status: {
          not: 'rejected', // Don't count rejected withdrawals
        },
      },
    });
    
    if (weeklyWithdrawals >= MAX_WITHDRAWALS_PER_WEEK) {
      return NextResponse.json(
        { success: false, error: `Maximum ${MAX_WITHDRAWALS_PER_WEEK} withdrawals per week allowed. Please try again later.` },
        { status: 400 }
      );
    }
    
    // Calculate Rs amount
    const rsAmount = pointsToRupees(body.points);
    
    // Create withdrawal and update user balance in a transaction
    const result = await db.$transaction(async (tx) => {
      // Deduct points from user
      const updatedUser = await tx.user.update({
        where: { id: user.id },
        data: {
          pointsBalance: { decrement: body.points },
        },
      });
      
      // Create withdrawal record
      const withdrawal = await tx.withdrawal.create({
        data: {
          userId: user.id,
          method: body.method,
          pointsRequested: body.points,
          rsAmount,
          accountNumber: body.accountNumber.replace(/-/g, ''), // Store clean number
          cnicLast6: body.cnicLast6 || null,
          accountName: body.accountName || null,
          status: 'pending',
        },
      });
      
      // Create transaction record
      await tx.transaction.create({
        data: {
          userId: user.id,
          type: 'withdrawal',
          points: -body.points,
          rsEquivalent: rsAmount,
          status: 'pending',
          reference: withdrawal.id,
          description: `Withdrawal request via ${body.method}`,
        },
      });
      
      return { withdrawal, updatedUser };
    });
    
    // Emit real-time events
    realtime.withdrawalRequest({
      withdrawalId: result.withdrawal.id,
      userId: user.id,
      userName: user.name,
      method: body.method,
      pointsRequested: body.points,
      rsAmount,
    });
    
    realtime.balanceUpdate({
      userId: user.id,
      pointsBalance: result.updatedUser.pointsBalance,
      rsEquivalent: result.updatedUser.pointsBalance * 0.1,
      change: -body.points,
      reason: 'Withdrawal request',
    });
    
    return NextResponse.json({
      success: true,
      data: {
        withdrawalId: result.withdrawal.id,
        points: body.points,
        rsAmount,
        status: 'pending',
        method: body.method,
      },
      message: `Withdrawal request submitted. You will receive Rs. ${rsAmount} within 1-3 days.`,
    });
  } catch (error) {
    console.error('Withdrawal request error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to process withdrawal request' },
      { status: 500 }
    );
  }
}

/**
 * GET /api/withdraw
 * Get user's withdrawal history
 */
export async function GET(request: NextRequest) {
  try {
    const authResult = await requireAuth(request);
    
    if (authResult instanceof Response) {
      return authResult;
    }
    
    const user = authResult;
    
    const { searchParams } = new URL(request.url);
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(50, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const status = searchParams.get('status') || undefined;
    
    const skip = (page - 1) * limit;
    
    // Build where clause
    const where: { userId: string; status?: string } = {
      userId: user.id,
    };
    
    if (status) {
      where.status = status;
    }
    
    // Get total count
    const totalCount = await db.withdrawal.count({ where });
    const totalPages = Math.ceil(totalCount / limit);
    
    // Get withdrawals
    const withdrawals = await db.withdrawal.findMany({
      where,
      orderBy: {
        createdAt: 'desc',
      },
      skip,
      take: limit,
    });
    
    return NextResponse.json({
      success: true,
      data: {
        withdrawals,
        pagination: {
          page,
          limit,
          totalCount,
          totalPages,
          hasMore: page < totalPages,
        },
      },
    });
  } catch (error) {
    console.error('Withdrawal history fetch error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch withdrawal history' },
      { status: 500 }
    );
  }
}
