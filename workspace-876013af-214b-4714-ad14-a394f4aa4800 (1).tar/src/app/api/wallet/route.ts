import { NextRequest, NextResponse } from 'next/server';
import { requireAuth, pointsToRupees } from '@/lib/auth';
import { db } from '@/lib/db';

const WITHDRAWAL_THRESHOLD = 3000; // Minimum points for withdrawal

/**
 * GET /api/wallet
 * Get wallet info including:
 * - pointsBalance
 * - rsEquivalent (100 pts = Rs. 10)
 * - totalEarned
 * - totalWithdrawn
 * - pendingWithdrawals (points currently pending)
 * - progress to 3000 pts threshold (percentage)
 */
export async function GET(request: NextRequest) {
  try {
    const authResult = await requireAuth(request);
    
    if (authResult instanceof Response) {
      return authResult;
    }
    
    const user = authResult;
    
    // Get pending withdrawals total
    const pendingWithdrawals = await db.withdrawal.aggregate({
      where: {
        userId: user.id,
        status: 'pending',
      },
      _sum: {
        pointsRequested: true,
      },
    });
    
    const pendingPoints = pendingWithdrawals._sum.pointsRequested || 0;
    const progressPercentage = Math.min(100, Math.round((user.pointsBalance / WITHDRAWAL_THRESHOLD) * 100));
    
    return NextResponse.json({
      success: true,
      data: {
        pointsBalance: user.pointsBalance,
        rsEquivalent: pointsToRupees(user.pointsBalance),
        totalEarned: user.totalPointsEarned,
        totalWithdrawn: user.totalPointsWithdrawn,
        pendingWithdrawals: pendingPoints,
        pendingWithdrawalsRs: pointsToRupees(pendingPoints),
        withdrawalThreshold: WITHDRAWAL_THRESHOLD,
        progressPercentage,
        canWithdraw: user.pointsBalance >= WITHDRAWAL_THRESHOLD,
      },
    });
  } catch (error) {
    console.error('Wallet fetch error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch wallet info' },
      { status: 500 }
    );
  }
}
