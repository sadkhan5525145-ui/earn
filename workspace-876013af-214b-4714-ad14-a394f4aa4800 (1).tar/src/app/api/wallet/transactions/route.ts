import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/auth';
import { db } from '@/lib/db';

const DEFAULT_PAGE_SIZE = 20;
const MAX_PAGE_SIZE = 50;

/**
 * GET /api/wallet/transactions
 * Get transaction history with pagination
 * 
 * Query params:
 * - page: page number (default 1)
 * - limit: items per page (default 20, max 50)
 * - type: filter by transaction type (optional)
 */
export async function GET(request: NextRequest) {
  try {
    const authResult = await requireAuth(request);
    
    if (authResult instanceof Response) {
      return authResult;
    }
    
    const user = authResult;
    
    const { searchParams } = new URL(request.url);
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(MAX_PAGE_SIZE, Math.max(1, parseInt(searchParams.get('limit') || String(DEFAULT_PAGE_SIZE), 10)));
    const type = searchParams.get('type') || undefined;
    
    const skip = (page - 1) * limit;
    
    // Build where clause
    const where: { userId: string; type?: string } = {
      userId: user.id,
    };
    
    if (type) {
      where.type = type;
    }
    
    // Get total count for pagination
    const totalCount = await db.transaction.count({ where });
    const totalPages = Math.ceil(totalCount / limit);
    
    // Get transactions
    const transactions = await db.transaction.findMany({
      where,
      orderBy: {
        createdAt: 'desc',
      },
      skip,
      take: limit,
    });
    
    return NextResponse.json({
      success: true,
      data: {
        transactions,
        pagination: {
          page,
          limit,
          totalCount,
          totalPages,
          hasMore: page < totalPages,
        },
      },
    });
  } catch (error) {
    console.error('Transactions fetch error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch transactions' },
      { status: 500 }
    );
  }
}
