import { NextRequest, NextResponse } from 'next/server';
import { NextRequest } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { db } from '@/lib/db';

/**
 * GET /api/referral/list
 * List all referred friends with their status
 * Query params: page, limit
 */
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser(request);

    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(50, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    // Get total count
    const totalCount = await db.referralRecord.count({
      where: {
        referrerId: user.id,
      },
    });
    const totalPages = Math.ceil(totalCount / limit);

    // Get referral records with referred user info
    const referrals = await db.referralRecord.findMany({
      where: {
        referrerId: user.id,
      },
      include: {
        referred: {
          select: {
            id: true,
            name: true,
            createdAt: true,
            totalSpinsCompleted: true,
            level: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
      skip,
      take: limit,
    });

    // Format the response
    const formattedReferrals = referrals.map(ref => {
      let statusText = 'Pending';
      let progress = 0;
      
      if (ref.status === 'rewarded') {
        statusText = 'Completed';
        progress = 100;
      } else if (ref.status === 'flagged') {
        statusText = 'Flagged';
        progress = 0;
      } else {
        // Pending - calculate progress towards 10 spins
        progress = Math.min(100, (ref.spinsCompletedByFriend / 10) * 100);
        statusText = ref.spinsCompletedByFriend >= 10 ? 'Ready to Reward' : `${ref.spinsCompletedByFriend}/10 spins`;
      }

      return {
        id: ref.id,
        friendId: ref.referred.id,
        friendName: ref.referred.name,
        friendLevel: ref.referred.level,
        spinsCompleted: ref.spinsCompletedByFriend,
        status: ref.status,
        statusText,
        progress,
        joinedAt: ref.referred.createdAt.toISOString(),
        createdAt: ref.createdAt.toISOString(),
        rewardedAt: ref.rewardTriggeredAt?.toISOString() || null,
      };
    });

    return NextResponse.json({
      success: true,
      data: {
        referrals: formattedReferrals,
        pagination: {
          page,
          limit,
          totalCount,
          totalPages,
          hasMore: page < totalPages,
        },
      },
    });
  } catch (error) {
    console.error('Get referral list error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to get referral list' },
      { status: 500 }
    );
  }
}
