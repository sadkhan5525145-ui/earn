import { NextResponse } from 'next/server';
import { NextRequest } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { db } from '@/lib/db';

/**
 * GET /api/referral/stats
 * Get referral statistics for current user
 * Returns: total referrals, points earned from referrals, pending rewards
 */
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser(request);

    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Get all referral records where user is the referrer
    const referralRecords = await db.referralRecord.findMany({
      where: {
        referrerId: user.id,
      },
      include: {
        referred: {
          select: {
            id: true,
            name: true,
            createdAt: true,
            totalSpinsCompleted: true,
          },
        },
      },
    });

    // Calculate statistics
    const totalReferrals = referralRecords.length;
    
    const rewardedReferrals = referralRecords.filter(r => r.status === 'rewarded');
    const pendingReferrals = referralRecords.filter(r => r.status === 'pending');
    const flaggedReferrals = referralRecords.filter(r => r.status === 'flagged');
    
    // Points earned from rewarded referrals
    const pointsEarned = rewardedReferrals.length * 500;
    
    // Pending rewards (referrals that are close to 10 spins but haven't completed yet)
    const pendingRewards = pendingReferrals
      .filter(r => r.spinsCompletedByFriend > 0)
      .map(r => ({
        friendName: r.referred.name,
        spinsCompleted: r.spinsCompletedByFriend,
        spinsRemaining: 10 - r.spinsCompletedByFriend,
      }));

    // Count friends who have completed 10+ spins but haven't been rewarded yet
    const readyToReward = pendingReferrals.filter(r => r.spinsCompletedByFriend >= 10).length;

    return NextResponse.json({
      success: true,
      data: {
        totalReferrals,
        rewardedCount: rewardedReferrals.length,
        pendingCount: pendingReferrals.length,
        flaggedCount: flaggedReferrals.length,
        pointsEarned,
        pointsPerReferral: 500,
        pendingRewards,
        readyToReward, // Friends who completed 10 spins but reward not yet processed
      },
    });
  } catch (error) {
    console.error('Get referral stats error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to get referral statistics' },
      { status: 500 }
    );
  }
}
