import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

interface ValidateRequestBody {
  code: string;
}

/**
 * POST /api/referral/validate
 * Validate a referral code during registration
 * Returns: valid status, referrer info (if valid)
 */
export async function POST(request: NextRequest) {
  try {
    let body: ValidateRequestBody;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json(
        { success: false, error: 'Invalid request body' },
        { status: 400 }
      );
    }

    const { code } = body;

    if (!code || typeof code !== 'string') {
      return NextResponse.json(
        { success: false, error: 'Referral code is required' },
        { status: 400 }
      );
    }

    // Normalize the code (uppercase, trim)
    const normalizedCode = code.trim().toUpperCase();

    // Validate format (SPIN####)
    if (!/^SPIN\d{4}$/.test(normalizedCode)) {
      return NextResponse.json({
        success: true,
        data: {
          valid: false,
          message: 'Invalid referral code format',
        },
      });
    }

    // Find the referrer
    const referrer = await db.user.findUnique({
      where: { referralCode: normalizedCode },
      select: {
        id: true,
        name: true,
        referralCode: true,
      },
    });

    if (!referrer) {
      return NextResponse.json({
        success: true,
        data: {
          valid: false,
          message: 'Referral code not found',
        },
      });
    }

    return NextResponse.json({
      success: true,
      data: {
        valid: true,
        referrer: {
          id: referrer.id,
          name: referrer.name,
          code: referrer.referralCode,
        },
        message: `Valid code! You'll receive 500 bonus points after completing 10 spins.`,
      },
    });
  } catch (error) {
    console.error('Validate referral code error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to validate referral code' },
      { status: 500 }
    );
  }
}
