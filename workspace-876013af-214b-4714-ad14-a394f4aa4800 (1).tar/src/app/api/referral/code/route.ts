import { NextResponse } from 'next/server';
import { NextRequest } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { db } from '@/lib/db';

/**
 * GET /api/referral/code
 * Get user's referral code and shareable link
 */
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser(request);

    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Generate shareable link
    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || 'https://spinwin.pk';
    const shareableLink = `${baseUrl}/register?ref=${user.referralCode}`;

    return NextResponse.json({
      success: true,
      data: {
        referralCode: user.referralCode,
        shareableLink,
        message: 'Share your link with friends! You both get 500 points when they complete 10 spins.',
      },
    });
  } catch (error) {
    console.error('Get referral code error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to get referral code' },
      { status: 500 }
    );
  }
}
