import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { db } from '@/lib/db';
import { realtime } from '@/lib/realtime';

interface RouteParams {
  params: Promise<{ id: string }>;
}

/**
 * POST /api/tasks/[id]/complete
 * Mark a task as complete and award points
 * 
 * Validates:
 * - Task exists and is active
 * - User hasn't already completed (considering task type)
 * - Awards points and XP
 * - Creates transaction record
 */
export async function POST(request: NextRequest, { params }: RouteParams) {
  try {
    const user = await getCurrentUser(request);

    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { id: taskId } = await params;

    // Find the task
    const task = await db.task.findUnique({
      where: { id: taskId },
    });

    if (!task) {
      // Try to find by taskId field
      const taskByTaskId = await db.task.findUnique({
        where: { taskId },
      });
      
      if (!taskByTaskId) {
        return NextResponse.json(
          { success: false, error: 'Task not found' },
          { status: 404 }
        );
      }
      
      // Use the found task
      return completeTask(user.id, taskByTaskId);
    }

    return completeTask(user.id, task);
  } catch (error) {
    console.error('Complete task error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to complete task' },
      { status: 500 }
    );
  }
}

async function completeTask(userId: string, task: {
  id: string;
  taskId: string;
  name: string;
  pointsReward: number;
  xpReward: number;
  type: string;
  isActive: boolean;
}) {
  if (!task.isActive) {
    return NextResponse.json(
      { success: false, error: 'This task is no longer available' },
      { status: 400 }
    );
  }

  // Check for existing completion based on task type
  const now = new Date();
  const pktOffset = 5 * 60 * 60 * 1000; // PKT is UTC+5
  const pktTime = new Date(now.getTime() + pktOffset);
  pktTime.setUTCHours(0, 0, 0, 0);
  const todayStart = new Date(pktTime.getTime() - pktOffset);

  // Get start of current week (Monday PKT midnight)
  const weekStart = new Date(todayStart);
  const dayOfWeek = weekStart.getUTCDay();
  const daysToMonday = dayOfWeek === 0 ? 6 : dayOfWeek - 1;
  weekStart.setUTCDate(weekStart.getUTCDate() - daysToMonday);

  // Check existing completions
  const existingCompletions = await db.taskCompletion.findMany({
    where: {
      userId,
      taskId: task.id,
    },
    orderBy: {
      completedAt: 'desc',
    },
  });

  // Validate based on task type
  if (task.type === 'onetime' && existingCompletions.length > 0) {
    return NextResponse.json(
      { success: false, error: 'You have already completed this one-time task' },
      { status: 400 }
    );
  }

  if (task.type === 'daily') {
    const todayCompletion = existingCompletions.find(
      c => c.completedAt >= todayStart
    );
    if (todayCompletion) {
      return NextResponse.json(
        { success: false, error: 'You have already completed this daily task today' },
        { status: 400 }
      );
    }
  }

  if (task.type === 'weekly') {
    const weekCompletion = existingCompletions.find(
      c => c.completedAt >= weekStart
    );
    if (weekCompletion) {
      return NextResponse.json(
        { success: false, error: 'You have already completed this weekly task this week' },
        { status: 400 }
      );
    }
  }

  // Complete the task in a transaction
  const result = await db.$transaction(async (tx) => {
    // Create task completion record
    const completion = await tx.taskCompletion.create({
      data: {
        userId,
        taskId: task.id,
        pointsAwarded: task.pointsReward,
        xpAwarded: task.xpReward,
      },
    });

    // Create transaction record
    await tx.transaction.create({
      data: {
        userId,
        type: 'task',
        points: task.pointsReward,
        rsEquivalent: task.pointsReward * 0.1,
        status: 'completed',
        reference: task.id,
        description: `Completed task: ${task.name}`,
      },
    });

    // Update user balance and XP
    const updatedUser = await tx.user.update({
      where: { id: userId },
      data: {
        pointsBalance: { increment: task.pointsReward },
        totalPointsEarned: { increment: task.pointsReward },
        xp: { increment: task.xpReward },
      },
    });

    return { completion, updatedUser };
  });

  // Emit real-time events
  realtime.taskCompleted({
    userId,
    taskId: task.id,
    taskName: task.name,
    pointsAwarded: task.pointsReward,
    xpAwarded: task.xpReward,
  });

  realtime.balanceUpdate({
    userId,
    pointsBalance: result.updatedUser.pointsBalance,
    rsEquivalent: result.updatedUser.pointsBalance * 0.1,
    change: task.pointsReward,
    reason: `Task: ${task.name}`,
  });

  return NextResponse.json({
    success: true,
    data: {
      taskId: task.id,
      taskName: task.name,
      pointsAwarded: task.pointsReward,
      xpAwarded: task.xpReward,
      newBalance: result.updatedUser.pointsBalance,
      newXp: result.updatedUser.xp,
      completedAt: result.completion.completedAt.toISOString(),
    },
    message: `Task completed! You earned ${task.pointsReward} points and ${task.xpReward} XP`,
  });
}
