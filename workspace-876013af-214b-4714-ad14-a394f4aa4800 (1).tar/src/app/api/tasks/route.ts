import { NextResponse } from 'next/server';
import { NextRequest } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { db } from '@/lib/db';

/**
 * GET /api/tasks
 * Get all tasks with completion status for current user
 * Returns tasks grouped by type (daily, onetime, weekly)
 */
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser(request);

    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Get all active tasks
    const tasks = await db.task.findMany({
      where: {
        isActive: true,
      },
      orderBy: [
        { type: 'asc' },
        { pointsReward: 'desc' },
      ],
    });

    // Get user's completed tasks
    const completedTasks = await db.taskCompletion.findMany({
      where: {
        userId: user.id,
      },
      select: {
        taskId: true,
        completedAt: true,
        pointsAwarded: true,
        xpAwarded: true,
      },
    });

    // Create a map of completed task IDs
    const completedMap = new Map(
      completedTasks.map(ct => [ct.taskId, ct])
    );

    // Get start of current day (PKT midnight)
    const now = new Date();
    const pktOffset = 5 * 60 * 60 * 1000; // PKT is UTC+5
    const pktTime = new Date(now.getTime() + pktOffset);
    pktTime.setUTCHours(0, 0, 0, 0);
    const todayStart = new Date(pktTime.getTime() - pktOffset);

    // Get start of current week (Monday PKT midnight)
    const weekStart = new Date(todayStart);
    const dayOfWeek = weekStart.getUTCDay();
    const daysToMonday = dayOfWeek === 0 ? 6 : dayOfWeek - 1;
    weekStart.setUTCDate(weekStart.getUTCDate() - daysToMonday);

    // Filter completed tasks for daily and weekly
    const dailyCompletedToday = completedTasks.filter(
      ct => ct.completedAt >= todayStart
    );
    const weeklyCompletedThisWeek = completedTasks.filter(
      ct => ct.completedAt >= weekStart
    );

    // Format tasks with completion status
    const formatTask = (task: typeof tasks[0]) => {
      const completion = completedMap.get(task.id);
      let isCompleted = !!completion;
      let canComplete = !completion;
      let completedAt = completion?.completedAt?.toISOString() || null;

      // For daily tasks, check if completed today
      if (task.type === 'daily') {
        const todayCompletion = dailyCompletedToday.find(
          ct => ct.taskId === task.id
        );
        isCompleted = !!todayCompletion;
        canComplete = !todayCompletion;
        completedAt = todayCompletion?.completedAt?.toISOString() || null;
      }

      // For weekly tasks, check if completed this week
      if (task.type === 'weekly') {
        const weekCompletion = weeklyCompletedThisWeek.find(
          ct => ct.taskId === task.id
        );
        isCompleted = !!weekCompletion;
        canComplete = !weekCompletion;
        completedAt = weekCompletion?.completedAt?.toISOString() || null;
      }

      return {
        id: task.id,
        taskId: task.taskId,
        name: task.name,
        description: task.description,
        pointsReward: task.pointsReward,
        xpReward: task.xpReward,
        type: task.type,
        category: task.category,
        link: task.link,
        isCompleted,
        canComplete,
        completedAt,
      };
    };

    // Group tasks by type
    const groupedTasks = {
      daily: tasks.filter(t => t.type === 'daily').map(formatTask),
      onetime: tasks.filter(t => t.type === 'onetime').map(formatTask),
      weekly: tasks.filter(t => t.type === 'weekly').map(formatTask),
    };

    // Calculate totals
    const totalAvailable = tasks.length;
    const totalCompleted = [
      ...groupedTasks.daily.filter(t => t.isCompleted),
      ...groupedTasks.onetime.filter(t => t.isCompleted),
      ...groupedTasks.weekly.filter(t => t.isCompleted),
    ].length;

    // Calculate potential points/xp from incomplete tasks
    const incompleteTasks = [
      ...groupedTasks.daily.filter(t => !t.isCompleted),
      ...groupedTasks.onetime.filter(t => !t.isCompleted),
      ...groupedTasks.weekly.filter(t => !t.isCompleted),
    ];
    const potentialPoints = incompleteTasks.reduce((sum, t) => sum + t.pointsReward, 0);
    const potentialXP = incompleteTasks.reduce((sum, t) => sum + t.xpReward, 0);

    return NextResponse.json({
      success: true,
      data: {
        tasks: groupedTasks,
        summary: {
          totalAvailable,
          totalCompleted,
          completionRate: totalAvailable > 0 
            ? Math.round((totalCompleted / totalAvailable) * 100) 
            : 0,
          potentialPoints,
          potentialXP,
        },
      },
    });
  } catch (error) {
    console.error('Get tasks error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to get tasks' },
      { status: 500 }
    );
  }
}
