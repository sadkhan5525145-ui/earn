import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { db } from '@/lib/db';
import { realtime } from '@/lib/realtime';

// Streak rewards: Day 1-7
const STREAK_REWARDS: Record<number, { points: number; xp: number }> = {
  1: { points: 50, xp: 5 },
  2: { points: 100, xp: 10 },
  3: { points: 150, xp: 15 },
  4: { points: 200, xp: 20 },
  5: { points: 300, xp: 30 },
  6: { points: 500, xp: 50 },
  7: { points: 1000, xp: 200 }, // Day 7 has bonus XP
};

// Get PKT midnight for a given date
function getPKTMidnight(date: Date): Date {
  const pktOffset = 5 * 60 * 60 * 1000; // PKT is UTC+5
  const pktTime = new Date(date.getTime() + pktOffset);
  pktTime.setUTCHours(0, 0, 0, 0);
  return new Date(pktTime.getTime() - pktOffset);
}

/**
 * GET /api/bonus
 * Check if daily bonus is available
 * Returns: canClaim, nextReward, streakDays, lastClaimDate
 */
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser(request);

    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const now = new Date();
    const todayMidnightPKT = getPKTMidnight(now);

    // Check if already claimed today
    const lastBonusClaim = user.lastBonusClaim;
    const canClaim = !lastBonusClaim || lastBonusClaim < todayMidnightPKT;

    // Calculate current streak
    let streakDays = user.streakDays;
    
    if (lastBonusClaim) {
      const yesterdayMidnightPKT = new Date(todayMidnightPKT);
      yesterdayMidnightPKT.setUTCDate(yesterdayMidnightPKT.getUTCDate() - 1);

      // If last claim was before yesterday, streak is broken
      if (lastBonusClaim < yesterdayMidnightPKT) {
        streakDays = 0;
      }
    }

    // Determine next reward
    const nextStreakDay = canClaim ? streakDays + 1 : streakDays;
    const cycleDay = ((nextStreakDay - 1) % 7) + 1; // 1-7 cycle
    const nextReward = STREAK_REWARDS[cycleDay] || STREAK_REWARDS[1];

    // Time until next claim (if already claimed today)
    let nextClaimIn = null;
    if (!canClaim) {
      const tomorrowMidnightPKT = new Date(todayMidnightPKT);
      tomorrowMidnightPKT.setUTCDate(tomorrowMidnightPKT.getUTCDate() + 1);
      nextClaimIn = tomorrowMidnightPKT.getTime() - now.getTime();
    }

    return NextResponse.json({
      success: true,
      data: {
        canClaim,
        streakDays,
        nextReward: {
          day: cycleDay,
          points: nextReward.points,
          xp: nextReward.xp,
        },
        lastClaimDate: lastBonusClaim?.toISOString() || null,
        nextClaimIn,
      },
    });
  } catch (error) {
    console.error('Get bonus status error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to get bonus status' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/bonus
 * Claim daily bonus
 * Awards points and XP based on streak
 * Streak cycle: 7 days, then resets to day 1
 */
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser(request);

    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const now = new Date();
    const todayMidnightPKT = getPKTMidnight(now);

    // Check if already claimed today
    const lastBonusClaim = user.lastBonusClaim;
    
    if (lastBonusClaim && lastBonusClaim >= todayMidnightPKT) {
      return NextResponse.json(
        { success: false, error: 'Daily bonus already claimed today. Come back tomorrow!' },
        { status: 400 }
      );
    }

    // Calculate new streak
    let newStreak = user.streakDays;
    
    if (lastBonusClaim) {
      const yesterdayMidnightPKT = new Date(todayMidnightPKT);
      yesterdayMidnightPKT.setUTCDate(yesterdayMidnightPKT.getUTCDate() - 1);

      // If last claim was yesterday or later, increment streak
      if (lastBonusClaim >= yesterdayMidnightPKT) {
        newStreak += 1;
      } else {
        // Streak broken, start over
        newStreak = 1;
      }
    } else {
      // First claim
      newStreak = 1;
    }

    // Get reward for current streak day (cycle 1-7)
    const cycleDay = ((newStreak - 1) % 7) + 1;
    const reward = STREAK_REWARDS[cycleDay] || STREAK_REWARDS[1];

    // Claim bonus in a transaction
    const result = await db.$transaction(async (tx) => {
      // Create transaction record
      await tx.transaction.create({
        data: {
          userId: user.id,
          type: 'daily_bonus',
          points: reward.points,
          rsEquivalent: reward.points * 0.1,
          status: 'completed',
          description: `Daily login bonus - Day ${cycleDay} streak${cycleDay === 7 ? ' (MAX!)' : ''}`,
        },
      });

      // Update user
      const updatedUser = await tx.user.update({
        where: { id: user.id },
        data: {
          pointsBalance: { increment: reward.points },
          totalPointsEarned: { increment: reward.points },
          xp: { increment: reward.xp },
          streakDays: newStreak,
          lastBonusClaim: now,
          lastLoginDate: now,
        },
      });

      return { updatedUser };
    });

    // Emit real-time events
    realtime.bonusClaimed({
      userId: user.id,
      pointsAwarded: reward.points,
      streakDays: newStreak,
    });

    realtime.balanceUpdate({
      userId: user.id,
      pointsBalance: result.updatedUser.pointsBalance,
      rsEquivalent: result.updatedUser.pointsBalance * 0.1,
      change: reward.points,
      reason: `Daily bonus - Day ${cycleDay}`,
    });

    // Check if completed 7-day streak
    const completedWeek = cycleDay === 7;
    const nextCycleDay = 1; // After day 7, resets to day 1

    return NextResponse.json({
      success: true,
      data: {
        streakDay: cycleDay,
        streakDays: newStreak,
        pointsAwarded: reward.points,
        xpAwarded: reward.xp,
        newBalance: result.updatedUser.pointsBalance,
        newXp: result.updatedUser.xp,
        completedWeek,
        nextReward: STREAK_REWARDS[nextCycleDay],
      },
      message: completedWeek
        ? `🎉 Amazing! You completed a 7-day streak! You earned ${reward.points} points and ${reward.xp} XP!`
        : `Day ${cycleDay} bonus claimed! You earned ${reward.points} points and ${reward.xp} XP`,
    });
  } catch (error) {
    console.error('Claim bonus error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to claim bonus' },
      { status: 500 }
    );
  }
}
