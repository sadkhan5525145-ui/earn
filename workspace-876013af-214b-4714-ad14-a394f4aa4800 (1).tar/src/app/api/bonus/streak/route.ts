import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { db } from '@/lib/db';

// Streak rewards: Day 1-7
const STREAK_REWARDS: Record<number, { points: number; xp: number }> = {
  1: { points: 50, xp: 5 },
  2: { points: 100, xp: 10 },
  3: { points: 150, xp: 15 },
  4: { points: 200, xp: 20 },
  5: { points: 300, xp: 30 },
  6: { points: 500, xp: 50 },
  7: { points: 1000, xp: 200 },
};

// Get PKT midnight for a given date
function getPKTMidnight(date: Date): Date {
  const pktOffset = 5 * 60 * 60 * 1000; // PKT is UTC+5
  const pktTime = new Date(date.getTime() + pktOffset);
  pktTime.setUTCHours(0, 0, 0, 0);
  return new Date(pktTime.getTime() - pktOffset);
}

/**
 * GET /api/bonus/streak
 * Get detailed streak information
 * Returns: current streak, cycle position, rewards history, next reward
 */
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser(request);

    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const now = new Date();
    const todayMidnightPKT = getPKTMidnight(now);
    const yesterdayMidnightPKT = new Date(todayMidnightPKT);
    yesterdayMidnightPKT.setUTCDate(yesterdayMidnightPKT.getUTCDate() - 1);

    // Determine streak status
    let currentStreak = user.streakDays;
    let streakBroken = false;
    let streakCanBeContinued = false;

    if (user.lastBonusClaim) {
      if (user.lastBonusClaim < yesterdayMidnightPKT) {
        // Streak is broken
        streakBroken = true;
        currentStreak = 0;
      } else if (user.lastBonusClaim >= yesterdayMidnightPKT && user.lastBonusClaim < todayMidnightPKT) {
        // Can still continue streak today
        streakCanBeContinued = true;
      }
    }

    // Current position in 7-day cycle
    const cyclePosition = currentStreak > 0 ? ((currentStreak - 1) % 7) + 1 : 0;
    const nextRewardDay = currentStreak > 0 ? (cyclePosition % 7) + 1 : 1;
    const nextReward = STREAK_REWARDS[nextRewardDay];

    // Get recent streak-related transactions
    const recentBonusTransactions = await db.transaction.findMany({
      where: {
        userId: user.id,
        type: 'daily_bonus',
      },
      orderBy: {
        createdAt: 'desc',
      },
      take: 14, // Last 2 weeks
      select: {
        points: true,
        description: true,
        createdAt: true,
      },
    });

    // Calculate total earned from streaks
    const totalFromStreaks = recentBonusTransactions.reduce((sum, t) => sum + t.points, 0);

    // Build streak calendar (last 7 days)
    const streakCalendar = [];
    for (let i = 6; i >= 0; i--) {
      const dayDate = new Date(todayMidnightPKT);
      dayDate.setUTCDate(dayDate.getUTCDate() - i);
      
      const dayEnd = new Date(dayDate);
      dayEnd.setUTCDate(dayEnd.getUTCDate() + 1);

      const claimed = recentBonusTransactions.some(t => {
        const claimDate = new Date(t.createdAt);
        return claimDate >= dayDate && claimDate < dayEnd;
      });

      const dayInCycle = i === 0 ? cyclePosition : 
        currentStreak > i ? ((currentStreak - i - 1) % 7) + 1 : 0;

      streakCalendar.push({
        date: dayDate.toISOString(),
        dayOfCycle: dayInCycle,
        claimed,
        reward: STREAK_REWARDS[dayInCycle] || null,
        isToday: i === 0,
      });
    }

    return NextResponse.json({
      success: true,
      data: {
        currentStreak,
        cyclePosition,
        streakBroken,
        streakCanBeContinued,
        nextReward: {
          day: nextRewardDay,
          points: nextReward.points,
          xp: nextReward.xp,
        },
        totalFromStreaks,
        streakCalendar,
        streakRewards: Object.entries(STREAK_REWARDS).map(([day, reward]) => ({
          day: parseInt(day),
          points: reward.points,
          xp: reward.xp,
          isMilestone: parseInt(day) === 7,
        })),
        recentClaims: recentBonusTransactions.slice(0, 7).map(t => ({
          points: t.points,
          description: t.description,
          claimedAt: t.createdAt.toISOString(),
        })),
      },
    });
  } catch (error) {
    console.error('Get streak info error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to get streak information' },
      { status: 500 }
    );
  }
}
