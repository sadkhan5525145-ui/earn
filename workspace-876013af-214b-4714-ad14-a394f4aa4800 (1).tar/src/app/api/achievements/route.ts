import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/auth';
import { db } from '@/lib/db';

/**
 * GET /api/achievements
 * Get all achievements with unlock status for the current user
 * 
 * Returns:
 * - achievements: List of all achievements with unlock status
 * - totalUnlocked: Count of unlocked achievements
 * - totalPoints: Total points from claimed achievements
 * - unclaimedPoints: Points available to claim
 */
export async function GET(request: NextRequest) {
  try {
    const authResult = await requireAuth(request);
    
    if (authResult instanceof Response) {
      return authResult;
    }
    
    const user = authResult;
    
    // Get all achievements
    const achievements = await db.achievement.findMany({
      orderBy: [
        { category: 'asc' },
        { pointsReward: 'asc' },
      ],
    });
    
    // Get user's unlocked achievements
    const userAchievements = await db.userAchievement.findMany({
      where: { userId: user.id },
      include: { achievement: true },
    });
    
    // Create a map for quick lookup
    const unlockedMap = new Map(
      userAchievements.map(ua => [ua.achievementId, ua])
    );
    
    // Combine achievements with unlock status
    const achievementsWithStatus = achievements.map(achievement => {
      const unlocked = unlockedMap.get(achievement.id);
      
      return {
        id: achievement.id,
        badgeId: achievement.badgeId,
        name: achievement.name,
        description: achievement.description,
        icon: achievement.icon,
        pointsReward: achievement.pointsReward,
        category: achievement.category,
        unlocked: !!unlocked,
        unlockedAt: unlocked?.unlockedAt || null,
        claimed: unlocked?.pointsClaimed || false,
      };
    });
    
    // Calculate stats
    const totalUnlocked = userAchievements.length;
    const totalPoints = userAchievements
      .filter(ua => ua.pointsClaimed)
      .reduce((sum, ua) => sum + ua.achievement.pointsReward, 0);
    const unclaimedPoints = userAchievements
      .filter(ua => !ua.pointsClaimed)
      .reduce((sum, ua) => sum + ua.achievement.pointsReward, 0);
    
    return NextResponse.json({
      success: true,
      data: {
        achievements: achievementsWithStatus,
        stats: {
          total: achievements.length,
          totalUnlocked,
          totalPoints,
          unclaimedPoints,
        },
      },
    });
  } catch (error) {
    console.error('Achievements fetch error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch achievements' },
      { status: 500 }
    );
  }
}
