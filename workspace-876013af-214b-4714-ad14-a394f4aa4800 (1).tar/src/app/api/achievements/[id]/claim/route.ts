import { NextRequest, NextResponse } from 'next/server';
import { requireAuth, pointsToRupees } from '@/lib/auth';
import { db } from '@/lib/db';

interface RouteParams {
  params: Promise<{ id: string }>;
}

/**
 * POST /api/achievements/[id]/claim
 * Claim the points reward for an unlocked achievement
 * 
 * Validates:
 * - Achievement exists
 * - User has unlocked the achievement
 * - Points haven't been claimed already
 * 
 * Returns:
 * - points: Points awarded
 * - rsEquivalent: Rs. value
 */
export async function POST(request: NextRequest, { params }: RouteParams) {
  try {
    const authResult = await requireAuth(request);
    
    if (authResult instanceof Response) {
      return authResult;
    }
    
    const user = authResult;
    const { id } = await params;
    
    // Get the achievement
    const achievement = await db.achievement.findUnique({
      where: { id },
    });
    
    if (!achievement) {
      return NextResponse.json(
        { success: false, error: 'Achievement not found' },
        { status: 404 }
      );
    }
    
    // Check if user has unlocked this achievement
    const userAchievement = await db.userAchievement.findUnique({
      where: {
        userId_achievementId: {
          userId: user.id,
          achievementId: achievement.id,
        },
      },
    });
    
    if (!userAchievement) {
      return NextResponse.json(
        { success: false, error: 'You have not unlocked this achievement yet' },
        { status: 400 }
      );
    }
    
    // Check if already claimed
    if (userAchievement.pointsClaimed) {
      return NextResponse.json(
        { success: false, error: 'Points for this achievement have already been claimed' },
        { status: 400 }
      );
    }
    
    // Claim the points in a transaction
    const result = await db.$transaction(async (tx) => {
      // Update user's balance
      const updatedUser = await tx.user.update({
        where: { id: user.id },
        data: {
          pointsBalance: { increment: achievement.pointsReward },
          totalPointsEarned: { increment: achievement.pointsReward },
        },
      });
      
      // Mark achievement as claimed
      await tx.userAchievement.update({
        where: { id: userAchievement.id },
        data: { pointsClaimed: true },
      });
      
      // Create transaction record
      await tx.transaction.create({
        data: {
          userId: user.id,
          type: 'achievement',
          points: achievement.pointsReward,
          rsEquivalent: pointsToRupees(achievement.pointsReward),
          status: 'completed',
          reference: achievement.id,
          description: `Achievement claimed: ${achievement.name}`,
        },
      });
      
      return { updatedUser };
    });
    
    return NextResponse.json({
      success: true,
      data: {
        achievementId: achievement.id,
        achievementName: achievement.name,
        points: achievement.pointsReward,
        rsEquivalent: pointsToRupees(achievement.pointsReward),
        newBalance: result.updatedUser.pointsBalance,
      },
      message: `You claimed ${achievement.pointsReward} points for "${achievement.name}"!`,
    });
  } catch (error) {
    console.error('Achievement claim error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to claim achievement' },
      { status: 500 }
    );
  }
}
