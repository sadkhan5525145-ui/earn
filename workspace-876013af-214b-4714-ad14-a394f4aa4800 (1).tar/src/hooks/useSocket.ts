'use client';

import { useEffect, useRef, useCallback, useState } from 'react';
import { io, Socket } from 'socket.io-client';

interface UseSocketOptions {
  userId?: string;
  isAdmin?: boolean;
  onConnect?: () => void;
  onDisconnect?: () => void;
}

interface SocketEvents {
  // Connection
  connected: (data: { socketId: string; serverTime: string }) => void;
  authenticated: (data: { success: boolean; userId: string; onlineUsers: number }) => void;
  'online-count': (data: { count: number }) => void;
  
  // Spin
  'spin:result': (data: { userId: string; pointsWon: number; xpEarned: number; newBalance: number; segmentIndex: number }) => void;
  'spin:jackpot': (data: { userId: string; pointsWon: number }) => void;
  
  // Wallet
  'wallet:balance': (data: { userId: string; pointsBalance: number; rsEquivalent: number; change: number; reason: string }) => void;
  
  // Withdrawal
  'withdrawal:status': (data: { withdrawalId: string; userId: string; status: string; adminNote?: string; processedAt?: string }) => void;
  
  // Tasks
  'task:completed': (data: { userId: string; taskId: string; taskName: string; pointsAwarded: number; xpAwarded: number }) => void;
  'tasks:refresh': (data: { action: string; task: any }) => void;
  
  // Leaderboard
  'leaderboard:update': (data: { leaderboard: any[] }) => void;
  
  // Achievement
  'achievement:unlocked': (data: { userId: string; achievementId: string; achievementName: string; pointsReward: number; icon: string }) => void;
  'achievement:rare': (data: any) => void;
  
  // Level
  'level:up': (data: { userId: string; newLevel: number; levelName: string; rewards: any }) => void;
  'level:milestone': (data: any) => void;
  
  // Referral
  'referral:new': (data: { referrerId: string; referredName: string; status: string }) => void;
  'referral:rewarded': (data: { referrerId: string; referredName: string; pointsEarned: number }) => void;
  
  // Bonus
  'bonus:claimed': (data: { userId: string; pointsAwarded: number; streakDays: number }) => void;
  
  // Notifications
  announcement: (data: { message: string; type: string; from: string; timestamp: string }) => void;
  notification: (data: { userId: string; title: string; message: string; type: string; data?: any }) => void;
  
  // Account
  'account:deleted': (data: { reason: string }) => void;
  'account:updated': (data: any) => void;
  
  // Admin
  'admin:withdrawal:new': (data: any) => void;
  'admin:stats': (data: any) => void;
}

export function useSocket(options: UseSocketOptions = {}) {
  const { userId, isAdmin = false, onConnect, onDisconnect } = options;
  const socketRef = useRef<Socket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [onlineUsers, setOnlineUsers] = useState(0);
  const authenticatedRef = useRef(false);

  // Connect to socket server
  useEffect(() => {
    // Only connect on client side
    if (typeof window === 'undefined') return;
    
    // Prevent multiple connections
    if (socketRef.current?.connected) return;

    const socketInstance = io('/?XTransformPort=3003', {
      transports: ['websocket', 'polling'],
      forceNew: true,
      reconnection: true,
      reconnectionAttempts: 10,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
      timeout: 20000,
    });

    socketRef.current = socketInstance;

    socketInstance.on('connect', () => {
      console.log('[Socket] Connected');
      setIsConnected(true);
      onConnect?.();
    });

    socketInstance.on('disconnect', () => {
      console.log('[Socket] Disconnected');
      setIsConnected(false);
      authenticatedRef.current = false;
      onDisconnect?.();
    });

    socketInstance.on('connect_error', (error) => {
      console.error('[Socket] Connection error:', error.message);
    });

    socketInstance.on('online-count', (data: { count: number }) => {
      setOnlineUsers(data.count);
    });

    return () => {
      if (socketRef.current) {
        socketRef.current.disconnect();
        socketRef.current = null;
      }
    };
  }, [onConnect, onDisconnect]);

  // Authenticate when userId is available
  useEffect(() => {
    if (socketRef.current && isConnected && userId && !authenticatedRef.current) {
      console.log('[Socket] Authenticating user:', userId);
      socketRef.current.emit('authenticate', { userId, isAdmin });
      authenticatedRef.current = true;
    }
  }, [userId, isAdmin, isConnected]);

  // Subscribe to events
  const subscribe = useCallback(<K extends keyof SocketEvents>(
    event: K,
    callback: SocketEvents[K]
  ) => {
    if (!socketRef.current) return () => {};
    
    socketRef.current.on(event, callback as any);
    
    return () => {
      socketRef.current?.off(event, callback as any);
    };
  }, []);

  // Emit events
  const emit = useCallback(<K extends keyof SocketEvents>(
    event: K,
    data: any
  ) => {
    if (socketRef.current && isConnected) {
      socketRef.current.emit(event, data);
    }
  }, [isConnected]);

  // Convenience methods for common events
  const notifyWithdrawalRequest = useCallback((data: {
    withdrawalId: string;
    userId: string;
    userName: string;
    method: string;
    pointsRequested: number;
    rsAmount: number;
  }) => {
    emit('withdrawal-request', { ...data, createdAt: new Date().toISOString() });
  }, [emit]);

  const notifyWithdrawalUpdate = useCallback((data: {
    withdrawalId: string;
    userId: string;
    status: string;
    adminNote?: string;
  }) => {
    emit('withdrawal-update', { ...data, processedAt: new Date().toISOString() });
  }, [emit]);

  const notifyBalanceUpdate = useCallback((data: {
    userId: string;
    pointsBalance: number;
    rsEquivalent: number;
    change: number;
    reason: string;
  }) => {
    emit('balance-update', data);
  }, [emit]);

  const notifyTaskCompleted = useCallback((data: {
    userId: string;
    taskId: string;
    taskName: string;
    pointsAwarded: number;
    xpAwarded: number;
  }) => {
    emit('task-completed', data);
  }, [emit]);

  const notifyTaskUpdated = useCallback((data: {
    action: 'created' | 'updated' | 'deleted' | 'toggled';
    task: any;
  }) => {
    emit('task-updated', data);
  }, [emit]);

  const notifyAchievementUnlocked = useCallback((data: {
    userId: string;
    achievementId: string;
    achievementName: string;
    pointsReward: number;
    icon: string;
  }) => {
    emit('achievement-unlocked', data);
  }, [emit]);

  const notifyLevelUp = useCallback((data: {
    userId: string;
    newLevel: number;
    levelName: string;
    rewards: any;
  }) => {
    emit('level-up', data);
  }, [emit]);

  const notifySpinResult = useCallback((data: {
    userId: string;
    pointsWon: number;
    xpEarned: number;
    newBalance: number;
    segmentIndex: number;
  }) => {
    emit('spin-result', data);
  }, [emit]);

  const sendAnnouncement = useCallback((data: {
    message: string;
    type: 'info' | 'warning' | 'success' | 'error';
    from: string;
  }) => {
    emit('announcement', { ...data, timestamp: new Date().toISOString() });
  }, [emit]);

  const sendNotification = useCallback((data: {
    userId: string;
    title: string;
    message: string;
    type: string;
    data?: any;
  }) => {
    emit('notification', data);
  }, [emit]);

  const notifyReferralNew = useCallback((data: {
    referrerId: string;
    referredName: string;
    status: string;
  }) => {
    emit('referral-new', data);
  }, [emit]);

  const notifyReferralRewarded = useCallback((data: {
    referrerId: string;
    referredName: string;
    pointsEarned: number;
  }) => {
    emit('referral-rewarded', data);
  }, [emit]);

  const notifyBonusClaimed = useCallback((data: {
    userId: string;
    pointsAwarded: number;
    streakDays: number;
  }) => {
    emit('bonus-claimed', data);
  }, [emit]);

  const notifyLeaderboardUpdate = useCallback((data: {
    leaderboard: any[];
  }) => {
    emit('leaderboard-update', data);
  }, [emit]);

  return {
    isConnected,
    onlineUsers,
    subscribe,
    emit,
    // Convenience methods
    notifyWithdrawalRequest,
    notifyWithdrawalUpdate,
    notifyBalanceUpdate,
    notifyTaskCompleted,
    notifyTaskUpdated,
    notifyAchievementUnlocked,
    notifyLevelUp,
    notifySpinResult,
    sendAnnouncement,
    sendNotification,
    notifyReferralNew,
    notifyReferralRewarded,
    notifyBonusClaimed,
    notifyLeaderboardUpdate,
  };
}
