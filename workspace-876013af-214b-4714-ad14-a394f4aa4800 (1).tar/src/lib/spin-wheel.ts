// Spin Wheel Configuration
// 12 segments with weighted probabilities and rewards

export interface WheelSegment {
  index: number
  label: string
  points: number
  weight: number
  color: string
  isJackpot: boolean
}

// Wheel segments configuration
export const WHEEL_SEGMENTS: WheelSegment[] = [
  { index: 0, label: '50', points: 50, weight: 8.3, color: 'green', isJackpot: false },
  { index: 1, label: '100', points: 100, weight: 8.3, color: 'gold', isJackpot: false },
  { index: 2, label: 'Try Again', points: 0, weight: 8.3, color: 'dark', isJackpot: false },
  { index: 3, label: '150', points: 150, weight: 8.3, color: 'green', isJackpot: false },
  { index: 4, label: '300', points: 300, weight: 8.3, color: 'orange', isJackpot: false },
  { index: 5, label: 'Try Again', points: 0, weight: 8.3, color: 'dark', isJackpot: false },
  { index: 6, label: 'JACKPOT', points: 500, weight: 8.3, color: 'bright-gold', isJackpot: true },
  { index: 7, label: '50', points: 50, weight: 8.3, color: 'teal', isJackpot: false },
  { index: 8, label: '100', points: 100, weight: 8.3, color: 'gold', isJackpot: false },
  { index: 9, label: '200', points: 200, weight: 8.3, color: 'orange', isJackpot: false },
  { index: 10, label: 'Try Again', points: 0, weight: 8.3, color: 'dark', isJackpot: false },
  { index: 11, label: '75', points: 75, weight: 8.3, color: 'teal', isJackpot: false },
]

// XP awarded based on points won
export function calculateXP(pointsWon: number): number {
  let xp = 5 // Base XP
  
  if (pointsWon >= 500) {
    xp += 50 // Jackpot bonus
  } else if (pointsWon >= 150) {
    xp += 15 // Medium win bonus
  } else if (pointsWon >= 50) {
    xp += 5 // Small win bonus
  }
  
  return xp
}

// Server-side weighted random selection
export function spinWheel(): WheelSegment {
  // Calculate total weight
  const totalWeight = WHEEL_SEGMENTS.reduce((sum, seg) => sum + seg.weight, 0)
  
  // Generate random number between 0 and total weight
  const random = Math.random() * totalWeight
  
  // Find the segment
  let cumulative = 0
  for (const segment of WHEEL_SEGMENTS) {
    cumulative += segment.weight
    if (random <= cumulative) {
      return segment
    }
  }
  
  // Fallback to last segment (should never reach here)
  return WHEEL_SEGMENTS[WHEEL_SEGMENTS.length - 1]
}

// Level-based daily spins configuration
export const LEVEL_SPINS: Record<number, number> = {
  0: 5,   // Bronze
  1: 6,   // Silver
  2: 7,   // Gold
  3: 8,   // Platinum
  4: 10,  // Diamond
  5: 12,  // Master
  6: 15,  // Legend
  7: 999, // Grandmaster (unlimited)
}

// Get spins for a level
export function getSpinsForLevel(level: number): number {
  return LEVEL_SPINS[level] ?? 5
}

// Level names for display
export const LEVEL_NAMES: Record<number, string> = {
  0: 'Bronze',
  1: 'Silver',
  2: 'Gold',
  3: 'Platinum',
  4: 'Diamond',
  5: 'Master',
  6: 'Legend',
  7: 'Grandmaster',
}

// XP required for each level (cumulative)
export const XP_LEVEL_THRESHOLDS: Record<number, number> = {
  0: 0,      // Bronze
  1: 100,    // Silver
  2: 300,    // Gold
  3: 600,    // Platinum
  4: 1000,   // Diamond
  5: 2000,   // Master
  6: 4000,   // Legend
  7: 8000,   // Grandmaster
}

// Calculate level from XP
export function calculateLevelFromXP(xp: number): number {
  let level = 0
  for (const [lvl, threshold] of Object.entries(XP_LEVEL_THRESHOLDS)) {
    if (xp >= threshold) {
      level = parseInt(lvl)
    }
  }
  return level
}

// Get PKT (Pakistan Standard Time) midnight for a given date
export function getPKTMidnight(date: Date): Date {
  // PKT is UTC+5
  const pktOffset = 5 * 60 * 60 * 1000 // 5 hours in milliseconds
  
  // Get current time in PKT
  const pktTime = new Date(date.getTime() + pktOffset)
  
  // Set to midnight PKT
  const pktMidnight = new Date(pktTime)
  pktMidnight.setUTCHours(0, 0, 0, 0)
  
  // Convert back to UTC
  return new Date(pktMidnight.getTime() - pktOffset)
}

// Check if reset is needed (last reset was before today's PKT midnight)
export function needsDailyReset(lastReset: Date | null): boolean {
  if (!lastReset) return true
  
  const now = new Date()
  const todayMidnightPKT = getPKTMidnight(now)
  
  return lastReset < todayMidnightPKT
}

// Generate spin result message
export function getSpinMessage(pointsWon: number, isJackpot: boolean): string {
  if (isJackpot) {
    return `JACKPOT! You won ${pointsWon} points!`
  }
  
  if (pointsWon === 0) {
    return 'Try Again! Better luck next spin!'
  }
  
  return `You won ${pointsWon} points!`
}
