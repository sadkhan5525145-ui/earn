import { db } from './db';
import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcrypt';
import { v4 as uuidv4 } from 'uuid';

const SESSION_COOKIE_NAME = 'session_token';
const SESSION_DURATION_DAYS = 7;
const SALT_ROUNDS = 10;

// Generate a unique referral code in SPIN#### format
export function generateReferralCode(): string {
  const digits = Math.floor(1000 + Math.random() * 9000);
  return `SPIN${digits}`;
}

// Ensure unique referral code
export async function getUniqueReferralCode(): Promise<string> {
  let code = generateReferralCode();
  let attempts = 0;
  
  while (attempts < 100) {
    const existing = await db.user.findUnique({
      where: { referralCode: code }
    });
    
    if (!existing) return code;
    
    code = generateReferralCode();
    attempts++;
  }
  
  // Fallback with timestamp
  return `SPIN${Date.now().toString().slice(-4)}`;
}

// Hash password
export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, SALT_ROUNDS);
}

// Verify password
export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

// Create session
export async function createSession(userId: string): Promise<string> {
  const token = uuidv4();
  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + SESSION_DURATION_DAYS);
  
  await db.session.create({
    data: {
      userId,
      token,
      expiresAt
    }
  });
  
  return token;
}

// Get user from session token
export async function getUserFromToken(token: string) {
  if (!token) return null;
  
  const session = await db.session.findUnique({
    where: { token },
    include: { user: true }
  });
  
  if (!session) return null;
  
  if (session.expiresAt < new Date()) {
    // Session expired, delete it
    await db.session.delete({ where: { id: session.id } });
    return null;
  }
  
  return session.user;
}

// Get session token from request (cookie or header)
export function getSessionToken(request: NextRequest): string | null {
  // Try cookie first
  const cookieToken = request.cookies.get(SESSION_COOKIE_NAME)?.value;
  if (cookieToken) return cookieToken;
  
  // Try Authorization header
  const authHeader = request.headers.get('authorization');
  if (authHeader?.startsWith('Bearer ')) {
    return authHeader.slice(7);
  }
  
  return null;
}

// Get current user from request
export async function getCurrentUser(request: NextRequest) {
  const token = getSessionToken(request);
  if (!token) return null;
  
  return getUserFromToken(token);
}

// Invalidate session
export async function invalidateSession(token: string): Promise<void> {
  await db.session.deleteMany({
    where: { token }
  });
}

// Set session cookie
export function setSessionCookie(response: NextResponse, token: string): void {
  response.cookies.set(SESSION_COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: SESSION_DURATION_DAYS * 24 * 60 * 60,
    path: '/'
  });
}

// Clear session cookie
export function clearSessionCookie(response: NextResponse): void {
  response.cookies.delete(SESSION_COOKIE_NAME);
}

// Generate 4-digit OTP
export function generateOTP(): string {
  return Math.floor(1000 + Math.random() * 9000).toString();
}

// Create OTP record
export async function createOTP(email: string, type: string): Promise<string> {
  const code = generateOTP();
  const expiresAt = new Date();
  expiresAt.setMinutes(expiresAt.getMinutes() + 10); // 10 minutes expiry
  
  await db.oTP.create({
    data: {
      email,
      code,
      type,
      expiresAt
    }
  });
  
  return code;
}

// Verify OTP
export async function verifyOTP(email: string, code: string, type: string): Promise<{ valid: boolean; error?: string }> {
  const otp = await db.oTP.findFirst({
    where: {
      email,
      type,
      used: false
    },
    orderBy: { createdAt: 'desc' }
  });
  
  if (!otp) {
    return { valid: false, error: 'OTP not found' };
  }
  
  // Check attempts
  if (otp.attempts >= 5) {
    return { valid: false, error: 'Too many attempts. Please request a new OTP.' };
  }
  
  // Check expiry
  if (otp.expiresAt < new Date()) {
    return { valid: false, error: 'OTP has expired. Please request a new one.' };
  }
  
  // Check code
  if (otp.code !== code) {
    // Increment attempts
    await db.oTP.update({
      where: { id: otp.id },
      data: { attempts: otp.attempts + 1 }
    });
    return { valid: false, error: 'Invalid OTP code' };
  }
  
  // Mark as used
  await db.oTP.update({
    where: { id: otp.id },
    data: { used: true }
  });
  
  return { valid: true };
}

// Require authentication - returns user or 401 response
export async function requireAuth(request: NextRequest) {
  const user = await getCurrentUser(request);
  
  if (!user) {
    return NextResponse.json(
      { success: false, error: 'Authentication required' },
      { status: 401 }
    );
  }
  
  return user;
}

// Get authenticated user (alias for getCurrentUser)
export async function getAuthUser(request: NextRequest) {
  return getCurrentUser(request);
}

// Require admin role - returns user or 403 response
export async function requireAdmin(request: NextRequest) {
  const user = await getCurrentUser(request);
  
  if (!user) {
    return NextResponse.json(
      { success: false, error: 'Authentication required' },
      { status: 401 }
    );
  }
  
  if (!user.isAdmin) {
    return NextResponse.json(
      { success: false, error: 'Admin access required' },
      { status: 403 }
    );
  }
  
  return user;
}

// Standard API response helpers
export function apiSuccess(data: unknown, status = 200) {
  return NextResponse.json({ success: true, data }, { status });
}

export function apiError(message: string, status = 400) {
  return NextResponse.json({ success: false, message }, { status });
}

// Sanitize user data (remove sensitive fields)
export function sanitizeUser(user: {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  passwordHash: string | null;
  authProvider: string;
  isVerified: boolean;
  isAdmin: boolean;
  referralCode: string;
  referredBy: string | null;
  level: number;
  xp: number;
  pointsBalance: number;
  totalPointsEarned: number;
  totalPointsWithdrawn: number;
  dailySpinsRemaining: number;
  lastSpinReset: Date | null;
  totalSpinsCompleted: number;
  streakDays: number;
  lastLoginDate: Date | null;
  lastBonusClaim: Date | null;
  cnicLast6: string | null;
  easypaisaNumber: string | null;
  jazzcashNumber: string | null;
  bankAccountNumber: string | null;
  bankName: string | null;
  createdAt: Date;
  updatedAt: Date;
}) {
  const { passwordHash: _passwordHash, ...userWithoutPassword } = user;
  return userWithoutPassword;
}

// Points to Rupees conversion (100 points = Rs. 10)
export function pointsToRupees(points: number): number {
  return points * 0.1;
}

// Rupees to Points conversion
export function rupeesToPoints(rupees: number): number {
  return Math.floor(rupees * 10);
}
