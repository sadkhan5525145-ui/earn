/**
 * Real-time event emitter for API routes
 * This helper allows server-side code to emit WebSocket events
 */

import { io } from 'socket.io-client';

// Socket client for server-side emissions
let socketClient: ReturnType<typeof io> | null = null;

function getSocketClient() {
  if (!socketClient || !socketClient.connected) {
    socketClient = io('http://localhost:3003', {
      transports: ['websocket'],
      reconnection: true,
      reconnectionAttempts: 5,
    });
  }
  return socketClient;
}

// Event types
interface SpinResultEvent {
  userId: string;
  pointsWon: number;
  xpEarned: number;
  newBalance: number;
  segmentIndex: number;
}

interface BalanceUpdateEvent {
  userId: string;
  pointsBalance: number;
  rsEquivalent: number;
  change: number;
  reason: string;
}

interface WithdrawalRequestEvent {
  withdrawalId: string;
  userId: string;
  userName: string;
  method: string;
  pointsRequested: number;
  rsAmount: number;
}

interface WithdrawalUpdateEvent {
  withdrawalId: string;
  userId: string;
  status: string;
  adminNote?: string;
}

interface TaskCompletedEvent {
  userId: string;
  taskId: string;
  taskName: string;
  pointsAwarded: number;
  xpAwarded: number;
}

interface TaskUpdatedEvent {
  action: 'created' | 'updated' | 'deleted' | 'toggled';
  task: any;
}

interface AchievementUnlockedEvent {
  userId: string;
  achievementId: string;
  achievementName: string;
  pointsReward: number;
  icon: string;
}

interface LevelUpEvent {
  userId: string;
  newLevel: number;
  levelName: string;
  rewards: any;
}

interface ReferralNewEvent {
  referrerId: string;
  referredName: string;
  status: string;
}

interface ReferralRewardedEvent {
  referrerId: string;
  referredName: string;
  pointsEarned: number;
}

interface BonusClaimedEvent {
  userId: string;
  pointsAwarded: number;
  streakDays: number;
}

interface LeaderboardUpdateEvent {
  leaderboard: any[];
}

interface AnnouncementEvent {
  message: string;
  type: 'info' | 'warning' | 'success' | 'error';
  from: string;
}

interface NotificationEvent {
  userId: string;
  title: string;
  message: string;
  type: string;
  data?: any;
}

// Emit functions
export const realtime = {
  spinResult: (data: SpinResultEvent) => {
    try {
      const socket = getSocketClient();
      socket.emit('spin-result', data);
    } catch (e) {
      console.error('[Realtime] Failed to emit spin-result:', e);
    }
  },

  balanceUpdate: (data: BalanceUpdateEvent) => {
    try {
      const socket = getSocketClient();
      socket.emit('balance-update', data);
    } catch (e) {
      console.error('[Realtime] Failed to emit balance-update:', e);
    }
  },

  withdrawalRequest: (data: WithdrawalRequestEvent) => {
    try {
      const socket = getSocketClient();
      socket.emit('withdrawal-request', { ...data, createdAt: new Date().toISOString() });
    } catch (e) {
      console.error('[Realtime] Failed to emit withdrawal-request:', e);
    }
  },

  withdrawalUpdate: (data: WithdrawalUpdateEvent) => {
    try {
      const socket = getSocketClient();
      socket.emit('withdrawal-update', { ...data, processedAt: new Date().toISOString() });
    } catch (e) {
      console.error('[Realtime] Failed to emit withdrawal-update:', e);
    }
  },

  taskCompleted: (data: TaskCompletedEvent) => {
    try {
      const socket = getSocketClient();
      socket.emit('task-completed', data);
    } catch (e) {
      console.error('[Realtime] Failed to emit task-completed:', e);
    }
  },

  taskUpdated: (data: TaskUpdatedEvent) => {
    try {
      const socket = getSocketClient();
      socket.emit('task-updated', data);
    } catch (e) {
      console.error('[Realtime] Failed to emit task-updated:', e);
    }
  },

  achievementUnlocked: (data: AchievementUnlockedEvent) => {
    try {
      const socket = getSocketClient();
      socket.emit('achievement-unlocked', data);
    } catch (e) {
      console.error('[Realtime] Failed to emit achievement-unlocked:', e);
    }
  },

  levelUp: (data: LevelUpEvent) => {
    try {
      const socket = getSocketClient();
      socket.emit('level-up', data);
    } catch (e) {
      console.error('[Realtime] Failed to emit level-up:', e);
    }
  },

  referralNew: (data: ReferralNewEvent) => {
    try {
      const socket = getSocketClient();
      socket.emit('referral-new', data);
    } catch (e) {
      console.error('[Realtime] Failed to emit referral-new:', e);
    }
  },

  referralRewarded: (data: ReferralRewardedEvent) => {
    try {
      const socket = getSocketClient();
      socket.emit('referral-rewarded', data);
    } catch (e) {
      console.error('[Realtime] Failed to emit referral-rewarded:', e);
    }
  },

  bonusClaimed: (data: BonusClaimedEvent) => {
    try {
      const socket = getSocketClient();
      socket.emit('bonus-claimed', data);
    } catch (e) {
      console.error('[Realtime] Failed to emit bonus-claimed:', e);
    }
  },

  leaderboardUpdate: (data: LeaderboardUpdateEvent) => {
    try {
      const socket = getSocketClient();
      socket.emit('leaderboard-update', data);
    } catch (e) {
      console.error('[Realtime] Failed to emit leaderboard-update:', e);
    }
  },

  announcement: (data: AnnouncementEvent) => {
    try {
      const socket = getSocketClient();
      socket.emit('announcement', { ...data, timestamp: new Date().toISOString() });
    } catch (e) {
      console.error('[Realtime] Failed to emit announcement:', e);
    }
  },

  notification: (data: NotificationEvent) => {
    try {
      const socket = getSocketClient();
      socket.emit('notification', data);
    } catch (e) {
      console.error('[Realtime] Failed to emit notification:', e);
    }
  },
};

export default realtime;
