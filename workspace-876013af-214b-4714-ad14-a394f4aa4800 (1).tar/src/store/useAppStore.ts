import { create } from 'zustand';

// User type based on database schema
export interface User {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  authProvider: string;
  isVerified: boolean;
  isAdmin: boolean;
  referralCode: string;
  referredBy: string | null;
  level: number;
  xp: number;
  pointsBalance: number;
  totalPointsEarned: number;
  totalPointsWithdrawn: number;
  dailySpinsRemaining: number;
  lastSpinReset: string | null;
  totalSpinsCompleted: number;
  streakDays: number;
  lastLoginDate: string | null;
  lastBonusClaim: string | null;
  cnicLast6: string | null;
  easypaisaNumber: string | null;
  jazzcashNumber: string | null;
  bankAccountNumber: string | null;
  bankName: string | null;
  createdAt: string;
  updatedAt: string;
}

// View/Tab types
export type ViewType = 'home' | 'spin' | 'wallet' | 'tasks' | 'referral' | 'achievements' | 'leaderboard' | 'profile' | 'admin';

// Achievement type
export interface Achievement {
  id: string;
  badgeId: string;
  name: string;
  description: string;
  icon: string;
  pointsReward: number;
  condition: string;
  category: string;
  unlocked?: boolean;
  unlockedAt?: string;
  pointsClaimed?: boolean;
}

// Task type
export interface Task {
  id: string;
  taskId: string;
  name: string;
  description: string;
  pointsReward: number;
  xpReward: number;
  type: 'daily' | 'onetime' | 'weekly';
  category: string;
  link: string | null;
  isActive: boolean;
  completed?: boolean;
  completedAt?: string;
}

// Transaction type
export interface Transaction {
  id: string;
  type: string;
  points: number;
  rsEquivalent: number;
  status: string;
  description: string | null;
  createdAt: string;
}

// Withdrawal type
export interface Withdrawal {
  id: string;
  method: string;
  pointsRequested: number;
  rsAmount: number;
  accountNumber: string;
  status: string;
  adminNote: string | null;
  createdAt: string;
  processedAt: string | null;
}

// Spin result type
export interface SpinResult {
  segmentIndex: number;
  pointsWon: number;
  xpEarned: number;
  remainingSpins: number;
  newBalance: number;
  newLevel?: number;
  levelUp?: boolean;
  achievements?: Achievement[];
}

// Referral stats
export interface ReferralStats {
  totalReferrals: number;
  pendingRewards: number;
  rewardedReferrals: number;
  totalPointsEarned: number;
}

// Leaderboard entry
export interface LeaderboardEntry {
  rank: number;
  userId: string;
  name: string;
  level: number;
  pointsEarned: number;
  isCurrentUser?: boolean;
}

// App State
interface AppState {
  // Auth
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  
  // View
  currentView: ViewType;
  
  // Spin
  spinsRemaining: number;
  isSpinning: boolean;
  lastSpinResult: SpinResult | null;
  spinHistory: SpinResult[];
  
  // Wallet
  walletInfo: {
    pointsBalance: number;
    rsEquivalent: number;
    totalEarned: number;
    totalWithdrawn: number;
    pendingWithdrawals: number;
    progressPercentage: number;
    canWithdraw: boolean;
  } | null;
  transactions: Transaction[];
  
  // Withdrawals
  withdrawals: Withdrawal[];
  
  // Tasks
  tasks: Task[];
  
  // Achievements
  achievements: Achievement[];
  
  // Referral
  referralCode: string;
  referralStats: ReferralStats | null;
  referredFriends: Array<{
    id: string;
    name: string;
    spinsCompleted: number;
    status: string;
    createdAt: string;
  }>;
  
  // Leaderboard
  leaderboard: LeaderboardEntry[];
  userRank: { rank: number; percentile: number } | null;
  
  // Streak
  streakInfo: {
    currentStreak: number;
    nextReward: number;
    canClaimBonus: boolean;
    lastClaimDate: string | null;
  } | null;
  
  // Level
  levelInfo: {
    currentLevel: number;
    levelName: string;
    currentXP: number;
    nextLevelXP: number;
    xpProgress: number;
    dailySpins: number;
    perks: string[];
  } | null;
  
  // Admin
  adminWithdrawals: Withdrawal[];
  
  // Actions
  setUser: (user: User | null) => void;
  setLoading: (loading: boolean) => void;
  setCurrentView: (view: ViewType) => void;
  setSpinsRemaining: (spins: number) => void;
  setIsSpinning: (spinning: boolean) => void;
  setLastSpinResult: (result: SpinResult | null) => void;
  setWalletInfo: (info: AppState['walletInfo']) => void;
  setTransactions: (transactions: Transaction[]) => void;
  setWithdrawals: (withdrawals: Withdrawal[]) => void;
  setTasks: (tasks: Task[]) => void;
  setAchievements: (achievements: Achievement[]) => void;
  setReferralCode: (code: string) => void;
  setReferralStats: (stats: ReferralStats | null) => void;
  setReferredFriends: (friends: AppState['referredFriends']) => void;
  setLeaderboard: (entries: LeaderboardEntry[]) => void;
  setUserRank: (rank: AppState['userRank']) => void;
  setStreakInfo: (info: AppState['streakInfo']) => void;
  setLevelInfo: (info: AppState['levelInfo']) => void;
  setAdminWithdrawals: (withdrawals: Withdrawal[]) => void;
  
  // Fetch functions
  fetchUser: () => Promise<void>;
  fetchWallet: () => Promise<void>;
  fetchSpinStatus: () => Promise<void>;
  fetchTasks: () => Promise<void>;
  fetchAchievements: () => Promise<void>;
  fetchReferralData: () => Promise<void>;
  fetchLeaderboard: () => Promise<void>;
  fetchStreakInfo: () => Promise<void>;
  fetchLevelInfo: () => Promise<void>;
  fetchAdminWithdrawals: () => Promise<void>;
  fetchWithdrawals: () => Promise<void>;
  
  // Auth functions
  login: (email: string, password: string) => Promise<{ success: boolean; message?: string }>;
  register: (data: { name: string; email: string; phone: string; password: string; referralCode?: string }) => Promise<{ success: boolean; message?: string }>;
  logout: () => Promise<void>;
  
  // Spin function
  spin: () => Promise<SpinResult | null>;
  
  // Task function
  completeTask: (taskId: string) => Promise<{ success: boolean; points: number; message?: string }>;
  
  // Bonus function
  claimBonus: () => Promise<{ success: boolean; points: number; streak: number; message?: string }>;
  
  // Withdrawal function
  requestWithdrawal: (data: { method: string; points: number; accountNumber: string; cnicLast6?: string; accountName?: string; bankName?: string }) => Promise<{ success: boolean; message?: string }>;
  
  // Admin functions
  approveWithdrawal: (id: string) => Promise<{ success: boolean; message?: string }>;
  rejectWithdrawal: (id: string, note: string) => Promise<{ success: boolean; message?: string }>;
  
  // Reset
  reset: () => void;
}

// Initial state
const initialState = {
  user: null,
  isLoading: true,
  isAuthenticated: false,
  currentView: 'home' as ViewType,
  spinsRemaining: 0,
  isSpinning: false,
  lastSpinResult: null,
  spinHistory: [],
  walletInfo: null,
  transactions: [],
  withdrawals: [],
  tasks: [],
  achievements: [],
  referralCode: '',
  referralStats: null,
  referredFriends: [],
  leaderboard: [],
  userRank: null,
  streakInfo: null,
  levelInfo: null,
  adminWithdrawals: [],
};

// API helper
async function apiFetch(endpoint: string, options: RequestInit = {}) {
  const response = await fetch(endpoint, {
    ...options,
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
  });
  return response.json();
}

// Create store
export const useAppStore = create<AppState>((set, get) => ({
  ...initialState,
  
  // Setters
  setUser: (user) => set({ user, isAuthenticated: !!user, isLoading: false }),
  setLoading: (loading) => set({ isLoading: loading }),
  setCurrentView: (view) => set({ currentView: view }),
  setSpinsRemaining: (spins) => set({ spinsRemaining: spins }),
  setIsSpinning: (spinning) => set({ isSpinning: spinning }),
  setLastSpinResult: (result) => set({ lastSpinResult: result }),
  setWalletInfo: (info) => set({ walletInfo: info }),
  setTransactions: (transactions) => set({ transactions }),
  setWithdrawals: (withdrawals) => set({ withdrawals }),
  setTasks: (tasks) => set({ tasks }),
  setAchievements: (achievements) => set({ achievements }),
  setReferralCode: (code) => set({ referralCode: code }),
  setReferralStats: (stats) => set({ referralStats: stats }),
  setReferredFriends: (friends) => set({ referredFriends: friends }),
  setLeaderboard: (entries) => set({ leaderboard: entries }),
  setUserRank: (rank) => set({ userRank: rank }),
  setStreakInfo: (info) => set({ streakInfo: info }),
  setLevelInfo: (info) => set({ levelInfo: info }),
  setAdminWithdrawals: (withdrawals) => set({ adminWithdrawals: withdrawals }),
  
  // Fetch functions
  fetchUser: async () => {
    try {
      const res = await apiFetch('/api/auth/me');
      if (res.success && res.data?.user) {
        set({ user: res.data.user, isAuthenticated: true, isLoading: false });
      } else {
        set({ user: null, isAuthenticated: false, isLoading: false });
      }
    } catch {
      set({ user: null, isAuthenticated: false, isLoading: false });
    }
  },
  
  fetchWallet: async () => {
    try {
      const res = await apiFetch('/api/wallet');
      if (res.success && res.data) {
        set({ walletInfo: res.data });
      }
    } catch (error) {
      console.error('Failed to fetch wallet:', error);
    }
  },
  
  fetchSpinStatus: async () => {
    try {
      const res = await apiFetch('/api/spin');
      if (res.success && res.data) {
        set({ 
          spinsRemaining: res.data.remainingSpins,
          spinHistory: res.data.lastSpins || []
        });
      }
    } catch (error) {
      console.error('Failed to fetch spin status:', error);
    }
  },
  
  fetchTasks: async () => {
    try {
      const res = await apiFetch('/api/tasks');
      if (res.success && res.data?.tasks) {
        // Flatten tasks from grouped format and map isCompleted to completed
        const { daily = [], onetime = [], weekly = [] } = res.data.tasks;
        const allTasks = [...daily, ...onetime, ...weekly].map((t: { isCompleted?: boolean; completed?: boolean }) => ({
          ...t,
          completed: t.isCompleted || t.completed || false
        }));
        set({ tasks: allTasks });
      }
    } catch (error) {
      console.error('Failed to fetch tasks:', error);
    }
  },
  
  fetchAchievements: async () => {
    try {
      const res = await apiFetch('/api/achievements');
      if (res.success && res.data) {
        set({ achievements: res.data.achievements });
      }
    } catch (error) {
      console.error('Failed to fetch achievements:', error);
    }
  },
  
  fetchReferralData: async () => {
    try {
      const [codeRes, statsRes, listRes] = await Promise.all([
        apiFetch('/api/referral/code'),
        apiFetch('/api/referral/stats'),
        apiFetch('/api/referral/list')
      ]);
      
      if (codeRes.success) set({ referralCode: codeRes.data?.code || '' });
      if (statsRes.success) set({ referralStats: statsRes.data });
      if (listRes.success) set({ referredFriends: listRes.data?.friends || [] });
    } catch (error) {
      console.error('Failed to fetch referral data:', error);
    }
  },
  
  fetchLeaderboard: async () => {
    try {
      const [lbRes, rankRes] = await Promise.all([
        apiFetch('/api/leaderboard/weekly'),
        apiFetch('/api/leaderboard/rank')
      ]);
      
      if (lbRes.success) set({ leaderboard: lbRes.data?.leaderboard || [] });
      if (rankRes.success) set({ userRank: rankRes.data });
    } catch (error) {
      console.error('Failed to fetch leaderboard:', error);
    }
  },
  
  fetchStreakInfo: async () => {
    try {
      const [bonusRes, streakRes] = await Promise.all([
        apiFetch('/api/bonus'),
        apiFetch('/api/bonus/streak')
      ]);
      
      if (bonusRes.success && bonusRes.data) {
        set({ 
          streakInfo: {
            currentStreak: bonusRes.data.streakDays || 0,
            nextReward: bonusRes.data.nextReward?.points || 50,
            canClaimBonus: bonusRes.data.canClaim || false,
            lastClaimDate: bonusRes.data.lastClaimDate || null,
          }
        });
      }
    } catch (error) {
      console.error('Failed to fetch streak info:', error);
    }
  },
  
  fetchLevelInfo: async () => {
    try {
      const res = await apiFetch('/api/level');
      if (res.success && res.data) {
        set({ levelInfo: res.data });
      }
    } catch (error) {
      console.error('Failed to fetch level info:', error);
    }
  },
  
  fetchAdminWithdrawals: async () => {
    try {
      const res = await apiFetch('/api/admin/withdrawals');
      if (res.success && res.data) {
        set({ adminWithdrawals: res.data.withdrawals || [] });
      }
    } catch (error) {
      console.error('Failed to fetch admin withdrawals:', error);
    }
  },
  
  fetchWithdrawals: async () => {
    try {
      const res = await apiFetch('/api/withdraw');
      if (res.success && res.data) {
        set({ withdrawals: res.data.withdrawals || [] });
      }
    } catch (error) {
      console.error('Failed to fetch withdrawals:', error);
    }
  },
  
  // Auth functions
  login: async (email, password) => {
    try {
      const res = await apiFetch('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password }),
      });
      
      if (res.success && res.data?.user) {
        set({ user: res.data.user, isAuthenticated: true, isLoading: false });
        return { success: true };
      }
      return { success: false, message: res.message || 'Login failed' };
    } catch {
      return { success: false, message: 'An error occurred' };
    }
  },
  
  register: async (data) => {
    try {
      const res = await apiFetch('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify(data),
      });
      
      if (res.success && res.data?.user) {
        set({ user: res.data.user, isAuthenticated: true, isLoading: false });
        return { success: true };
      }
      return { success: false, message: res.message || 'Registration failed' };
    } catch {
      return { success: false, message: 'An error occurred' };
    }
  },
  
  logout: async () => {
    try {
      await apiFetch('/api/auth/logout', { method: 'POST' });
    } finally {
      get().reset();
    }
  },
  
  // Spin function
  spin: async () => {
    const { isSpinning } = get();
    if (isSpinning) return null;
    
    set({ isSpinning: true });
    
    try {
      const res = await apiFetch('/api/spin', { method: 'POST' });
      
      if (res.success && res.data) {
        const result = res.data as SpinResult;
        set({ 
          lastSpinResult: result,
          spinsRemaining: result.remainingSpins,
        });
        
        // Update user balance
        const { user, walletInfo } = get();
        if (user) {
          set({ 
            user: { ...user, pointsBalance: result.newBalance }
          });
        }
        if (walletInfo) {
          set({
            walletInfo: {
              ...walletInfo,
              balance: result.newBalance,
              rsEquivalent: result.newBalance * 0.1
            }
          });
        }
        
        return result;
      }
      return null;
    } catch (error) {
      console.error('Spin failed:', error);
      return null;
    } finally {
      set({ isSpinning: false });
    }
  },
  
  // Task function
  completeTask: async (taskId) => {
    try {
      const res = await apiFetch(`/api/tasks/${taskId}/complete`, { method: 'POST' });
      
      if (res.success) {
        // Refresh tasks and wallet
        get().fetchTasks();
        get().fetchWallet();
        return { success: true, points: res.data?.pointsAwarded || 0 };
      }
      return { success: false, message: res.message || 'Task completion failed' };
    } catch (error) {
      return { success: false, message: 'An error occurred' };
    }
  },
  
  // Bonus function
  claimBonus: async () => {
    try {
      const res = await apiFetch('/api/bonus', { method: 'POST' });
      
      if (res.success && res.data) {
        // Refresh streak and wallet
        get().fetchStreakInfo();
        get().fetchWallet();
        return { 
          success: true, 
          points: res.data.pointsAwarded,
          streak: res.data.streak
        };
      }
      return { success: false, message: res.message || 'Bonus claim failed' };
    } catch (error) {
      return { success: false, message: 'An error occurred' };
    }
  },
  
  // Withdrawal function
  requestWithdrawal: async (data) => {
    try {
      const res = await apiFetch('/api/withdraw', {
        method: 'POST',
        body: JSON.stringify(data),
      });
      
      if (res.success) {
        get().fetchWallet();
        return { success: true };
      }
      return { success: false, message: res.message || 'Withdrawal request failed' };
    } catch (error) {
      return { success: false, message: 'An error occurred' };
    }
  },
  
  // Admin functions
  approveWithdrawal: async (id) => {
    try {
      const res = await apiFetch(`/api/admin/withdrawals/${id}/approve`, { method: 'POST' });
      
      if (res.success) {
        get().fetchAdminWithdrawals();
        return { success: true };
      }
      return { success: false, message: res.message || 'Approval failed' };
    } catch (error) {
      return { success: false, message: 'An error occurred' };
    }
  },
  
  rejectWithdrawal: async (id, note) => {
    try {
      const res = await apiFetch(`/api/admin/withdrawals/${id}/reject`, {
        method: 'POST',
        body: JSON.stringify({ note }),
      });
      
      if (res.success) {
        get().fetchAdminWithdrawals();
        return { success: true };
      }
      return { success: false, message: res.message || 'Rejection failed' };
    } catch (error) {
      return { success: false, message: 'An error occurred' };
    }
  },
  
  // Reset
  reset: () => set(initialState),
}));
