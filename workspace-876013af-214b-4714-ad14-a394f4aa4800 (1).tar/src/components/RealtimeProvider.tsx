'use client';

import { useEffect, useRef, createContext, useContext, ReactNode, useCallback } from 'react';
import { useSocket } from '@/hooks/useSocket';
import { useAppStore } from '@/store/useAppStore';
import { useToast } from '@/hooks/use-toast';
import { X, CheckCircle, AlertCircle, Info, Trophy, Gift, TrendingUp, Users, Bell } from 'lucide-react';

interface RealtimeContextType {
  isConnected: boolean;
  onlineUsers: number;
  notifyWithdrawalRequest: (data: any) => void;
  notifyWithdrawalUpdate: (data: any) => void;
  notifyBalanceUpdate: (data: any) => void;
  notifyTaskCompleted: (data: any) => void;
  notifyTaskUpdated: (data: any) => void;
  notifyAchievementUnlocked: (data: any) => void;
  notifyLevelUp: (data: any) => void;
  notifySpinResult: (data: any) => void;
  sendAnnouncement: (data: any) => void;
  sendNotification: (data: any) => void;
  notifyReferralNew: (data: any) => void;
  notifyReferralRewarded: (data: any) => void;
  notifyBonusClaimed: (data: any) => void;
  notifyLeaderboardUpdate: (data: any) => void;
}

const RealtimeContext = createContext<RealtimeContextType | null>(null);

export function useRealtime() {
  const context = useContext(RealtimeContext);
  if (!context) {
    throw new Error('useRealtime must be used within RealtimeProvider');
  }
  return context;
}

interface RealtimeProviderProps {
  children: ReactNode;
}

export function RealtimeProvider({ children }: RealtimeProviderProps) {
  const { user, isAuthenticated, setWalletInfo, setTasks, setLeaderboard, setAchievements, fetchWallet, fetchTasks, fetchLeaderboard, fetchAchievements, fetchAdminWithdrawals } = useAppStore();
  const { toast } = useToast();
  const previousOnlineUsers = useRef(0);

  const {
    isConnected,
    onlineUsers,
    subscribe,
    notifyWithdrawalRequest,
    notifyWithdrawalUpdate,
    notifyBalanceUpdate,
    notifyTaskCompleted,
    notifyTaskUpdated,
    notifyAchievementUnlocked,
    notifyLevelUp,
    notifySpinResult,
    sendAnnouncement,
    sendNotification,
    notifyReferralNew,
    notifyReferralRewarded,
    notifyBonusClaimed,
    notifyLeaderboardUpdate,
  } = useSocket({
    userId: user?.id,
    isAdmin: user?.isAdmin,
    onConnect: () => {
      console.log('[Realtime] Connected to server');
    },
    onDisconnect: () => {
      console.log('[Realtime] Disconnected from server');
    },
  });

  // Show toast notification
  const showToast = useCallback((
    title: string,
    message: string,
    type: 'success' | 'error' | 'info' | 'warning' = 'info',
    icon?: React.ReactNode
  ) => {
    toast({
      title: (
        <div className="flex items-center gap-2">
          {icon}
          <span>{title}</span>
        </div>
      ),
      description: message,
      className: type === 'success' ? 'border-primary' : type === 'error' ? 'border-destructive' : '',
    });
  }, [toast]);

  // Subscribe to all real-time events
  useEffect(() => {
    if (!isAuthenticated || !user) return;

    const unsubscribers: (() => void)[] = [];

    // Wallet balance update
    unsubscribers.push(subscribe('wallet:balance', (data) => {
      if (data.userId === user.id) {
        setWalletInfo({
          pointsBalance: data.pointsBalance,
          rsEquivalent: data.rsEquivalent,
          totalEarned: data.pointsBalance,
          totalWithdrawn: 0,
          pendingWithdrawals: 0,
          progressPercentage: (data.pointsBalance / 3000) * 100,
          canWithdraw: data.pointsBalance >= 3000,
        });
        
        if (data.change > 0) {
          showToast(
            'Points Earned!',
            `+${data.change} points - ${data.reason}`,
            'success',
            <Gift className="h-4 w-4 text-primary" />
          );
        }
      }
    }));

    // Spin result
    unsubscribers.push(subscribe('spin:result', (data) => {
      if (data.userId === user.id && data.pointsWon > 0) {
        showToast(
          'Spin Result!',
          `You won ${data.pointsWon} points!`,
          'success',
          <Trophy className="h-4 w-4 text-amber-500" />
        );
      }
    }));

    // Jackpot announcement
    unsubscribers.push(subscribe('spin:jackpot', (data) => {
      if (data.userId !== user.id) {
        showToast(
          'Jackpot!',
          `Someone just won ${data.pointsWon} points!`,
          'info',
          <Trophy className="h-4 w-4 text-amber-500" />
        );
      }
    }));

    // Task completed
    unsubscribers.push(subscribe('task:completed', (data) => {
      if (data.userId === user.id) {
        showToast(
          'Task Completed!',
          `${data.taskName}: +${data.pointsAwarded} points`,
          'success',
          <CheckCircle className="h-4 w-4 text-primary" />
        );
        fetchTasks();
        fetchWallet();
      }
    }));

    // Tasks refresh (admin updated tasks)
    unsubscribers.push(subscribe('tasks:refresh', (data) => {
      if (user.id) {
        fetchTasks();
        showToast(
          'Tasks Updated',
          `A task has been ${data.action}`,
          'info',
          <Bell className="h-4 w-4" />
        );
      }
    }));

    // Withdrawal status update
    unsubscribers.push(subscribe('withdrawal:status', (data) => {
      if (data.userId === user.id) {
        const isSuccess = data.status === 'processed' || data.status === 'approved';
        showToast(
          isSuccess ? 'Withdrawal Approved!' : 'Withdrawal Update',
          data.adminNote || `Your withdrawal has been ${data.status}`,
          isSuccess ? 'success' : 'warning',
          isSuccess ? <CheckCircle className="h-4 w-4 text-primary" /> : <AlertCircle className="h-4 w-4 text-amber-500" />
        );
        fetchWallet();
      }
    }));

    // Achievement unlocked
    unsubscribers.push(subscribe('achievement:unlocked', (data) => {
      if (data.userId === user.id) {
        showToast(
          'Achievement Unlocked!',
          `${data.icon} ${data.achievementName} - +${data.pointsReward} points`,
          'success',
          <Trophy className="h-4 w-4 text-amber-500" />
        );
        fetchAchievements();
      }
    }));

    // Level up
    unsubscribers.push(subscribe('level:up', (data) => {
      if (data.userId === user.id) {
        showToast(
          'Level Up!',
          `You reached ${data.levelName}! New perks unlocked.`,
          'success',
          <TrendingUp className="h-4 w-4 text-primary" />
        );
        fetchWallet();
      }
    }));

    // Referral new
    unsubscribers.push(subscribe('referral:new', (data) => {
      if (data.referrerId === user.id) {
        showToast(
          'New Referral!',
          `${data.referredName} joined using your code!`,
          'success',
          <Users className="h-4 w-4 text-primary" />
        );
      }
    }));

    // Referral rewarded
    unsubscribers.push(subscribe('referral:rewarded', (data) => {
      if (data.referrerId === user.id) {
        showToast(
          'Referral Reward!',
          `You earned ${data.pointsEarned} points from referral!`,
          'success',
          <Gift className="h-4 w-4 text-primary" />
        );
        fetchWallet();
      }
    }));

    // Bonus claimed
    unsubscribers.push(subscribe('bonus:claimed', (data) => {
      if (data.userId === user.id) {
        showToast(
          'Daily Bonus!',
          `+${data.pointsAwarded} points (Streak: ${data.streakDays} days)`,
          'success',
          <Gift className="h-4 w-4 text-primary" />
        );
        fetchWallet();
      }
    }));

    // Leaderboard update
    unsubscribers.push(subscribe('leaderboard:update', (data) => {
      setLeaderboard(data.leaderboard);
    }));

    // Admin: new withdrawal request
    if (user.isAdmin) {
      unsubscribers.push(subscribe('admin:withdrawal:new', (data) => {
        showToast(
          'New Withdrawal Request',
          `${data.userName} requested Rs. ${data.rsAmount} via ${data.method}`,
          'info',
          <Bell className="h-4 w-4" />
        );
        fetchAdminWithdrawals();
      }));
    }

    // Global announcement
    unsubscribers.push(subscribe('announcement', (data) => {
      const IconMap = {
        info: <Info className="h-4 w-4" />,
        success: <CheckCircle className="h-4 w-4 text-primary" />,
        warning: <AlertCircle className="h-4 w-4 text-amber-500" />,
        error: <X className="h-4 w-4 text-destructive" />,
      };
      showToast(
        'Announcement',
        data.message,
        data.type as any,
        IconMap[data.type as keyof typeof IconMap] || <Bell className="h-4 w-4" />
      );
    }));

    // Personal notification
    unsubscribers.push(subscribe('notification', (data) => {
      if (data.userId === user.id) {
        showToast(data.title, data.message, data.type as any);
      }
    }));

    // Account deleted by admin
    unsubscribers.push(subscribe('account:deleted', (data) => {
      showToast(
        'Account Deleted',
        data.reason,
        'error',
        <AlertCircle className="h-4 w-4 text-destructive" />
      );
      // Force logout
      useAppStore.getState().logout();
    }));

    // Cleanup
    return () => {
      unsubscribers.forEach(unsub => unsub());
    };
  }, [
    isAuthenticated, 
    user, 
    subscribe, 
    showToast, 
    setWalletInfo, 
    setTasks, 
    setLeaderboard,
    fetchWallet,
    fetchTasks,
    fetchLeaderboard,
    fetchAchievements,
    fetchAdminWithdrawals,
  ]);

  // Online users indicator
  useEffect(() => {
    if (onlineUsers !== previousOnlineUsers.current && onlineUsers > 0) {
      previousOnlineUsers.current = onlineUsers;
    }
  }, [onlineUsers]);

  const value: RealtimeContextType = {
    isConnected,
    onlineUsers,
    notifyWithdrawalRequest,
    notifyWithdrawalUpdate,
    notifyBalanceUpdate,
    notifyTaskCompleted,
    notifyTaskUpdated,
    notifyAchievementUnlocked,
    notifyLevelUp,
    notifySpinResult,
    sendAnnouncement,
    sendNotification,
    notifyReferralNew,
    notifyReferralRewarded,
    notifyBonusClaimed,
    notifyLeaderboardUpdate,
  };

  return (
    <RealtimeContext.Provider value={value}>
      {children}
    </RealtimeContext.Provider>
  );
}
