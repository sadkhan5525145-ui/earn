'use client';

import { RealtimeProvider } from '@/components/RealtimeProvider';

export function ClientProviders({ children }: { children: React.ReactNode }) {
  return (
    <RealtimeProvider>
      {children}
    </RealtimeProvider>
  );
}
