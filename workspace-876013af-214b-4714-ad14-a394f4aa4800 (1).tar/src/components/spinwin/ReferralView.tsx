'use client';

import { useEffect } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Users, Copy, Share2, Gift, Clock, CheckCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function ReferralView() {
  const { 
    referralCode, 
    referralStats,
    referredFriends,
    fetchReferralData
  } = useAppStore();
  const { toast } = useToast();
  
  useEffect(() => {
    fetchReferralData();
  }, [fetchReferralData]);
  
  const shareLink = `https://spinwin.pk?ref=${referralCode}`;
  const shareText = `🎮 Join SpinWin and earn real cash! Use my referral code ${referralCode} to get 500 bonus points. Spin the wheel, complete tasks, and withdraw to Easypaisa! 🎰💰`;
  
  const handleCopyCode = () => {
    navigator.clipboard.writeText(referralCode);
    toast({
      title: "Code Copied!",
      description: `Referral code ${referralCode} copied to clipboard`,
    });
  };
  
  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareLink);
    toast({
      title: "Link Copied!",
      description: "Referral link copied to clipboard",
    });
  };
  
  const handleShareWhatsApp = () => {
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(shareText + '\n\n' + shareLink)}`;
    window.open(whatsappUrl, '_blank');
  };
  
  return (
    <div className="max-w-lg mx-auto space-y-4">
      {/* Referral Code Card */}
      <Card className="bg-gradient-to-br from-primary to-accent">
        <CardContent className="pt-6">
          <div className="text-center">
            <Gift className="h-12 w-12 mx-auto mb-2 text-primary-foreground/80" />
            <h2 className="text-xl font-bold mb-1 text-primary-foreground">Refer & Earn Rs. 50!</h2>
            <p className="text-primary-foreground/70 text-sm mb-4">
              Share your code and get 500 points when friends complete 10 spins
            </p>
            
            {/* Referral Code */}
            <div className="bg-primary-foreground/20 rounded-lg p-4 mb-4">
              <p className="text-xs text-primary-foreground/70 mb-1">Your Referral Code</p>
              <p className="text-3xl font-bold tracking-wider text-primary-foreground">{referralCode}</p>
            </div>
            
            {/* Action Buttons */}
            <div className="grid grid-cols-3 gap-2">
              <Button 
                variant="secondary" 
                size="sm"
                onClick={handleCopyCode}
              >
                <Copy className="h-4 w-4 mr-1" />
                Copy Code
              </Button>
              <Button 
                variant="secondary" 
                size="sm"
                onClick={handleCopyLink}
              >
                <Copy className="h-4 w-4 mr-1" />
                Copy Link
              </Button>
              <Button 
                variant="secondary" 
                size="sm"
                onClick={handleShareWhatsApp}
                className="bg-accent hover:bg-accent/80 text-accent-foreground"
              >
                <Share2 className="h-4 w-4 mr-1" />
                WhatsApp
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <Card>
          <CardContent className="pt-4 text-center">
            <p className="text-2xl font-bold text-primary">
              {referralStats?.totalReferrals || 0}
            </p>
            <p className="text-xs text-muted-foreground">Total Referrals</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 text-center">
            <p className="text-2xl font-bold text-amber-600">
              {referralStats?.pendingRewards || 0}
            </p>
            <p className="text-xs text-muted-foreground">Pending</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 text-center">
            <p className="text-2xl font-bold text-accent">
              {referralStats?.totalPointsEarned || 0}
            </p>
            <p className="text-xs text-muted-foreground">Points Earned</p>
          </CardContent>
        </Card>
      </div>
      
      {/* How It Works */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">How Referrals Work</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 text-sm">
            <div className="flex gap-3">
              <div className="w-6 h-6 rounded-full bg-accent/30 text-primary flex items-center justify-center font-bold text-xs">1</div>
              <p>Share your unique code with friends</p>
            </div>
            <div className="flex gap-3">
              <div className="w-6 h-6 rounded-full bg-accent/30 text-primary flex items-center justify-center font-bold text-xs">2</div>
              <p>Friend registers using your code</p>
            </div>
            <div className="flex gap-3">
              <div className="w-6 h-6 rounded-full bg-accent/30 text-primary flex items-center justify-center font-bold text-xs">3</div>
              <p>Friend completes 10 spins</p>
            </div>
            <div className="flex gap-3">
              <div className="w-6 h-6 rounded-full bg-primary/20 text-primary flex items-center justify-center font-bold text-xs">4</div>
              <p className="font-medium text-primary">Both get 500 points (Rs. 50)!</p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Referred Friends */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <Users className="h-4 w-4" />
            Your Referrals
          </CardTitle>
        </CardHeader>
        <CardContent>
          {referredFriends && referredFriends.length > 0 ? (
            <div className="space-y-2 max-h-60 overflow-y-auto">
              {referredFriends.map((friend) => (
                <div 
                  key={friend.id}
                  className="flex items-center justify-between p-2 bg-muted rounded-lg"
                >
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-accent/30 flex items-center justify-center">
                      <Users className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium text-sm">{friend.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {friend.spinsCompleted}/10 spins
                      </p>
                    </div>
                  </div>
                  <div>
                    {friend.status === 'rewarded' ? (
                      <Badge className="bg-primary">
                        <CheckCircle className="h-3 w-3 mr-1" />
                        Rewarded
                      </Badge>
                    ) : friend.spinsCompleted >= 10 ? (
                      <Badge className="bg-amber-600">
                        <Clock className="h-3 w-3 mr-1" />
                        Processing
                      </Badge>
                    ) : (
                      <Badge variant="secondary">
                        <Clock className="h-3 w-3 mr-1" />
                        Pending
                      </Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <Users className="h-12 w-12 mx-auto mb-2 opacity-50" />
              <p>No referrals yet</p>
              <p className="text-sm">Share your code to start earning!</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
