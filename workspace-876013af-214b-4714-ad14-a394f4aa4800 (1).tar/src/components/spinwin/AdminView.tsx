'use client';

import { useEffect, useState } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Textarea } from '@/components/ui/textarea';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { 
  Settings, Clock, CheckCircle, XCircle, Eye, 
  Loader2, Search, ChevronDown, ChevronUp, Users,
  DollarSign, TrendingUp, Activity, Trash2, Edit,
  Coins, Gift, RotateCcw, ClipboardList, Plus,
  ExternalLink, ToggleLeft, ToggleRight, Megaphone
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useRealtime } from '@/components/RealtimeProvider';

interface AdminWithdrawal {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  method: string;
  pointsRequested: number;
  rsAmount: number;
  accountNumber: string;
  cnicLast6: string | null;
  status: string;
  adminNote: string | null;
  createdAt: string;
}

interface AdminUser {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  isAdmin: boolean;
  isVerified: boolean;
  level: number;
  xp: number;
  pointsBalance: number;
  totalPointsEarned: number;
  totalPointsWithdrawn: number;
  totalSpinsCompleted: number;
  streakDays: number;
  createdAt: string;
  lastLoginDate: string | null;
  _count: {
    referrals: number;
    withdrawals: number;
    spinLogs: number;
    taskCompletions: number;
    achievements: number;
  };
}

interface AdminTask {
  id: string;
  taskId: string;
  name: string;
  description: string;
  pointsReward: number;
  xpReward: number;
  type: string;
  category: string;
  link: string | null;
  isActive: boolean;
  createdAt: string;
  _count?: {
    taskCompletions: number;
  };
}

interface AdminStats {
  users: { total: number; newToday: number; newThisWeek: number; activeToday: number; };
  points: { inSystem: number; totalEarned: number; totalWithdrawn: number; };
  withdrawals: { total: number; pending: number; pendingRs: number; pendingPoints: number; processed: number; totalRsWithdrawn: number; };
  spins: { total: number; today: number; pointsWonToday: number; totalPointsWon: number; };
  referrals: { total: number; rewarded: number; };
}

const LEVEL_NAMES = ['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond', 'Master', 'Legend', 'Grandmaster'];
const LEVEL_EMOJIS = ['🥉', '🥈', '🥇', '💠', '💎', '🔮', '👑', '🌟'];

export function AdminView() {
  const { adminWithdrawals, fetchAdminWithdrawals, approveWithdrawal, rejectWithdrawal, user } = useAppStore();
  const { toast } = useToast();
  const { isConnected, onlineUsers, sendAnnouncement } = useRealtime();
  
  const [activeTab, setActiveTab] = useState('dashboard');
  const [processing, setProcessing] = useState<string | null>(null);
  const [rejectDialog, setRejectDialog] = useState<string | null>(null);
  const [rejectNote, setRejectNote] = useState('');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  
  // Admin data states
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [usersPage, setUsersPage] = useState(1);
  const [usersTotal, setUsersTotal] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [loadingStats, setLoadingStats] = useState(false);
  const [loadingUsers, setLoadingUsers] = useState(false);
  
  // Task management states
  const [tasks, setTasks] = useState<AdminTask[]>([]);
  const [loadingTasks, setLoadingTasks] = useState(false);
  const [taskDialog, setTaskDialog] = useState(false);
  const [editingTask, setEditingTask] = useState<AdminTask | null>(null);
  const [savingTask, setSavingTask] = useState(false);
  
  // Announcement states
  const [announcementMessage, setAnnouncementMessage] = useState('');
  const [announcementType, setAnnouncementType] = useState<'info' | 'success' | 'warning' | 'error'>('info');
  const [sendingAnnouncement, setSendingAnnouncement] = useState(false);
  
  // New task form
  const [taskForm, setTaskForm] = useState({
    taskId: '',
    name: '',
    description: '',
    pointsReward: '100',
    xpReward: '10',
    type: 'daily',
    category: 'social',
    link: '',
    isActive: true,
  });
  
  // Handle send announcement
  const handleSendAnnouncement = async () => {
    if (!announcementMessage.trim()) {
      toast({ title: "Error", description: "Please enter a message", variant: "destructive" });
      return;
    }
    
    setSendingAnnouncement(true);
    sendAnnouncement({
      message: announcementMessage,
      type: announcementType,
      from: user?.name || 'Admin',
    });
    setAnnouncementMessage('');
    setSendingAnnouncement(false);
    toast({ title: "Success", description: "Announcement sent to all users!" });
  };
  
  // Fetch stats
  const fetchStats = async () => {
    setLoadingStats(true);
    try {
      const res = await fetch('/api/admin/stats');
      const data = await res.json();
      if (data.success) setStats(data.data);
    } catch (error) {
      console.error('Failed to fetch stats:', error);
    }
    setLoadingStats(false);
  };
  
  // Fetch users
  const fetchUsers = async (page = 1, search = '') => {
    setLoadingUsers(true);
    try {
      const params = new URLSearchParams({ page: page.toString(), limit: '20', ...(search && { search }) });
      const res = await fetch(`/api/admin/users?${params}`);
      const data = await res.json();
      if (data.success) {
        setUsers(data.data.users);
        setUsersTotal(data.data.pagination.totalCount);
      }
    } catch (error) {
      console.error('Failed to fetch users:', error);
    }
    setLoadingUsers(false);
  };
  
  // Fetch tasks
  const fetchTasks = async () => {
    setLoadingTasks(true);
    try {
      const res = await fetch('/api/admin/tasks');
      const data = await res.json();
      if (data.success) setTasks(data.data.tasks);
    } catch (error) {
      console.error('Failed to fetch tasks:', error);
    }
    setLoadingTasks(false);
  };
  
  useEffect(() => {
    if (user?.isAdmin) {
      fetchAdminWithdrawals();
      fetchStats();
      fetchUsers();
      fetchTasks();
    }
  }, [fetchAdminWithdrawals, user?.isAdmin]);
  
  useEffect(() => {
    if (activeTab === 'users') fetchUsers(usersPage, searchQuery);
  }, [usersPage, searchQuery, activeTab]);
  
  useEffect(() => {
    if (activeTab === 'tasks') fetchTasks();
  }, [activeTab]);
  
  const handleApprove = async (id: string) => {
    setProcessing(id);
    const result = await approveWithdrawal(id);
    setProcessing(null);
    if (result.success) {
      toast({ title: "Approved!", description: "Withdrawal has been approved" });
      fetchStats();
    } else {
      toast({ title: "Failed", description: result.message, variant: "destructive" });
    }
  };
  
  const handleReject = async () => {
    if (!rejectDialog || !rejectNote) return;
    setProcessing(rejectDialog);
    const result = await rejectWithdrawal(rejectDialog, rejectNote);
    setProcessing(null);
    if (result.success) {
      toast({ title: "Rejected", description: "Withdrawal rejected and points refunded" });
      setRejectDialog(null);
      setRejectNote('');
      fetchStats();
    } else {
      toast({ title: "Failed", description: result.message, variant: "destructive" });
    }
  };
  
  // Task handlers
  const openNewTask = () => {
    setEditingTask(null);
    setTaskForm({
      taskId: '',
      name: '',
      description: '',
      pointsReward: '100',
      xpReward: '10',
      type: 'daily',
      category: 'social',
      link: '',
      isActive: true,
    });
    setTaskDialog(true);
  };
  
  const openEditTask = (task: AdminTask) => {
    setEditingTask(task);
    setTaskForm({
      taskId: task.taskId,
      name: task.name,
      description: task.description,
      pointsReward: task.pointsReward.toString(),
      xpReward: task.xpReward.toString(),
      type: task.type,
      category: task.category,
      link: task.link || '',
      isActive: task.isActive,
    });
    setTaskDialog(true);
  };
  
  const handleSaveTask = async () => {
    if (!taskForm.taskId || !taskForm.name || !taskForm.description) {
      toast({ title: "Missing Fields", description: "Please fill in all required fields", variant: "destructive" });
      return;
    }
    
    setSavingTask(true);
    
    try {
      const url = editingTask ? `/api/admin/tasks/${taskForm.taskId}` : '/api/admin/tasks';
      const method = editingTask ? 'PUT' : 'POST';
      
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(taskForm),
      });
      
      const data = await res.json();
      
      if (data.success) {
        toast({ title: editingTask ? "Task Updated" : "Task Created", description: data.message });
        setTaskDialog(false);
        fetchTasks();
      } else {
        throw new Error(data.error);
      }
    } catch (error) {
      toast({ 
        title: "Failed", 
        description: error instanceof Error ? error.message : 'Failed to save task',
        variant: "destructive" 
      });
    }
    
    setSavingTask(false);
  };
  
  const handleDeleteTask = async (taskId: string) => {
    if (!confirm('Are you sure you want to delete this task?')) return;
    
    try {
      const res = await fetch(`/api/admin/tasks/${taskId}`, { method: 'DELETE' });
      const data = await res.json();
      
      if (data.success) {
        toast({ title: "Task Deleted", description: "Task has been removed" });
        fetchTasks();
      } else {
        throw new Error(data.error);
      }
    } catch (error) {
      toast({ 
        title: "Delete Failed", 
        description: error instanceof Error ? error.message : 'Failed to delete task',
        variant: "destructive" 
      });
    }
  };
  
  const handleToggleTask = async (task: AdminTask) => {
    try {
      const res = await fetch(`/api/admin/tasks/${task.taskId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !task.isActive }),
      });
      
      const data = await res.json();
      
      if (data.success) {
        toast({ title: task.isActive ? "Task Deactivated" : "Task Activated", description: `Task is now ${task.isActive ? 'inactive' : 'active'}` });
        fetchTasks();
      }
    } catch (error) {
      toast({ title: "Failed", description: "Could not update task", variant: "destructive" });
    }
  };
  
  // User handlers
  const [selectedUser, setSelectedUser] = useState<AdminUser | null>(null);
  const [userDetailOpen, setUserDetailOpen] = useState(false);
  const [editUser, setEditUser] = useState<AdminUser | null>(null);
  const [editUserOpen, setEditUserOpen] = useState(false);
  const [editPoints, setEditPoints] = useState(0);
  const [editLevel, setEditLevel] = useState(0);
  const [savingUser, setSavingUser] = useState(false);
  
  const handleEditUser = async () => {
    if (!editUser) return;
    setSavingUser(true);
    try {
      const res = await fetch(`/api/admin/users/${editUser.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pointsBalance: editPoints, level: editLevel }),
      });
      const data = await res.json();
      if (data.success) {
        toast({ title: "User Updated", description: "User data has been updated" });
        setEditUserOpen(false);
        fetchUsers(usersPage, searchQuery);
        fetchStats();
      } else {
        throw new Error(data.error);
      }
    } catch (error) {
      toast({ title: "Update Failed", description: error instanceof Error ? error.message : 'Failed to update user', variant: "destructive" });
    }
    setSavingUser(false);
  };
  
  const handleDeleteUser = async (userId: string) => {
    if (!confirm('Are you sure you want to delete this user?')) return;
    try {
      const res = await fetch(`/api/admin/users/${userId}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        toast({ title: "User Deleted", description: "User has been removed" });
        fetchUsers(usersPage, searchQuery);
        fetchStats();
      } else {
        throw new Error(data.error);
      }
    } catch (error) {
      toast({ title: "Delete Failed", description: error instanceof Error ? error.message : 'Failed to delete user', variant: "destructive" });
    }
  };
  
  const pendingWithdrawals = adminWithdrawals.filter(w => w.status === 'pending');
  const processedWithdrawals = adminWithdrawals.filter(w => w.status !== 'pending');
  
  const renderWithdrawalCard = (w: AdminWithdrawal) => (
    <Card key={w.id} className="mb-3">
      <CardContent className="pt-4">
        <div className="flex justify-between items-start mb-3">
          <div>
            <p className="font-semibold">{w.userName}</p>
            <p className="text-sm text-muted-foreground">{w.userEmail}</p>
          </div>
          <div className="text-right">
            <p className="text-xl font-bold text-primary">Rs. {w.rsAmount}</p>
            <p className="text-sm text-muted-foreground">{w.pointsRequested.toLocaleString()} pts</p>
          </div>
        </div>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="capitalize">{w.method}</Badge>
            <p className="text-sm text-muted-foreground">{w.accountNumber}</p>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setExpandedId(expandedId === w.id ? null : w.id)}>
            {expandedId === w.id ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </Button>
        </div>
        {expandedId === w.id && (
          <div className="mt-3 pt-3 border-t space-y-2 text-sm">
            {w.cnicLast6 && <div className="flex justify-between"><span className="text-muted-foreground">CNIC:</span><span className="font-mono">{w.cnicLast6}</span></div>}
            <div className="flex justify-between"><span className="text-muted-foreground">Requested:</span><span>{new Date(w.createdAt).toLocaleString()}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Status:</span><Badge className={w.status === 'pending' ? 'bg-amber-500' : w.status === 'processed' ? 'bg-primary' : 'bg-destructive'}>{w.status}</Badge></div>
          </div>
        )}
        {w.status === 'pending' && (
          <div className="flex gap-2 mt-3">
            <Button className="flex-1" onClick={() => handleApprove(w.id)} disabled={processing === w.id}>
              {processing === w.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <><CheckCircle className="h-4 w-4 mr-1" />Approve</>}
            </Button>
            <Dialog open={rejectDialog === w.id} onOpenChange={(open) => setRejectDialog(open ? w.id : null)}>
              <Button variant="destructive" className="flex-1" onClick={() => setRejectDialog(w.id)}><XCircle className="h-4 w-4 mr-1" />Reject</Button>
              <DialogContent>
                <DialogHeader><DialogTitle>Reject Withdrawal</DialogTitle><DialogDescription>Provide a reason for rejection.</DialogDescription></DialogHeader>
                <div className="py-4">
                  <Label>Rejection Reason</Label>
                  <Input value={rejectNote} onChange={(e) => setRejectNote(e.target.value)} placeholder="e.g., Invalid account number" />
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setRejectDialog(null)}>Cancel</Button>
                  <Button variant="destructive" onClick={handleReject} disabled={!rejectNote || processing === w.id}>{processing === w.id ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Confirm Reject'}</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        )}
      </CardContent>
    </Card>
  );
  
  if (!user?.isAdmin) {
    return (
      <div className="max-w-lg mx-auto text-center py-12">
        <Settings className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
        <h2 className="text-xl font-bold">Access Denied</h2>
        <p className="text-muted-foreground">You don&apos;t have admin privileges</p>
      </div>
    );
  }
  
  return (
    <div className="max-w-4xl mx-auto space-y-4">
      <Card className="bg-gradient-to-br from-primary to-accent">
        <CardContent className="pt-6">
          <div className="flex items-center gap-3">
            <Settings className="h-8 w-8 text-primary-foreground" />
            <div>
              <h2 className="text-xl font-bold text-primary-foreground">Admin Dashboard</h2>
              <p className="text-primary-foreground/70 text-sm">Manage users, tasks, withdrawals & more</p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="dashboard" className="gap-1"><Activity className="h-4 w-4" /><span className="hidden sm:inline">Dashboard</span></TabsTrigger>
          <TabsTrigger value="users" className="gap-1"><Users className="h-4 w-4" /><span className="hidden sm:inline">Users</span></TabsTrigger>
          <TabsTrigger value="tasks" className="gap-1"><ClipboardList className="h-4 w-4" /><span className="hidden sm:inline">Tasks</span></TabsTrigger>
          <TabsTrigger value="pending" className="gap-1"><Clock className="h-4 w-4" /><span className="hidden sm:inline">Pending</span>{stats && stats.withdrawals.pending > 0 && <Badge variant="destructive" className="ml-1 h-5 w-5 p-0 text-xs">{stats.withdrawals.pending}</Badge>}</TabsTrigger>
          <TabsTrigger value="processed" className="gap-1"><CheckCircle className="h-4 w-4" /><span className="hidden sm:inline">Done</span></TabsTrigger>
        </TabsList>
        
        {/* Dashboard Tab */}
        <TabsContent value="dashboard" className="mt-4 space-y-4">
          {/* Real-time Status */}
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className={`h-3 w-3 rounded-full ${isConnected ? 'bg-primary animate-pulse' : 'bg-muted-foreground'}`} />
                  <span className="text-sm font-medium">Real-time: {isConnected ? 'Connected' : 'Disconnected'}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Users className="h-4 w-4" />
                  {onlineUsers} online
                </div>
              </div>
            </CardContent>
          </Card>
          
          {loadingStats ? <div className="flex justify-center py-8"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div> : stats ? (
            <>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <Card><CardContent className="pt-4 text-center"><Users className="h-6 w-6 mx-auto text-primary mb-2" /><p className="text-2xl font-bold">{stats.users.total}</p><p className="text-xs text-muted-foreground">Total Users</p></CardContent></Card>
                <Card><CardContent className="pt-4 text-center"><TrendingUp className="h-6 w-6 mx-auto text-accent mb-2" /><p className="text-2xl font-bold">{stats.users.activeToday}</p><p className="text-xs text-muted-foreground">Active Today</p></CardContent></Card>
                <Card><CardContent className="pt-4 text-center"><Coins className="h-6 w-6 mx-auto text-amber-600 mb-2" /><p className="text-2xl font-bold">{stats.points.inSystem.toLocaleString()}</p><p className="text-xs text-muted-foreground">Points in System</p></CardContent></Card>
                <Card><CardContent className="pt-4 text-center"><DollarSign className="h-6 w-6 mx-auto text-primary mb-2" /><p className="text-2xl font-bold">Rs. {stats.withdrawals.totalRsWithdrawn.toLocaleString()}</p><p className="text-xs text-muted-foreground">Total Withdrawn</p></CardContent></Card>
              </div>
              
              {/* Announcement Section */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Megaphone className="h-5 w-5" />
                    Send Announcement
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Textarea 
                    placeholder="Type your announcement message..."
                    value={announcementMessage}
                    onChange={(e) => setAnnouncementMessage(e.target.value)}
                    rows={3}
                  />
                  <div className="flex items-center gap-3">
                    <select 
                      className="border rounded-md p-2 bg-background text-sm"
                      value={announcementType}
                      onChange={(e) => setAnnouncementType(e.target.value as any)}
                    >
                      <option value="info">Info</option>
                      <option value="success">Success</option>
                      <option value="warning">Warning</option>
                      <option value="error">Error</option>
                    </select>
                    <Button 
                      onClick={handleSendAnnouncement} 
                      disabled={!announcementMessage.trim() || sendingAnnouncement || !isConnected}
                      className="flex-1"
                    >
                      {sendingAnnouncement ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Send to All Users'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
              
              {stats.withdrawals.pending > 0 && (
                <Card className="border-amber-300 bg-amber-100 dark:bg-amber-900/30">
                  <CardContent className="pt-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Clock className="h-8 w-8 text-amber-600" />
                        <div>
                          <p className="font-bold text-amber-800 dark:text-amber-200">{stats.withdrawals.pending} Pending Withdrawals</p>
                          <p className="text-sm text-amber-600 dark:text-amber-400">Rs. {stats.withdrawals.pendingRs.toLocaleString()} total</p>
                        </div>
                      </div>
                      <Button onClick={() => setActiveTab('pending')}>Review</Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </>
          ) : null}
        </TabsContent>
        
        {/* Users Tab */}
        <TabsContent value="users" className="mt-4 space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input className="pl-10" placeholder="Search by name, email, or phone..." value={searchQuery} onChange={(e) => { setSearchQuery(e.target.value); setUsersPage(1); }} />
          </div>
          {loadingUsers ? <div className="flex justify-center py-8"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div> : (
            <>
              <div className="text-sm text-muted-foreground">{usersTotal} user{usersTotal !== 1 ? 's' : ''} found</div>
              <ScrollArea className="h-[500px] pr-4">
                <div className="space-y-2">
                  {users.map((u) => (
                    <Card key={u.id} className="hover:bg-muted/50 transition-colors">
                      <CardContent className="pt-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-accent/30 flex items-center justify-center text-xl">{LEVEL_EMOJIS[u.level]}</div>
                            <div>
                              <div className="flex items-center gap-2"><p className="font-semibold">{u.name}</p>{u.isAdmin && <Badge className="text-xs bg-primary">Admin</Badge>}</div>
                              <p className="text-sm text-muted-foreground">{u.email}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="text-right mr-2"><p className="font-bold text-primary">{u.pointsBalance.toLocaleString()} pts</p><p className="text-xs text-muted-foreground">Rs. {(u.pointsBalance * 0.1).toFixed(0)}</p></div>
                            <Button variant="ghost" size="icon" onClick={() => { setSelectedUser(u); setUserDetailOpen(true); }}><Eye className="h-4 w-4" /></Button>
                            <Button variant="ghost" size="icon" onClick={() => { setEditUser(u); setEditPoints(u.pointsBalance); setEditLevel(u.level); setEditUserOpen(true); }}><Edit className="h-4 w-4" /></Button>
                            {!u.isAdmin && <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive" onClick={() => handleDeleteUser(u.id)}><Trash2 className="h-4 w-4" /></Button>}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
              {usersTotal > 20 && <div className="flex justify-center gap-2"><Button variant="outline" disabled={usersPage === 1} onClick={() => setUsersPage(p => p - 1)}>Previous</Button><span className="py-2 px-4">Page {usersPage} of {Math.ceil(usersTotal / 20)}</span><Button variant="outline" disabled={usersPage >= Math.ceil(usersTotal / 20)} onClick={() => setUsersPage(p => p + 1)}>Next</Button></div>}
            </>
          )}
        </TabsContent>
        
        {/* Tasks Tab */}
        <TabsContent value="tasks" className="mt-4 space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="font-semibold">Manage Tasks</h3>
              <p className="text-sm text-muted-foreground">Create, edit, and manage tasks for users</p>
            </div>
            <Button onClick={openNewTask}><Plus className="h-4 w-4 mr-1" />Add Task</Button>
          </div>
          
          {loadingTasks ? <div className="flex justify-center py-8"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div> : (
            <div className="space-y-2">
              {tasks.map((task) => (
                <Card key={task.id} className={!task.isActive ? 'opacity-60' : ''}>
                  <CardContent className="pt-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-accent/30 flex items-center justify-center">
                          {task.type === 'daily' ? '📅' : task.type === 'weekly' ? '📆' : '⭐'}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <p className="font-semibold">{task.name}</p>
                            <Badge variant="outline" className="text-xs capitalize">{task.type}</Badge>
                            {!task.isActive && <Badge variant="secondary" className="text-xs">Inactive</Badge>}
                          </div>
                          <p className="text-sm text-muted-foreground">{task.description}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge className="text-xs">+{task.pointsReward} pts</Badge>
                            {task.link && <a href={task.link} target="_blank" rel="noopener noreferrer" className="text-xs text-primary flex items-center gap-1"><ExternalLink className="h-3 w-3" />Link</a>}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="icon" onClick={() => handleToggleTask(task)} title={task.isActive ? 'Deactivate' : 'Activate'}>
                          {task.isActive ? <ToggleRight className="h-5 w-5 text-primary" /> : <ToggleLeft className="h-5 w-5 text-muted-foreground" />}
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => openEditTask(task)}><Edit className="h-4 w-4" /></Button>
                        <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive" onClick={() => handleDeleteTask(task.taskId)}><Trash2 className="h-4 w-4" /></Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
              {tasks.length === 0 && <div className="text-center py-12 text-muted-foreground"><ClipboardList className="h-12 w-12 mx-auto mb-2 opacity-50" /><p>No tasks found</p><p className="text-sm">Click "Add Task" to create one</p></div>}
            </div>
          )}
        </TabsContent>
        
        {/* Pending & Processed Tabs */}
        <TabsContent value="pending" className="mt-4">{pendingWithdrawals.length > 0 ? pendingWithdrawals.map(renderWithdrawalCard) : <div className="text-center py-12 text-muted-foreground"><CheckCircle className="h-12 w-12 mx-auto mb-2 opacity-50" /><p>No pending withdrawals</p></div>}</TabsContent>
        <TabsContent value="processed" className="mt-4">{processedWithdrawals.length > 0 ? processedWithdrawals.map(renderWithdrawalCard) : <div className="text-center py-12 text-muted-foreground"><Eye className="h-12 w-12 mx-auto mb-2 opacity-50" /><p>No processed withdrawals</p></div>}</TabsContent>
      </Tabs>
      
      {/* User Detail Dialog */}
      <Dialog open={userDetailOpen} onOpenChange={setUserDetailOpen}>
        <DialogContent className="max-w-md max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>User Details</DialogTitle></DialogHeader>
          {selectedUser && (
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-accent/30 flex items-center justify-center text-3xl">{LEVEL_EMOJIS[selectedUser.level]}</div>
                <div><h3 className="font-bold text-lg">{selectedUser.name}</h3><p className="text-sm text-muted-foreground">{selectedUser.email}</p>{selectedUser.isAdmin && <Badge className="bg-primary">Admin</Badge>}</div>
              </div>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="bg-muted p-3 rounded-lg"><p className="text-muted-foreground">Level</p><p className="font-bold">{LEVEL_NAMES[selectedUser.level]}</p></div>
                <div className="bg-muted p-3 rounded-lg"><p className="text-muted-foreground">Points</p><p className="font-bold text-primary">{selectedUser.pointsBalance.toLocaleString()}</p></div>
              </div>
              <div className="border-t pt-4 text-sm">
                <div className="flex justify-between"><span className="text-muted-foreground">Total Spins:</span><span>{selectedUser.totalSpinsCompleted}</span></div>
                <div className="flex justify-between mt-2"><span className="text-muted-foreground">Total Earned:</span><span>{selectedUser.totalPointsEarned.toLocaleString()} pts</span></div>
                <div className="flex justify-between mt-2"><span className="text-muted-foreground">Joined:</span><span>{new Date(selectedUser.createdAt).toLocaleDateString()}</span></div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
      
      {/* Edit User Dialog */}
      <Dialog open={editUserOpen} onOpenChange={setEditUserOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Edit User</DialogTitle><DialogDescription>Modify user&apos;s points and level</DialogDescription></DialogHeader>
          {editUser && (
            <div className="space-y-4 py-4">
              <div className="space-y-2"><Label>Points Balance</Label><Input type="number" value={editPoints} onChange={(e) => setEditPoints(parseInt(e.target.value) || 0)} /></div>
              <div className="space-y-2"><Label>Level (0-7)</Label><Input type="number" min="0" max="7" value={editLevel} onChange={(e) => setEditLevel(Math.min(7, Math.max(0, parseInt(e.target.value) || 0)))} /></div>
            </div>
          )}
          <DialogFooter><Button variant="outline" onClick={() => setEditUserOpen(false)}>Cancel</Button><Button onClick={handleEditUser} disabled={savingUser}>{savingUser ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Save Changes'}</Button></DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Task Dialog */}
      <Dialog open={taskDialog} onOpenChange={setTaskDialog}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editingTask ? 'Edit Task' : 'Add New Task'}</DialogTitle><DialogDescription>{editingTask ? 'Modify task details' : 'Create a new task for users to complete'}</DialogDescription></DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2"><Label>Task ID *</Label><Input value={taskForm.taskId} onChange={(e) => setTaskForm({ ...taskForm, taskId: e.target.value.toUpperCase().replace(/\s+/g, '_') })} placeholder="e.g., WATCH_VIDEO_1" disabled={!!editingTask} /><p className="text-xs text-muted-foreground">Unique identifier (no spaces)</p></div>
            <div className="space-y-2"><Label>Task Name *</Label><Input value={taskForm.name} onChange={(e) => setTaskForm({ ...taskForm, name: e.target.value })} placeholder="e.g., Watch YouTube Video" /></div>
            <div className="space-y-2"><Label>Description *</Label><Input value={taskForm.description} onChange={(e) => setTaskForm({ ...taskForm, description: e.target.value })} placeholder="e.g., Watch our latest YouTube video for 100 points" /></div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2"><Label>Points Reward *</Label><Input type="number" value={taskForm.pointsReward} onChange={(e) => setTaskForm({ ...taskForm, pointsReward: e.target.value })} /></div>
              <div className="space-y-2"><Label>XP Reward</Label><Input type="number" value={taskForm.xpReward} onChange={(e) => setTaskForm({ ...taskForm, xpReward: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2"><Label>Type</Label><select className="w-full border rounded-md p-2 bg-background" value={taskForm.type} onChange={(e) => setTaskForm({ ...taskForm, type: e.target.value })}><option value="daily">Daily</option><option value="weekly">Weekly</option><option value="onetime">One-Time</option></select></div>
              <div className="space-y-2"><Label>Category</Label><select className="w-full border rounded-md p-2 bg-background" value={taskForm.category} onChange={(e) => setTaskForm({ ...taskForm, category: e.target.value })}><option value="social">Social Media</option><option value="video">Video</option><option value="quiz">Quiz</option><option value="referral">Referral</option><option value="other">Other</option></select></div>
            </div>
            <div className="space-y-2"><Label>Link (Optional)</Label><Input value={taskForm.link} onChange={(e) => setTaskForm({ ...taskForm, link: e.target.value })} placeholder="https://..." type="url" /></div>
            <div className="flex items-center gap-2"><input type="checkbox" id="isActive" checked={taskForm.isActive} onChange={(e) => setTaskForm({ ...taskForm, isActive: e.target.checked })} className="rounded" /><Label htmlFor="isActive">Task is Active</Label></div>
          </div>
          <DialogFooter><Button variant="outline" onClick={() => setTaskDialog(false)}>Cancel</Button><Button onClick={handleSaveTask} disabled={savingTask}>{savingTask ? <Loader2 className="h-4 w-4 animate-spin" /> : editingTask ? 'Update Task' : 'Create Task'}</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
