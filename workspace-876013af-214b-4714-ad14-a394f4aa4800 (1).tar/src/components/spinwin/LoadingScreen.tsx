'use client';

import { Coins, Loader2 } from 'lucide-react';

export function LoadingScreen() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background">
      <div className="flex flex-col items-center gap-4">
        {/* Logo */}
        <div className="relative">
          <div className="w-20 h-20 rounded-full bg-primary flex items-center justify-center shadow-lg">
            <Coins className="w-10 h-10 text-primary-foreground" />
          </div>
          <div className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-accent flex items-center justify-center">
            <Loader2 className="w-5 h-5 text-accent-foreground animate-spin" />
          </div>
        </div>
        
        {/* Brand Name */}
        <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
          SpinWin
        </h1>
        
        {/* Loading Text */}
        <p className="text-muted-foreground animate-pulse">
          Loading...
        </p>
      </div>
      
      {/* Loading Bar Animation */}
      <div className="mt-8 w-48 h-1 bg-muted rounded-full overflow-hidden">
        <div className="h-full bg-gradient-to-r from-primary to-accent rounded-full animate-loading-bar" />
      </div>
      
      <style jsx>{`
        @keyframes loading-bar {
          0% { width: 0%; transform: translateX(0); }
          50% { width: 70%; }
          100% { width: 100%; transform: translateX(0); }
        }
        .animate-loading-bar {
          animation: loading-bar 1.5s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}
