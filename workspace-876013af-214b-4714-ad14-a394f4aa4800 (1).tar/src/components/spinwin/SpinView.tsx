'use client';

import { useEffect } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { SpinWheel } from './SpinWheel';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { History, TrendingUp } from 'lucide-react';

export function SpinView() {
  const { fetchSpinStatus, spinHistory, user } = useAppStore();
  
  useEffect(() => {
    fetchSpinStatus();
  }, [fetchSpinStatus]);
  
  return (
    <div className="max-w-lg mx-auto space-y-6">
      {/* Spin Wheel */}
      <SpinWheel />
      
      {/* Recent Spins */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <History className="h-4 w-4" />
            Recent Spins
          </CardTitle>
        </CardHeader>
        <CardContent>
          {spinHistory && spinHistory.length > 0 ? (
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {spinHistory.slice(0, 10).map((spin: { pointsWon: number; createdAt: string }, index: number) => (
                <div key={index} className="flex justify-between items-center text-sm py-1 border-b last:border-0">
                  <span className="text-muted-foreground">
                    {new Date(spin.createdAt).toLocaleTimeString()}
                  </span>
                  <span className={spin.pointsWon > 0 ? "text-emerald-600 font-medium" : "text-gray-400"}>
                    {spin.pointsWon > 0 ? `+${spin.pointsWon} pts` : 'Try Again'}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground text-center py-4">
              No spins yet. Start spinning to win points!
            </p>
          )}
        </CardContent>
      </Card>
      
      {/* Spin Tips */}
      <Card className="bg-amber-50 border-amber-200">
        <CardContent className="pt-4">
          <h3 className="font-semibold text-amber-800 mb-2">💡 Spin Tips</h3>
          <ul className="text-sm text-amber-700 space-y-1">
            <li>• Each spin earns you XP towards the next level</li>
            <li>• Higher levels = more daily spins</li>
            <li>• Win the 500 pts Jackpot for the biggest rewards!</li>
            <li>• Daily streaks give bonus points up to 1,000 pts</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
