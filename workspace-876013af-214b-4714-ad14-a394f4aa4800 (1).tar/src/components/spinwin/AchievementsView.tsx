'use client';

import { useEffect, useState } from 'react';
import { useAppStore, Achievement } from '@/store/useAppStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Trophy, Lock, CheckCircle, Gift, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const CATEGORY_ICONS: Record<string, string> = {
  general: '🎯',
  spins: '🎰',
  social: '📱',
  streak: '🔥',
  referral: '👥',
  withdrawal: '💸',
};

export function AchievementsView() {
  const { 
    achievements, 
    fetchAchievements
  } = useAppStore();
  const { toast } = useToast();
  const [claiming, setClaiming] = useState<string | null>(null);
  
  useEffect(() => {
    fetchAchievements();
  }, [fetchAchievements]);
  
  const handleClaim = async (achievementId: string) => {
    setClaiming(achievementId);
    
    try {
      const res = await fetch(`/api/achievements/${achievementId}/claim`, {
        method: 'POST'
      });
      
      const data = await res.json();
      
      if (data.success) {
        toast({
          title: "Reward Claimed!",
          description: `You received ${data.data?.pointsAwarded || 0} points!`,
        });
        fetchAchievements();
      } else {
        throw new Error(data.message);
      }
    } catch {
      toast({
        title: "Claim Failed",
        description: "Please try again",
        variant: "destructive"
      });
    }
    
    setClaiming(null);
  };
  
  const unlockedCount = achievements.filter(a => a.unlocked).length;
  const unclaimedCount = achievements.filter(a => a.unlocked && !a.pointsClaimed).length;
  const totalPoints = achievements.reduce((sum, a) => sum + (a.unlocked ? a.pointsReward : 0), 0);
  
  // Group by category
  const grouped = achievements.reduce((acc, a) => {
    const cat = a.category || 'general';
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(a);
    return acc;
  }, {} as Record<string, Achievement[]>);
  
  return (
    <div className="max-w-lg mx-auto space-y-4">
      {/* Stats Header */}
      <Card className="bg-gradient-to-br from-amber-600 to-orange-700">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-amber-200 text-sm">Achievements Unlocked</p>
              <p className="text-3xl font-bold text-amber-50">{unlockedCount} / {achievements.length}</p>
            </div>
            <div className="text-right">
              <p className="text-amber-200 text-sm">Points Earned</p>
              <p className="text-3xl font-bold text-amber-50">{totalPoints.toLocaleString()}</p>
            </div>
          </div>
          
          {unclaimedCount > 0 && (
            <div className="mt-4 p-3 bg-amber-400/30 rounded-lg text-center">
              <p className="font-medium text-amber-50">
                🎁 You have {unclaimedCount} unclaimed reward{unclaimedCount > 1 ? 's' : ''}!
              </p>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Achievement Grid by Category */}
      {Object.entries(grouped).map(([category, categoryAchievements]) => (
        <Card key={category}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <span className="text-lg">{CATEGORY_ICONS[category] || '🏆'}</span>
              {category.charAt(0).toUpperCase() + category.slice(1)} Achievements
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3">
              {categoryAchievements.map((achievement) => (
                <div
                  key={achievement.id}
                  className={`p-3 rounded-lg border-2 transition-all ${
                    achievement.unlocked 
                      ? 'border-amber-400 bg-amber-100 dark:bg-amber-900/30' 
                      : 'border-border bg-muted opacity-60'
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <span className={`text-2xl ${achievement.unlocked ? '' : 'grayscale'}`}>
                      {achievement.icon}
                    </span>
                    {achievement.unlocked ? (
                      achievement.pointsClaimed ? (
                        <CheckCircle className="h-5 w-5 text-primary" />
                      ) : (
                        <Gift className="h-5 w-5 text-amber-500 animate-pulse" />
                      )
                    ) : (
                      <Lock className="h-5 w-5 text-muted-foreground" />
                    )}
                  </div>
                  
                  <h3 className={`font-semibold text-sm ${achievement.unlocked ? 'text-amber-800 dark:text-amber-200' : 'text-muted-foreground'}`}>
                    {achievement.name}
                  </h3>
                  <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                    {achievement.description}
                  </p>
                  
                  <div className="flex items-center justify-between mt-2">
                    <Badge variant={achievement.unlocked ? "default" : "secondary"} className="text-xs">
                      +{achievement.pointsReward} pts
                    </Badge>
                    
                    {achievement.unlocked && !achievement.pointsClaimed && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleClaim(achievement.badgeId)}
                        disabled={claiming === achievement.badgeId}
                        className="h-6 text-xs"
                      >
                        {claiming === achievement.badgeId ? (
                          <Loader2 className="h-3 w-3 animate-spin" />
                        ) : (
                          'Claim'
                        )}
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
