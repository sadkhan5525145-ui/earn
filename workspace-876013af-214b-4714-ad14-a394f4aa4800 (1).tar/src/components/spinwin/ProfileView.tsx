'use client';

import { useEffect, useState } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { User, Trophy, TrendingUp, Settings, Loader2, Check } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const LEVEL_NAMES = ['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond', 'Master', 'Legend', 'Grandmaster'];
const LEVEL_EMOJIS = ['🥉', '🥈', '🥇', '💠', '💎', '🔮', '👑', '🌟'];

export function ProfileView() {
  const { 
    user, 
    levelInfo, 
    walletInfo,
    fetchLevelInfo,
    fetchWallet
  } = useAppStore();
  const { toast } = useToast();
  
  const [easypaisaNumber, setEasypaisaNumber] = useState('');
  const [jazzcashNumber, setJazzcashNumber] = useState('');
  const [cnicLast6, setCnicLast6] = useState('');
  const [saving, setSaving] = useState(false);
  
  useEffect(() => {
    fetchLevelInfo();
    fetchWallet();
    
    if (user) {
      setEasypaisaNumber(user.easypaisaNumber || '');
      setJazzcashNumber(user.jazzcashNumber || '');
      setCnicLast6(user.cnicLast6 || '');
    }
  }, [fetchLevelInfo, fetchWallet, user]);
  
  const handleSaveSettings = async () => {
    setSaving(true);
    
    try {
      const res = await fetch('/api/user/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          easypaisaNumber,
          jazzcashNumber,
          cnicLast6
        })
      });
      
      const data = await res.json();
      
      if (data.success) {
        toast({
          title: "Settings Saved!",
          description: "Your withdrawal settings have been updated.",
        });
      } else {
        throw new Error(data.message);
      }
    } catch {
      toast({
        title: "Save Failed",
        description: "Please try again",
        variant: "destructive"
      });
    }
    
    setSaving(false);
  };
  
  const level = user?.level || 0;
  const levelName = levelInfo?.levelName || LEVEL_NAMES[level];
  const levelEmoji = LEVEL_EMOJIS[level];
  
  return (
    <div className="max-w-lg mx-auto space-y-4">
      {/* Profile Header */}
      <Card className="bg-gradient-to-br from-primary to-accent">
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-primary-foreground/20 flex items-center justify-center text-3xl">
              {levelEmoji}
            </div>
            <div>
              <h2 className="text-2xl font-bold text-primary-foreground">{user?.name}</h2>
              <p className="text-primary-foreground/70">{user?.email}</p>
              <Badge className="mt-1 bg-primary-foreground/20 text-primary-foreground">
                {levelName} Level
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Level Progress */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <Trophy className="h-4 w-4 text-amber-500" />
            Level Progress
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-3">
            <span className="text-3xl">{levelEmoji}</span>
            <div className="flex-1">
              <div className="flex justify-between items-center mb-1">
                <span className="font-semibold">{levelName}</span>
                <span className="text-sm text-muted-foreground">
                  {levelInfo?.currentXP || 0} / {levelInfo?.nextLevelXP || '?'} XP
                </span>
              </div>
              <Progress value={levelInfo?.xpProgress || 0} className="h-3" />
            </div>
            {level < 7 && (
              <>
                <span className="text-xl">→</span>
                <span className="text-2xl">{LEVEL_EMOJIS[level + 1]}</span>
              </>
            )}
          </div>
          
          <div className="mt-4 grid grid-cols-2 gap-2 text-sm">
            <div className="bg-muted p-2 rounded-lg">
              <span className="text-muted-foreground">Daily Spins:</span>
              <span className="font-bold ml-1">{levelInfo?.dailySpins || 5}</span>
            </div>
            <div className="bg-muted p-2 rounded-lg">
              <span className="text-muted-foreground">Total XP:</span>
              <span className="font-bold ml-1">{user?.xp || 0}</span>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Stats */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-accent" />
            Your Stats
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-3 bg-accent/20 rounded-lg">
              <p className="text-2xl font-bold text-primary">
                {(walletInfo?.totalEarned || 0).toLocaleString()}
              </p>
              <p className="text-xs text-muted-foreground">Points Earned</p>
            </div>
            <div className="text-center p-3 bg-amber-100 dark:bg-amber-900/30 rounded-lg">
              <p className="text-2xl font-bold text-amber-600 dark:text-amber-400">
                Rs. {((walletInfo?.totalWithdrawn || 0) * 0.1).toFixed(0)}
              </p>
              <p className="text-xs text-muted-foreground">Total Withdrawn</p>
            </div>
            <div className="text-center p-3 bg-muted rounded-lg">
              <p className="text-2xl font-bold text-foreground">
                {user?.totalSpinsCompleted || 0}
              </p>
              <p className="text-xs text-muted-foreground">Total Spins</p>
            </div>
            <div className="text-center p-3 bg-orange-100 dark:bg-orange-900/30 rounded-lg">
              <p className="text-2xl font-bold text-orange-600 dark:text-orange-400">
                {user?.streakDays || 0}
              </p>
              <p className="text-xs text-muted-foreground">Best Streak</p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Withdrawal Settings */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <Settings className="h-4 w-4" />
            Withdrawal Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="easypaisa">Easypaisa Number</Label>
            <Input
              id="easypaisa"
              type="tel"
              placeholder="03xx-xxxxxxx"
              value={easypaisaNumber}
              onChange={(e) => setEasypaisaNumber(e.target.value)}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="jazzcash">JazzCash Number</Label>
            <Input
              id="jazzcash"
              type="tel"
              placeholder="03xx-xxxxxxx"
              value={jazzcashNumber}
              onChange={(e) => setJazzcashNumber(e.target.value)}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="cnic">CNIC Last 6 Digits</Label>
            <Input
              id="cnic"
              type="text"
              placeholder="123456"
              maxLength={6}
              value={cnicLast6}
              onChange={(e) => setCnicLast6(e.target.value.replace(/\D/g, '').slice(0, 6))}
            />
            <p className="text-xs text-muted-foreground">
              Required for Easypaisa and JazzCash withdrawals
            </p>
          </div>
          
          <Button 
            onClick={handleSaveSettings}
            className="w-full"
            disabled={saving}
          >
            {saving ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Check className="mr-2 h-4 w-4" />
                Save Settings
              </>
            )}
          </Button>
        </CardContent>
      </Card>
      
      {/* Account Info */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <User className="h-4 w-4" />
            Account Information
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Email:</span>
              <span>{user?.email}</span>
            </div>
            <Separator />
            <div className="flex justify-between">
              <span className="text-muted-foreground">Phone:</span>
              <span>{user?.phone || 'Not set'}</span>
            </div>
            <Separator />
            <div className="flex justify-between">
              <span className="text-muted-foreground">Member Since:</span>
              <span>{new Date(user?.createdAt || '').toLocaleDateString()}</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
