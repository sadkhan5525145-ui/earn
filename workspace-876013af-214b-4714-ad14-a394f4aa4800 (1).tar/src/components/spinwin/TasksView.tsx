'use client';

import { useEffect, useState } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Gift, Flame, ExternalLink, CheckCircle, Loader2, Star } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const STREAK_REWARDS = [50, 100, 150, 200, 300, 500, 1000];

export function TasksView() {
  const { 
    tasks, 
    streakInfo,
    fetchTasks, 
    fetchStreakInfo,
    completeTask,
    claimBonus
  } = useAppStore();
  const { toast } = useToast();
  const [claiming, setClaiming] = useState(false);
  const [completingTask, setCompletingTask] = useState<string | null>(null);
  
  useEffect(() => {
    fetchTasks();
    fetchStreakInfo();
  }, [fetchTasks, fetchStreakInfo]);
  
  const handleClaimBonus = async () => {
    setClaiming(true);
    const result = await claimBonus();
    setClaiming(false);
    
    if (result.success) {
      toast({
        title: "Bonus Claimed!",
        description: `You received ${result.points} points! Day ${result.streak} streak!`,
      });
    } else {
      toast({
        title: "Cannot Claim",
        description: result.message || "Try again later",
        variant: "destructive"
      });
    }
  };
  
  const handleCompleteTask = async (taskId: string) => {
    setCompletingTask(taskId);
    const result = await completeTask(taskId);
    setCompletingTask(null);
    
    if (result.success) {
      toast({
        title: "Task Completed!",
        description: `You earned ${result.points} points!`,
      });
    } else {
      toast({
        title: "Task Failed",
        description: result.message || "Please try again",
        variant: "destructive"
      });
    }
  };
  
  const dailyTasks = tasks.filter(t => t.type === 'daily');
  const onetimeTasks = tasks.filter(t => t.type === 'onetime');
  const weeklyTasks = tasks.filter(t => t.type === 'weekly');
  
  const completedDaily = dailyTasks.filter(t => t.completed).length;
  const completedOnetime = onetimeTasks.filter(t => t.completed).length;
  const completedWeekly = weeklyTasks.filter(t => t.completed).length;
  
  return (
    <div className="max-w-lg mx-auto space-y-4">
      {/* Daily Bonus */}
      <Card className={streakInfo?.canClaimBonus ? "border-primary bg-accent/20" : ""}>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2">
            <Gift className="h-5 w-5 text-primary" />
            Daily Bonus
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between items-center">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Flame className="h-5 w-5 text-orange-500" />
                <span className="font-bold text-lg">{streakInfo?.currentStreak || 0} Day Streak</span>
              </div>
              {streakInfo?.canClaimBonus ? (
                <p className="text-sm text-primary font-medium">
                  +150 points ready to claim!
                </p>
              ) : (
                <p className="text-sm text-muted-foreground">
                  Already claimed today
                </p>
              )}
            </div>
            
            {streakInfo?.canClaimBonus && (
              <Button 
                onClick={handleClaimBonus}
                disabled={claiming}
              >
                {claiming ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  'Claim'
                )}
              </Button>
            )}
          </div>
          
          {/* Streak Progress */}
          <div className="mt-4">
            <div className="flex justify-between text-xs text-muted-foreground mb-1">
              <span>Weekly Streak Rewards</span>
            </div>
            <div className="grid grid-cols-7 gap-1">
              {STREAK_REWARDS.map((reward, i) => (
                <div 
                  key={i}
                  className={`text-center p-2 rounded-lg text-xs ${
                    (streakInfo?.currentStreak || 0) >= i + 1
                      ? 'bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-300 border border-orange-300'
                      : 'bg-muted text-muted-foreground'
                  }`}
                >
                  <div className="font-bold">Day {i + 1}</div>
                  <div className="text-[10px]">+{reward}</div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Daily Tasks */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex justify-between items-center">
            <CardTitle className="text-sm flex items-center gap-2">
              <Star className="h-4 w-4 text-amber-500" />
              Daily Tasks
            </CardTitle>
            <Badge variant="secondary">{completedDaily}/{dailyTasks.length}</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {dailyTasks.map((task) => (
              <div 
                key={task.id}
                className={`flex items-center justify-between p-3 rounded-lg border ${
                  task.completed ? 'bg-accent/30 border-primary' : 'bg-card'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Checkbox checked={task.completed} disabled />
                  <div>
                    <p className={`font-medium ${task.completed ? 'text-primary' : ''}`}>
                      {task.name}
                    </p>
                    <p className="text-xs text-muted-foreground">{task.description}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-primary">
                    +{task.pointsReward} pts
                  </Badge>
                  {!task.completed && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleCompleteTask(task.taskId)}
                      disabled={completingTask === task.taskId}
                    >
                      {completingTask === task.taskId ? (
                        <Loader2 className="h-3 w-3 animate-spin" />
                      ) : task.link ? (
                        <ExternalLink className="h-3 w-3" />
                      ) : (
                        <CheckCircle className="h-3 w-3" />
                      )}
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      
      {/* One-Time Tasks */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex justify-between items-center">
            <CardTitle className="text-sm flex items-center gap-2">
              <Gift className="h-4 w-4 text-accent" />
              One-Time Tasks
            </CardTitle>
            <Badge variant="secondary">{completedOnetime}/{onetimeTasks.length}</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {onetimeTasks.map((task) => (
              <div 
                key={task.id}
                className={`flex items-center justify-between p-3 rounded-lg border ${
                  task.completed ? 'bg-accent/30 border-primary' : 'bg-card'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Checkbox checked={task.completed} disabled />
                  <div>
                    <p className={`font-medium ${task.completed ? 'text-primary' : ''}`}>
                      {task.name}
                    </p>
                    <p className="text-xs text-muted-foreground">{task.description}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-primary">
                    +{task.pointsReward} pts
                  </Badge>
                  {!task.completed && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleCompleteTask(task.taskId)}
                      disabled={completingTask === task.taskId}
                    >
                      {completingTask === task.taskId ? (
                        <Loader2 className="h-3 w-3 animate-spin" />
                      ) : task.link ? (
                        <ExternalLink className="h-3 w-3" />
                      ) : (
                        <CheckCircle className="h-3 w-3" />
                      )}
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      
      {/* Weekly Tasks */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex justify-between items-center">
            <CardTitle className="text-sm flex items-center gap-2">
              <Star className="h-4 w-4 text-primary" />
              Weekly Tasks
            </CardTitle>
            <Badge variant="secondary">{completedWeekly}/{weeklyTasks.length}</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {weeklyTasks.map((task) => (
              <div 
                key={task.id}
                className={`flex items-center justify-between p-3 rounded-lg border ${
                  task.completed ? 'bg-accent/30 border-primary' : 'bg-card'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Checkbox checked={task.completed} disabled />
                  <div>
                    <p className={`font-medium ${task.completed ? 'text-primary' : ''}`}>
                      {task.name}
                    </p>
                    <p className="text-xs text-muted-foreground">{task.description}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-primary">
                    +{task.pointsReward} pts
                  </Badge>
                  {!task.completed && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleCompleteTask(task.taskId)}
                      disabled={completingTask === task.taskId}
                    >
                      {completingTask === task.taskId ? (
                        <Loader2 className="h-3 w-3 animate-spin" />
                      ) : (
                        <CheckCircle className="h-3 w-3" />
                      )}
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
