'use client';

import { useEffect } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Trophy, Medal, Award, Crown, TrendingUp } from 'lucide-react';

const LEVEL_NAMES = ['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond', 'Master', 'Legend', 'Grandmaster'];
const LEVEL_EMOJIS = ['🥉', '🥈', '🥇', '💠', '💎', '🔮', '👑', '🌟'];

export function LeaderboardView() {
  const { 
    leaderboard, 
    userRank,
    fetchLeaderboard
  } = useAppStore();
  
  useEffect(() => {
    fetchLeaderboard();
  }, [fetchLeaderboard]);
  
  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Crown className="h-6 w-6 text-amber-500" />;
      case 2: return <Medal className="h-6 w-6 text-slate-400" />;
      case 3: return <Award className="h-6 w-6 text-amber-700" />;
      default: return <span className="text-lg font-bold text-muted-foreground w-6 text-center">{rank}</span>;
    }
  };
  
  const getRankBg = (rank: number) => {
    switch (rank) {
      case 1: return 'bg-amber-100 dark:bg-amber-900/30 border-amber-300';
      case 2: return 'bg-slate-100 dark:bg-slate-800/30 border-slate-300';
      case 3: return 'bg-amber-50 dark:bg-amber-900/20 border-amber-200';
      default: return 'bg-card';
    }
  };
  
  return (
    <div className="max-w-lg mx-auto space-y-4">
      {/* Your Rank */}
      <Card className="bg-gradient-to-br from-primary to-accent">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-primary-foreground/70 text-sm">Your Weekly Rank</p>
              <p className="text-4xl font-bold text-primary-foreground">#{userRank?.rank || '---'}</p>
              <p className="text-primary-foreground/70 text-sm mt-1">
                Top {userRank?.percentile ? (100 - userRank.percentile).toFixed(1) : '--'}% of earners
              </p>
            </div>
            <div className="text-right">
              <TrendingUp className="h-12 w-12 text-primary-foreground/50" />
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Top 3 Podium */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <Trophy className="h-4 w-4 text-amber-500" />
            Weekly Top Earners
          </CardTitle>
        </CardHeader>
        <CardContent>
          {leaderboard && leaderboard.length > 0 ? (
            <div className="space-y-2">
              {/* Podium for top 3 */}
              <div className="grid grid-cols-3 gap-2 mb-4">
                {leaderboard.slice(0, 3).map((entry, idx) => {
                  const podiumOrder = [1, 0, 2]; // 2nd, 1st, 3rd
                  const actualEntry = leaderboard[podiumOrder[idx]];
                  if (!actualEntry) return null;
                  
                  const rank = podiumOrder[idx] + 1;
                  const height = rank === 1 ? 'h-24' : rank === 2 ? 'h-20' : 'h-16';
                  
                  return (
                    <div key={actualEntry.userId} className={`flex flex-col items-center ${idx === 0 ? 'order-2' : idx === 1 ? 'order-1' : 'order-3'}`}>
                      <div className={`${height} w-full rounded-t-lg flex flex-col items-center justify-end p-2 ${
                        rank === 1 ? 'bg-amber-500' : rank === 2 ? 'bg-slate-400' : 'bg-amber-600'
                      }`}>
                        <span className="text-2xl">
                          {LEVEL_EMOJIS[actualEntry.level] || '🥉'}
                        </span>
                        <p className="text-primary-foreground font-bold text-xs truncate w-full text-center">
                          {actualEntry.name.split(' ')[0]}
                        </p>
                        <p className="text-primary-foreground/80 text-[10px]">
                          {actualEntry.pointsEarned.toLocaleString()} pts
                        </p>
                      </div>
                      <div className={`w-full text-center py-1 rounded-b-lg ${
                        rank === 1 ? 'bg-amber-600 text-primary-foreground' : rank === 2 ? 'bg-slate-500 text-primary-foreground' : 'bg-amber-700 text-primary-foreground'
                      }`}>
                        #{rank}
                      </div>
                    </div>
                  );
                })}
              </div>
              
              {/* Rest of leaderboard */}
              <div className="space-y-2">
                {leaderboard.slice(3, 10).map((entry) => (
                  <div
                    key={entry.userId}
                    className={`flex items-center justify-between p-3 rounded-lg border ${getRankBg(entry.rank)} ${
                      entry.isCurrentUser ? 'ring-2 ring-primary' : ''
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      {getRankIcon(entry.rank)}
                      <div>
                        <p className={`font-medium ${entry.isCurrentUser ? 'text-primary' : ''}`}>
                          {entry.name}
                          {entry.isCurrentUser && ' (You)'}
                        </p>
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <span>{LEVEL_EMOJIS[entry.level]}</span>
                          <span>{LEVEL_NAMES[entry.level]}</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-primary">
                        {entry.pointsEarned.toLocaleString()}
                      </p>
                      <p className="text-xs text-muted-foreground">pts this week</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <Trophy className="h-12 w-12 mx-auto mb-2 opacity-50" />
              <p>No leaderboard data yet</p>
              <p className="text-sm">Start spinning to climb the ranks!</p>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Tips */}
      <Card className="bg-amber-100 dark:bg-amber-900/30 border-amber-300">
        <CardContent className="pt-4">
          <h3 className="font-semibold text-amber-800 dark:text-amber-200 mb-2">🏆 How to Climb</h3>
          <ul className="text-sm text-amber-700 dark:text-amber-300 space-y-1">
            <li>• Spin daily to earn points</li>
            <li>• Complete tasks for bonus points</li>
            <li>• Refer friends for 500 pts each</li>
            <li>• Maintain your daily streak</li>
          </ul>
          <p className="text-xs text-amber-600 dark:text-amber-400 mt-2">
            Leaderboard resets every Sunday at midnight PKT
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
