'use client';

import { useEffect } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { QuickActions } from './BottomNav';
import { Coins, Flame, Trophy, Gift, ArrowRight, TrendingUp } from 'lucide-react';

const LEVEL_NAMES = ['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond', 'Master', 'Legend', 'Grandmaster'];
const LEVEL_EMOJIS = ['🥉', '🥈', '🥇', '💠', '💎', '🔮', '👑', '🌟'];
const STREAK_REWARDS = [50, 100, 150, 200, 300, 500, 1000];

export function HomeView() {
  const { 
    user, 
    walletInfo, 
    streakInfo, 
    levelInfo, 
    spinsRemaining,
    fetchWallet, 
    fetchStreakInfo, 
    fetchLevelInfo,
    fetchSpinStatus,
    setCurrentView,
    claimBonus
  } = useAppStore();
  
  useEffect(() => {
    fetchWallet();
    fetchStreakInfo();
    fetchLevelInfo();
    fetchSpinStatus();
  }, [fetchWallet, fetchStreakInfo, fetchLevelInfo, fetchSpinStatus]);
  
  const level = user?.level || 0;
  const levelName = levelInfo?.levelName || LEVEL_NAMES[level];
  const levelEmoji = LEVEL_EMOJIS[level];
  
  const balance = user?.pointsBalance || 0;
  const rsEquivalent = balance * 0.1;
  const progressToWithdraw = Math.min((balance / 3000) * 100, 100);
  
  const handleClaimBonus = async () => {
    await claimBonus();
  };
  
  return (
    <div className="space-y-4 max-w-lg mx-auto">
      {/* Welcome Card */}
      <Card className="bg-gradient-to-br from-primary to-accent">
        <CardContent className="pt-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-primary-foreground/80 text-sm">Welcome back,</p>
              <h2 className="text-2xl font-bold text-primary-foreground">{user?.name?.split(' ')[0] || 'User'}! 👋</h2>
            </div>
            <Badge className="bg-primary-foreground/20 text-primary-foreground gap-1">
              <span>{levelEmoji}</span>
              {levelName}
            </Badge>
          </div>
          
          {/* Balance */}
          <div className="mt-6">
            <div className="flex items-center gap-2">
              <Coins className="h-5 w-5 text-amber-300" />
              <span className="text-primary-foreground/80">Your Balance</span>
            </div>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-4xl font-bold text-primary-foreground">{balance.toLocaleString()}</span>
              <span className="text-primary-foreground/70">points</span>
            </div>
            <p className="text-primary-foreground/80 text-lg font-medium">= Rs. {rsEquivalent.toFixed(0)}</p>
          </div>
          
          {/* Progress to Withdrawal */}
          <div className="mt-4">
            <div className="flex justify-between text-sm text-primary-foreground/80 mb-1">
              <span>Progress to Withdrawal</span>
              <span>{balance.toLocaleString()} / 3,000 pts</span>
            </div>
            <Progress value={progressToWithdraw} className="h-2 bg-primary-foreground/20" />
            <p className="text-xs text-primary-foreground/70 mt-1">
              {balance >= 3000 
                ? "✅ You can withdraw now!" 
                : `Need ${(3000 - balance).toLocaleString()} more points`}
            </p>
          </div>
        </CardContent>
      </Card>
      
      {/* Quick Actions */}
      <QuickActions />
      
      {/* Spins Remaining */}
      <Card className="border-amber-300 bg-amber-100 dark:bg-amber-900/30">
        <CardContent className="pt-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-amber-200 dark:bg-amber-800 p-2 rounded-full">
              <span className="text-2xl">🎰</span>
            </div>
            <div>
              <p className="font-semibold text-amber-800 dark:text-amber-200">{spinsRemaining} Spins Left Today</p>
              <p className="text-sm text-amber-600 dark:text-amber-400">Level up for more daily spins!</p>
            </div>
          </div>
          <Button 
            onClick={() => setCurrentView('spin')}
            className="bg-amber-600 hover:bg-amber-700 text-amber-50"
          >
            Spin Now
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </CardContent>
      </Card>
      
      {/* Daily Streak & Bonus */}
      <div className="grid grid-cols-2 gap-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Flame className="h-4 w-4 text-orange-500" />
              Daily Streak
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-orange-500">{streakInfo?.currentStreak || 0}</p>
            <p className="text-xs text-muted-foreground">consecutive days</p>
            {streakInfo?.currentStreak && streakInfo.currentStreak < 7 && (
              <p className="text-xs text-orange-600 mt-1">
                Next reward: +{STREAK_REWARDS[streakInfo.currentStreak]} pts
              </p>
            )}
          </CardContent>
        </Card>
        
        <Card className={streakInfo?.canClaimBonus ? "border-primary bg-accent/50" : ""}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Gift className="h-4 w-4 text-primary" />
              Daily Bonus
            </CardTitle>
          </CardHeader>
          <CardContent>
            {streakInfo?.canClaimBonus ? (
              <Button 
                onClick={handleClaimBonus}
                className="w-full bg-primary hover:bg-primary/90"
                size="sm"
              >
                Claim +150 pts
              </Button>
            ) : (
              <p className="text-sm text-muted-foreground">Already claimed today</p>
            )}
          </CardContent>
        </Card>
      </div>
      
      {/* Level Progress */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <Trophy className="h-4 w-4 text-amber-500" />
            Level Progress
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-3 mb-2">
            <span className="text-2xl">{levelEmoji}</span>
            <div className="flex-1">
              <div className="flex justify-between">
                <span className="font-medium">{levelName}</span>
                {level < 7 && (
                  <span className="text-sm text-muted-foreground">
                    {levelInfo?.currentXP || 0} / {levelInfo?.nextLevelXP || '?'} XP
                  </span>
                )}
              </div>
              {level < 7 && (
                <Progress 
                  value={levelInfo?.xpProgress || 0} 
                  className="h-2 mt-1"
                />
              )}
            </div>
            {level < 7 && (
              <>
                <ArrowRight className="h-4 w-4 text-muted-foreground" />
                <span className="text-xl">{LEVEL_EMOJIS[level + 1]}</span>
              </>
            )}
          </div>
          {level < 7 && (
            <p className="text-xs text-muted-foreground">
              {levelInfo?.dailySpins || 5} daily spins • {LEVEL_NAMES[level + 1]} unlocks {(levelInfo?.nextLevelXP || 0) - (levelInfo?.currentXP || 0)} more XP
            </p>
          )}
        </CardContent>
      </Card>
      
      {/* Stats */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-accent" />
            Your Stats
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <p className="text-2xl font-bold text-primary">
                {(walletInfo?.totalEarned || 0).toLocaleString()}
              </p>
              <p className="text-xs text-muted-foreground">Total Earned</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-amber-600">
                {user?.totalSpinsCompleted || 0}
              </p>
              <p className="text-xs text-muted-foreground">Total Spins</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-accent">
                Rs. {(walletInfo?.totalWithdrawn || 0) * 0.1}
              </p>
              <p className="text-xs text-muted-foreground">Withdrawn</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
