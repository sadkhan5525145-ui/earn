'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Loader2, Sparkles } from 'lucide-react';

// Wheel segments configuration
const SEGMENTS = [
  { points: 50, color: '#22c55e', label: '50' },
  { points: 100, color: '#eab308', label: '100' },
  { points: 0, color: '#41431B', label: 'Try Again' },
  { points: 150, color: '#22c55e', label: '150' },
  { points: 300, color: '#f97316', label: '300' },
  { points: 0, color: '#41431B', label: 'Try Again' },
  { points: 500, color: '#ffd700', label: '500 ★', isJackpot: true },
  { points: 50, color: '#14b8a6', label: '50' },
  { points: 100, color: '#eab308', label: '100' },
  { points: 200, color: '#f97316', label: '200' },
  { points: 0, color: '#41431B', label: 'Try Again' },
  { points: 75, color: '#14b8a6', label: '75' },
];

const LEVEL_NAMES = ['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond', 'Master', 'Legend', 'Grandmaster'];
const LEVEL_EMOJIS = ['🥉', '🥈', '🥇', '💠', '💎', '🔮', '👑', '🌟'];

export function SpinWheel() {
  const { spinsRemaining, isSpinning, lastSpinResult, spin, user, levelInfo } = useAppStore();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [rotation, setRotation] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [confetti, setConfetti] = useState<Array<{ x: number; y: number; color: string; speed: number }>>([]);

  // Draw wheel
  const drawWheel = useCallback((currentRotation: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = Math.min(centerX, centerY) - 10;
    const segmentAngle = (2 * Math.PI) / SEGMENTS.length;
    
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.save();
    ctx.translate(centerX, centerY);
    ctx.rotate(currentRotation);
    
    // Draw segments
    SEGMENTS.forEach((segment, i) => {
      const startAngle = i * segmentAngle - Math.PI / 2;
      const endAngle = startAngle + segmentAngle;
      
      // Draw segment
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.arc(0, 0, radius, startAngle, endAngle);
      ctx.closePath();
      
      // Gradient fill
      const gradient = ctx.createRadialGradient(0, 0, 0, 0, 0, radius);
      gradient.addColorStop(0, segment.color);
      gradient.addColorStop(1, segment.isJackpot ? '#ffed4a' : segment.color);
      ctx.fillStyle = gradient;
      ctx.fill();
      
      // Border
      ctx.strokeStyle = '#AEB784';
      ctx.lineWidth = 2;
      ctx.stroke();
      
      // Text
      ctx.save();
      ctx.rotate(startAngle + segmentAngle / 2);
      ctx.textAlign = 'right';
      ctx.fillStyle = segment.points === 0 ? '#AEB784' : '#F8F3E1';
      ctx.font = segment.isJackpot ? 'bold 16px sans-serif' : 'bold 14px sans-serif';
      ctx.shadowColor = 'rgba(0,0,0,0.5)';
      ctx.shadowBlur = 4;
      ctx.fillText(segment.label, radius - 15, 5);
      ctx.restore();
    });
    
    // Center circle
    ctx.beginPath();
    ctx.arc(0, 0, 30, 0, 2 * Math.PI);
    ctx.fillStyle = '#41431B';
    ctx.fill();
    ctx.strokeStyle = '#AEB784';
    ctx.lineWidth = 3;
    ctx.stroke();
    
    // Center text
    ctx.fillStyle = '#AEB784';
    ctx.font = 'bold 12px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('SPIN', 0, 5);
    
    ctx.restore();
    
    // Draw pointer
    ctx.beginPath();
    ctx.moveTo(centerX, 5);
    ctx.lineTo(centerX - 15, 35);
    ctx.lineTo(centerX + 15, 35);
    ctx.closePath();
    ctx.fillStyle = '#ef4444';
    ctx.fill();
    ctx.strokeStyle = '#AEB784';
    ctx.lineWidth = 2;
    ctx.stroke();
  }, []);
  
  // Initial draw
  useEffect(() => {
    drawWheel(rotation);
  }, [rotation, drawWheel]);
  
  // Handle spin
  const handleSpin = async () => {
    if (isSpinning || spinsRemaining <= 0) return;
    
    const result = await spin();
    if (!result) return;
    
    setShowResult(false);
    
    // Calculate target rotation
    const segmentAngle = (2 * Math.PI) / SEGMENTS.length;
    const targetSegment = result.segmentIndex;
    // We need the segment to be at the top (pointer position)
    const targetAngle = -(targetSegment * segmentAngle + segmentAngle / 2) - Math.PI / 2;
    const fullRotations = 5 + Math.random() * 3; // 5-8 full rotations
    const finalRotation = rotation + fullRotations * 2 * Math.PI + (targetAngle - (rotation % (2 * Math.PI)));
    
    // Animate
    const startTime = Date.now();
    const duration = 4000; // 4 seconds
    const startRotation = rotation;
    
    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      // Ease out quartic
      const eased = 1 - Math.pow(1 - progress, 4);
      const currentRotation = startRotation + (finalRotation - startRotation) * eased;
      
      setRotation(currentRotation);
      drawWheel(currentRotation);
      
      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        setShowResult(true);
        
        // Confetti for wins
        if (result.pointsWon > 0) {
          const colors = ['#ffd700', '#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4', '#feca57'];
          const newConfetti = Array.from({ length: 50 }, () => ({
            x: Math.random() * 400,
            y: -20,
            color: colors[Math.floor(Math.random() * colors.length)],
            speed: 2 + Math.random() * 4
          }));
          setConfetti(newConfetti);
          
          setTimeout(() => setConfetti([]), 3000);
        }
      }
    };
    
    requestAnimationFrame(animate);
  };
  
  // Animate confetti
  useEffect(() => {
    if (confetti.length === 0) return;
    
    const interval = setInterval(() => {
      setConfetti(prev => prev
        .map(c => ({ ...c, y: c.y + c.speed }))
        .filter(c => c.y < 500)
      );
    }, 16);
    
    return () => clearInterval(interval);
  }, [confetti.length]);
  
  const levelName = levelInfo?.levelName || LEVEL_NAMES[user?.level || 0];
  const levelEmoji = LEVEL_EMOJIS[user?.level || 0];
  
  return (
    <div className="flex flex-col items-center gap-4">
      {/* Level Badge */}
      <div className="flex items-center gap-2 text-lg font-semibold text-amber-600 dark:text-amber-400">
        <span className="text-2xl">{levelEmoji}</span>
        <span>{levelName}</span>
      </div>
      
      {/* Spins Remaining */}
      <div className="text-center">
        <span className="text-3xl font-bold text-primary">{spinsRemaining}</span>
        <span className="text-muted-foreground ml-2">spins remaining today</span>
      </div>
      
      {/* Wheel Container */}
      <div className="relative">
        <canvas
          ref={canvasRef}
          width={320}
          height={320}
          className="rounded-full shadow-2xl"
        />
        
        {/* Confetti */}
        {confetti.map((c, i) => (
          <div
            key={i}
            className="absolute w-3 h-3 rounded-sm"
            style={{
              left: c.x,
              top: c.y,
              backgroundColor: c.color,
              transform: `rotate(${Math.random() * 360}deg)`
            }}
          />
        ))}
      </div>
      
      {/* Spin Button */}
      <Button
        size="lg"
        onClick={handleSpin}
        disabled={isSpinning || spinsRemaining <= 0}
        className="w-full max-w-xs h-14 text-xl font-bold bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 shadow-lg"
      >
        {isSpinning ? (
          <>
            <Loader2 className="mr-2 h-6 w-6 animate-spin" />
            Spinning...
          </>
        ) : spinsRemaining <= 0 ? (
          'No Spins Left'
        ) : (
          <>
            <Sparkles className="mr-2 h-5 w-5" />
            SPIN NOW!
          </>
        )}
      </Button>
      
      {/* Result Display */}
      {showResult && lastSpinResult && (
        <Card className={`w-full max-w-xs animate-pulse ${lastSpinResult.pointsWon > 0 ? 'bg-accent/30 border-primary' : 'bg-muted border-border'}`}>
          <CardContent className="pt-4 text-center">
            {lastSpinResult.pointsWon > 0 ? (
              <>
                <p className="text-4xl font-bold text-primary">
                  +{lastSpinResult.pointsWon} PTS!
                </p>
                <p className="text-lg text-amber-600 dark:text-amber-400">
                  = Rs. {(lastSpinResult.pointsWon * 0.1).toFixed(0)}
                </p>
                {lastSpinResult.levelUp && (
                  <p className="text-lg font-semibold text-accent mt-2">
                    🎉 Level Up! You&apos;re now {lastSpinResult.newLevel && LEVEL_NAMES[lastSpinResult.newLevel]}!
                  </p>
                )}
              </>
            ) : (
              <p className="text-xl text-muted-foreground">Try Again! Better luck next spin!</p>
            )}
            <p className="text-sm text-muted-foreground mt-2">
              +{lastSpinResult.xpEarned} XP
            </p>
          </CardContent>
        </Card>
      )}
      
      {/* No spins message */}
      {spinsRemaining <= 0 && !isSpinning && (
        <Card className="w-full max-w-xs bg-amber-100 dark:bg-amber-900/30 border-amber-300">
          <CardContent className="pt-4 text-center">
            <p className="text-amber-800 dark:text-amber-200 font-medium">
              You&apos;ve used all your daily spins!
            </p>
            <p className="text-sm text-amber-700 dark:text-amber-300 mt-1">
              Come back tomorrow for more chances to win.
            </p>
            <p className="text-xs text-amber-600 dark:text-amber-400 mt-2">
              Or level up to get more daily spins!
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
