'use client';

import { useAppStore, ViewType } from '@/store/useAppStore';
import { Home, RotateCcw, Wallet, ClipboardList, User, Gift, Users, Settings } from 'lucide-react';
import { cn } from '@/lib/utils';

interface NavItem {
  id: ViewType;
  label: string;
  icon: React.ReactNode;
}

const navItems: NavItem[] = [
  { id: 'home', label: 'Home', icon: <Home className="h-5 w-5" /> },
  { id: 'spin', label: 'Spin', icon: <RotateCcw className="h-5 w-5" /> },
  { id: 'wallet', label: 'Wallet', icon: <Wallet className="h-5 w-5" /> },
  { id: 'tasks', label: 'Tasks', icon: <ClipboardList className="h-5 w-5" /> },
  { id: 'profile', label: 'Profile', icon: <User className="h-5 w-5" /> },
];

export function BottomNav() {
  const { currentView, setCurrentView, user } = useAppStore();
  
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card border-t shadow-lg z-50 safe-area-pb">
      <div className="max-w-lg mx-auto flex justify-around items-center py-2">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setCurrentView(item.id)}
            className={cn(
              "flex flex-col items-center gap-1 px-4 py-2 rounded-lg transition-all min-w-[64px]",
              currentView === item.id
                ? "text-primary bg-accent"
                : "text-muted-foreground hover:text-foreground hover:bg-muted"
            )}
          >
            {item.icon}
            <span className="text-xs font-medium">{item.label}</span>
          </button>
        ))}
        
        {/* Admin Button */}
        {user?.isAdmin && (
          <button
            onClick={() => setCurrentView('admin')}
            className={cn(
              "flex flex-col items-center gap-1 px-4 py-2 rounded-lg transition-all min-w-[64px]",
              currentView === 'admin'
                ? "text-red-600 bg-red-100 dark:bg-red-900/30"
                : "text-muted-foreground hover:text-foreground hover:bg-muted"
            )}
          >
            <Settings className="h-5 w-5" />
            <span className="text-xs font-medium">Admin</span>
          </button>
        )}
      </div>
    </nav>
  );
}

// Quick action buttons for Home view
export function QuickActions() {
  const { setCurrentView } = useAppStore();
  
  const actions = [
    { id: 'spin' as ViewType, label: 'Spin', icon: <RotateCcw className="h-6 w-6" />, color: 'bg-amber-600' },
    { id: 'wallet' as ViewType, label: 'Withdraw', icon: <Wallet className="h-6 w-6" />, color: 'bg-primary' },
    { id: 'referral' as ViewType, label: 'Refer', icon: <Users className="h-6 w-6" />, color: 'bg-accent' },
    { id: 'achievements' as ViewType, label: 'Badges', icon: <Gift className="h-6 w-6" />, color: 'bg-amber-700' },
  ];
  
  return (
    <div className="grid grid-cols-4 gap-3">
      {actions.map((action) => (
        <button
          key={action.id}
          onClick={() => setCurrentView(action.id)}
          className={`${action.color} text-primary-foreground rounded-xl p-3 flex flex-col items-center gap-1 shadow-md hover:shadow-lg transition-all active:scale-95`}
        >
          {action.icon}
          <span className="text-xs font-medium">{action.label}</span>
        </button>
      ))}
    </div>
  );
}
