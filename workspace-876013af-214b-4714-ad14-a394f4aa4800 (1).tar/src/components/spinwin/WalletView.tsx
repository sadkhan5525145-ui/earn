'use client';

import { useEffect, useState } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Coins, ArrowUpRight, Clock, CheckCircle, XCircle, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function WalletView() {
  const { 
    user, 
    walletInfo, 
    withdrawals,
    fetchWallet, 
    fetchWithdrawals,
    requestWithdrawal
  } = useAppStore();
  const { toast } = useToast();
  
  const [withdrawMethod, setWithdrawMethod] = useState('easypaisa');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [cnicLast6, setCnicLast6] = useState('');
  const [accountName, setAccountName] = useState('');
  const [bankName, setBankName] = useState('');
  const [submitting, setSubmitting] = useState(false);
  
  useEffect(() => {
    fetchWallet();
    fetchWithdrawals();
  }, [fetchWallet, fetchWithdrawals]);
  
  const balance = user?.pointsBalance || 0;
  const rsEquivalent = balance * 0.1;
  const progressToWithdraw = Math.min((balance / 3000) * 100, 100);
  
  const handleWithdraw = async () => {
    const points = parseInt(withdrawAmount);
    
    if (!points || points < 3000) {
      toast({
        title: "Invalid Amount",
        description: "Minimum withdrawal is 3,000 points (Rs. 300)",
        variant: "destructive"
      });
      return;
    }
    
    if (points > 50000) {
      toast({
        title: "Invalid Amount",
        description: "Maximum withdrawal is 50,000 points (Rs. 5,000)",
        variant: "destructive"
      });
      return;
    }
    
    if (points > balance) {
      toast({
        title: "Insufficient Balance",
        description: "You don't have enough points",
        variant: "destructive"
      });
      return;
    }
    
    if (!accountNumber) {
      toast({
        title: "Missing Information",
        description: "Please enter your account number",
        variant: "destructive"
      });
      return;
    }
    
    if ((withdrawMethod === 'easypaisa' || withdrawMethod === 'jazzcash') && !cnicLast6) {
      toast({
        title: "Missing Information",
        description: "Please enter the last 6 digits of your CNIC",
        variant: "destructive"
      });
      return;
    }
    
    setSubmitting(true);
    
    const result = await requestWithdrawal({
      method: withdrawMethod,
      points,
      accountNumber,
      cnicLast6: cnicLast6 || undefined,
      accountName: accountName || undefined,
      bankName: bankName || undefined
    });
    
    setSubmitting(false);
    
    if (result.success) {
      toast({
        title: "Withdrawal Requested!",
        description: `Rs. ${(points * 0.1).toFixed(0)} will be sent within 1-3 days`,
      });
      setWithdrawAmount('');
      setAccountNumber('');
      setCnicLast6('');
      setAccountName('');
      setBankName('');
    } else {
      toast({
        title: "Withdrawal Failed",
        description: result.message || "Please try again",
        variant: "destructive"
      });
    }
  };
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="secondary" className="gap-1"><Clock className="h-3 w-3" /> Pending</Badge>;
      case 'approved':
      case 'processed':
        return <Badge variant="default" className="gap-1 bg-primary"><CheckCircle className="h-3 w-3" /> Processed</Badge>;
      case 'rejected':
        return <Badge variant="destructive" className="gap-1"><XCircle className="h-3 w-3" /> Rejected</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };
  
  return (
    <div className="max-w-lg mx-auto space-y-4">
      {/* Balance Card */}
      <Card className="bg-gradient-to-br from-primary to-accent">
        <CardContent className="pt-6">
          <div className="flex items-center gap-2 text-primary-foreground/80 mb-2">
            <Coins className="h-5 w-5" />
            <span>Total Balance</span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-5xl font-bold text-primary-foreground">{balance.toLocaleString()}</span>
            <span className="text-xl text-primary-foreground/70">points</span>
          </div>
          <p className="text-2xl font-medium text-primary-foreground/80 mt-1">= Rs. {rsEquivalent.toFixed(0)}</p>
          
          {/* Progress */}
          <div className="mt-4">
            <div className="flex justify-between text-sm text-primary-foreground/70 mb-1">
              <span>Progress to Withdrawal</span>
              <span>{progressToWithdraw.toFixed(0)}%</span>
            </div>
            <Progress value={progressToWithdraw} className="h-3 bg-primary-foreground/20" />
          </div>
        </CardContent>
      </Card>
      
      {/* Withdrawal Form */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ArrowUpRight className="h-5 w-5" />
            Withdraw Funds
          </CardTitle>
        </CardHeader>
        <CardContent>
          {balance < 3000 ? (
            <div className="text-center py-4 text-muted-foreground">
              <p>You need at least 3,000 points to withdraw</p>
              <p className="text-sm mt-1">You need {(3000 - balance).toLocaleString()} more points</p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Withdrawal Method</Label>
                <Select value={withdrawMethod} onValueChange={setWithdrawMethod}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="easypaisa">📱 Easypaisa</SelectItem>
                    <SelectItem value="jazzcash">📱 JazzCash</SelectItem>
                    <SelectItem value="bank">🏦 Bank Transfer</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>Points to Withdraw</Label>
                <Input
                  type="number"
                  placeholder="Min 3,000 - Max 50,000"
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(e.target.value)}
                />
                <p className="text-xs text-muted-foreground">
                  You will receive: Rs. {((parseInt(withdrawAmount) || 0) * 0.1).toFixed(0)}
                </p>
              </div>
              
              {(withdrawMethod === 'easypaisa' || withdrawMethod === 'jazzcash') && (
                <>
                  <div className="space-y-2">
                    <Label>{withdrawMethod === 'easypaisa' ? 'Easypaisa' : 'JazzCash'} Number</Label>
                    <Input
                      type="tel"
                      placeholder="03xx-xxxxxxx"
                      value={accountNumber}
                      onChange={(e) => setAccountNumber(e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>CNIC Last 6 Digits</Label>
                    <Input
                      type="text"
                      placeholder="123456"
                      maxLength={6}
                      value={cnicLast6}
                      onChange={(e) => setCnicLast6(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    />
                  </div>
                </>
              )}
              
              {withdrawMethod === 'bank' && (
                <>
                  <div className="space-y-2">
                    <Label>Bank Name</Label>
                    <Input
                      type="text"
                      placeholder="e.g., HBL, UBL, Meezan"
                      value={bankName}
                      onChange={(e) => setBankName(e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Account Number</Label>
                    <Input
                      type="text"
                      placeholder="Your bank account number"
                      value={accountNumber}
                      onChange={(e) => setAccountNumber(e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Account Holder Name</Label>
                    <Input
                      type="text"
                      placeholder="Name on the account"
                      value={accountName}
                      onChange={(e) => setAccountName(e.target.value)}
                    />
                  </div>
                </>
              )}
              
              <Button 
                onClick={handleWithdraw}
                className="w-full"
                disabled={submitting}
              >
                {submitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  'Request Withdrawal'
                )}
              </Button>
              
              <p className="text-xs text-center text-muted-foreground">
                Processing time: 1-3 business days
              </p>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Withdrawal History */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-sm">
            <Clock className="h-4 w-4" />
            Withdrawal History
          </CardTitle>
        </CardHeader>
        <CardContent>
          {withdrawals && withdrawals.length > 0 ? (
            <div className="space-y-3 max-h-60 overflow-y-auto">
              {withdrawals.map((w) => (
                <div key={w.id} className="flex justify-between items-center p-3 bg-muted rounded-lg">
                  <div>
                    <p className="font-medium capitalize">{w.method}</p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(w.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold">Rs. {w.rsAmount.toFixed(0)}</p>
                    {getStatusBadge(w.status)}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground text-center py-4">
              No withdrawals yet
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
