'use client';

import { useAppStore } from '@/store/useAppStore';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { LogOut, Coins, Wifi, WifiOff, Users } from 'lucide-react';
import { ThemeToggle } from '@/components/ThemeToggle';
import { useRealtime } from '@/components/RealtimeProvider';

const LEVEL_NAMES = ['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond', 'Master', 'Legend', 'Grandmaster'];
const LEVEL_EMOJIS = ['🥉', '🥈', '🥇', '💠', '💎', '🔮', '👑', '🌟'];
const LEVEL_COLORS = ['text-amber-700', 'text-gray-400', 'text-yellow-500', 'text-cyan-400', 'text-blue-400', 'text-purple-500', 'text-amber-400', 'text-amber-300'];

export function Header() {
  const { user, logout, levelInfo } = useAppStore();
  const { isConnected, onlineUsers } = useRealtime();
  
  const level = user?.level || 0;
  const levelName = levelInfo?.levelName || LEVEL_NAMES[level];
  const levelEmoji = LEVEL_EMOJIS[level];
  const levelColor = LEVEL_COLORS[level];
  
  const handleLogout = async () => {
    await logout();
  };
  
  return (
    <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-sm border-b shadow-sm">
      <div className="max-w-lg mx-auto px-4 py-3 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-2">
          <span className="text-2xl">🎰</span>
          <h1 className="text-xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            SpinWin
          </h1>
          {/* Connection Status */}
          <div className="flex items-center gap-1">
            {isConnected ? (
              <Wifi className="h-3.5 w-3.5 text-primary" />
            ) : (
              <WifiOff className="h-3.5 w-3.5 text-muted-foreground animate-pulse" />
            )}
          </div>
        </div>
        
        {/* Balance & Level */}
        <div className="flex items-center gap-2">
          {/* Online Users */}
          {onlineUsers > 0 && (
            <Badge variant="outline" className="gap-1 text-xs">
              <Users className="h-3 w-3" />
              {onlineUsers}
            </Badge>
          )}
          
          {/* Points */}
          <div className="flex items-center gap-1 bg-secondary px-3 py-1.5 rounded-full">
            <Coins className="h-4 w-4 text-primary" />
            <span className="font-bold text-primary">
              {(user?.pointsBalance || 0).toLocaleString()}
            </span>
          </div>
          
          {/* Level Badge */}
          <Badge variant="secondary" className={`gap-1 ${levelColor}`}>
            <span>{levelEmoji}</span>
            <span className="hidden sm:inline">{levelName}</span>
          </Badge>
          
          {/* Theme Toggle */}
          <ThemeToggle />
          
          {/* Logout */}
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={handleLogout}
            className="text-muted-foreground hover:text-red-500"
          >
            <LogOut className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </header>
  );
}
