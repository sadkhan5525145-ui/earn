'use client';

import { useState } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, Sparkles } from 'lucide-react';

export function AuthScreen() {
  const { login, register, isLoading } = useAppStore();
  const [activeTab, setActiveTab] = useState('login');
  
  // Login state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  
  // Register state
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regReferral, setRegReferral] = useState('');
  const [regError, setRegError] = useState('');
  
  const [submitting, setSubmitting] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setSubmitting(true);
    
    const result = await login(loginEmail, loginPassword);
    
    if (!result.success) {
      setLoginError(result.message || 'Login failed');
    }
    setSubmitting(false);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setRegError('');
    
    if (!regName || !regEmail || !regPhone || !regPassword) {
      setRegError('All fields are required');
      return;
    }
    
    if (regPassword.length < 8) {
      setRegError('Password must be at least 8 characters');
      return;
    }
    
    if (!/^03\d{2}-?\d{7}$/.test(regPhone.replace('-', ''))) {
      setRegError('Invalid Pakistani mobile number (03xx-xxxxxxx)');
      return;
    }
    
    setSubmitting(true);
    
    const result = await register({
      name: regName,
      email: regEmail,
      phone: regPhone,
      password: regPassword,
      referralCode: regReferral || undefined
    });
    
    if (!result.success) {
      setRegError(result.message || 'Registration failed');
    }
    setSubmitting(false);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-background">
      {/* Logo */}
      <div className="text-center mb-8">
        <div className="flex items-center justify-center gap-2 mb-2">
          <Sparkles className="h-10 w-10 text-accent" />
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            SpinWin
          </h1>
        </div>
        <p className="text-muted-foreground">Spin. Earn. Withdraw Real Cash!</p>
        <p className="text-sm text-accent font-medium mt-1">100 Points = Rs. 10</p>
      </div>

      <Card className="w-full max-w-md shadow-xl">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <CardHeader className="pb-2">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">Login</TabsTrigger>
              <TabsTrigger value="register">Register</TabsTrigger>
            </TabsList>
          </CardHeader>
          
          <CardContent>
            <TabsContent value="login" className="mt-0">
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="login-email">Email</Label>
                  <Input
                    id="login-email"
                    type="email"
                    placeholder="your@email.com"
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="login-password">Password</Label>
                  <Input
                    id="login-password"
                    type="password"
                    placeholder="••••••••"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    required
                  />
                </div>
                
                {loginError && (
                  <p className="text-sm text-destructive">{loginError}</p>
                )}
                
                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={submitting}
                >
                  {submitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Logging in...
                    </>
                  ) : (
                    'Login'
                  )}
                </Button>
              </form>
            </TabsContent>
            
            <TabsContent value="register" className="mt-0">
              <form onSubmit={handleRegister} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="reg-name">Full Name</Label>
                  <Input
                    id="reg-name"
                    type="text"
                    placeholder="Your Name"
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="reg-email">Email</Label>
                  <Input
                    id="reg-email"
                    type="email"
                    placeholder="your@email.com"
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="reg-phone">Mobile Number</Label>
                  <Input
                    id="reg-phone"
                    type="tel"
                    placeholder="0300-1234567"
                    value={regPhone}
                    onChange={(e) => setRegPhone(e.target.value)}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="reg-password">Password</Label>
                  <Input
                    id="reg-password"
                    type="password"
                    placeholder="Min 8 characters"
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="reg-referral">Referral Code (Optional)</Label>
                  <Input
                    id="reg-referral"
                    type="text"
                    placeholder="SPIN####"
                    value={regReferral}
                    onChange={(e) => setRegReferral(e.target.value.toUpperCase())}
                  />
                  <p className="text-xs text-muted-foreground">
                    Get 500 bonus points with a valid referral code!
                  </p>
                </div>
                
                {regError && (
                  <p className="text-sm text-destructive">{regError}</p>
                )}
                
                <Button 
                  type="submit" 
                  className="w-full bg-accent hover:bg-accent/90"
                  disabled={submitting}
                >
                  {submitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Creating Account...
                    </>
                  ) : (
                    'Create Account'
                  )}
                </Button>
              </form>
            </TabsContent>
          </CardContent>
        </Tabs>
      </Card>
      
      {/* Features */}
      <div className="mt-8 grid grid-cols-3 gap-4 text-center max-w-md">
        <div className="p-3 rounded-lg bg-card border">
          <p className="text-2xl font-bold text-primary">5</p>
          <p className="text-xs text-muted-foreground">Free Daily Spins</p>
        </div>
        <div className="p-3 rounded-lg bg-card border">
          <p className="text-2xl font-bold text-accent">Rs.300</p>
          <p className="text-xs text-muted-foreground">Min Withdrawal</p>
        </div>
        <div className="p-3 rounded-lg bg-card border">
          <p className="text-2xl font-bold text-primary">Rs.50</p>
          <p className="text-xs text-muted-foreground">Per Referral</p>
        </div>
      </div>
    </div>
  );
}
