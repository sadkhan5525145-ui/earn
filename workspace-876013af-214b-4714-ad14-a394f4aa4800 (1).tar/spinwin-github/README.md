# 🎡 SpinWin - Earn Points, Win Rewards!

A gamified points-based earning web app with real-time cross-tab synchronization. Spin the wheel, complete tasks, and win rewards!

![SpinWin Banner](https://img.shields.io/badge/SpinWin-Earn%20Points%2C%20Win%20Rewards!-84cc16?style=for-the-badge)

## ✨ Features

### 🎰 Spin Wheel
- Animated spinning wheel with 8 prize segments
- Jackpot system that grows with each spin
- Prize chances: 10pts (25%), 25pts (20%), 50pts (15%), 100pts (10%), 200pts (7%), 500pts (5%), 1000pts (3%), Jackpot (1%)

### 💰 Points System
- Start with 100 bonus points
- Earn points by spinning, completing tasks, and referrals
- Level up every 1000 points earned
- Track biggest wins and statistics

### 📋 Tasks
- 10 different task types to complete
- Daily login bonuses
- Video ads, surveys, social sharing
- Earn bonus points for achievements

### 💳 Wallet
- Withdraw to Easypaisa, JazzCash, or Bank Transfer
- Track transaction history
- Minimum withdrawal: 1000 points
- Real-time balance updates

### 🏆 Leaderboard
- Top earners ranking
- Compete with other players
- Monthly rankings

### 🎖️ Achievements
- Unlock badges for milestones
- First spin, spin master, point collector
- Level achievements and more

### 👥 Referral System
- Unique referral code
- Earn 100 points per referral
- Share with friends easily

### 🌙 Dark Mode
- Full dark mode support
- Automatic theme saving
- Smooth transitions

### ⚡ Real-Time Sync
- Cross-tab synchronization using BroadcastChannel API
- See spin results from other tabs
- Jackpot alerts across all tabs
- Admin announcements

### 🔐 Admin Panel
- Full management dashboard
- Approve/reject withdrawals
- Add bonus points
- Trigger jackpots
- Broadcast messages

**Default Admin Password:** `admin123`

## 🚀 Deploy to GitHub Pages

### Method 1: Quick Deploy

1. **Create a new repository** on GitHub

2. **Upload files:**
   - Upload `index.html` to your repository root

3. **Enable GitHub Pages:**
   - Go to repository **Settings** → **Pages**
   - Under "Source", select **Deploy from a branch**
   - Select **main** branch and **/ (root)** folder
   - Click **Save**

4. **Access your site:**
   - Your site will be live at: `https://yourusername.github.io/repository-name/`

### Method 2: Clone and Deploy

```bash
# Clone this repository
git clone https://github.com/yourusername/spinwin.git

# Navigate to the folder
cd spinwin-github

# Initialize git
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit - SpinWin app"

# Add your GitHub repository as remote
git remote add origin https://github.com/yourusername/spinwin.git

# Push to GitHub
git push -u origin main
```

Then enable GitHub Pages in repository settings.

### Method 3: GitHub Desktop

1. Download [GitHub Desktop](https://desktop.github.com/)
2. Create a new repository
3. Copy `index.html` to the repository folder
4. Commit and push
5. Enable GitHub Pages in settings

## 🛠️ Technical Details

### Technologies Used
- **HTML5** - Semantic markup
- **Tailwind CSS** (via CDN) - Styling
- **Vanilla JavaScript** - No frameworks needed
- **localStorage** - Data persistence
- **BroadcastChannel API** - Cross-tab sync

### Browser Support
- ✅ Chrome 54+
- ✅ Firefox 38+
- ✅ Safari 15.4+
- ✅ Edge 79+
- ✅ Opera 41+

### Data Storage
All data is stored in browser's localStorage under the key `spinwin_data_v2`:
- User profile and points
- Transaction history
- Tasks completion status
- Withdrawals
- Settings

### Cross-Tab Sync
The app uses BroadcastChannel API for real-time synchronization between open tabs:
- Data updates sync automatically
- Spin events broadcast to all tabs
- Jackpot alerts show on all tabs
- Admin announcements reach all users

## 📱 Responsive Design

- Mobile-first approach
- Works on all screen sizes
- Touch-friendly interface
- Optimized for both portrait and landscape

## 🎨 Customization

### Change Colors
Edit the Tailwind config in `index.html`:

```javascript
tailwind.config = {
    theme: {
        extend: {
            colors: {
                primary: {
                    500: '#84cc16', // Main brand color
                    // ... other shades
                }
            }
        }
    }
}
```

### Change Admin Password
Find and modify this line in the JavaScript:

```javascript
const ADMIN_PASSWORD = 'admin123';
```

### Modify Prize Chances
Edit the `wheelPrizes` array:

```javascript
const wheelPrizes = [
    { label: '10', value: 10, color: '#84cc16', chance: 25 },
    // ... adjust chance percentages
];
```

## 🔒 Security Notes

- All data is stored locally in the browser
- No server-side validation (client-side only)
- Admin password is visible in source code (change for production)
- For production use, implement proper backend authentication

## 📄 License

MIT License - Feel free to use, modify, and distribute.

## 🤝 Contributing

Contributions are welcome! Feel free to:
- Report bugs
- Suggest features
- Submit pull requests

## 📞 Support

For issues or questions, please open a GitHub issue.

---

**Made with ❤️ for the SpinWin community**

![GitHub stars](https://img.shields.io/github/stars/yourusername/spinwin?style=social)
![GitHub forks](https://img.shields.io/github/forks/yourusername/spinwin?style=social)
