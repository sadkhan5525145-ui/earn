import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  const email = 'saadking3132@gmail.com';
  const phone = '03258356212';
  const password = 'Saadmalik99$';
  const name = 'Saad Admin';

  // Check if admin already exists
  const existingAdmin = await prisma.user.findUnique({
    where: { email }
  });

  if (existingAdmin) {
    console.log('Admin user already exists!');
    
    // Make sure they have admin privileges
    if (!existingAdmin.isAdmin) {
      await prisma.user.update({
        where: { email },
        data: { isAdmin: true }
      });
      console.log('Updated user to admin!');
    }
    
    return;
  }

  // Hash password
  const passwordHash = await bcrypt.hash(password, 10);

  // Generate unique referral code
  const referralCode = 'ADMIN' + Math.random().toString(36).substring(2, 6).toUpperCase();

  // Create admin user
  const admin = await prisma.user.create({
    data: {
      email,
      phone,
      name,
      passwordHash,
      authProvider: 'email',
      isVerified: true,
      isAdmin: true,
      referralCode,
      level: 7, // Grandmaster level
      xp: 100000, // High XP
      pointsBalance: 0,
      dailySpinsRemaining: 100, // Extra spins
    }
  });

  console.log('Admin user created successfully!');
  console.log({
    id: admin.id,
    email: admin.email,
    name: admin.name,
    referralCode: admin.referralCode
  });
}

main()
  .catch((e) => {
    console.error('Error creating admin:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
