import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Task definitions
const tasks = [
  // Daily Tasks
  {
    taskId: 'watch_youtube',
    name: 'Watch YouTube Video',
    description: 'Watch a short YouTube video to earn points. Videos update daily.',
    pointsReward: 80,
    xpReward: 10,
    type: 'daily',
    category: 'video',
    link: 'https://youtube.com/@spinwin',
  },
  {
    taskId: 'share_app',
    name: 'Share App with 3 Friends',
    description: 'Share SpinWin with 3 friends via WhatsApp, Facebook, or any platform.',
    pointsReward: 200,
    xpReward: 15,
    type: 'daily',
    category: 'social',
    link: null,
  },
  {
    taskId: 'daily_quiz',
    name: 'Complete Daily Quiz',
    description: 'Answer 5 simple questions correctly to earn bonus points.',
    pointsReward: 300,
    xpReward: 20,
    type: 'daily',
    category: 'quiz',
    link: null,
  },

  // One-Time Tasks
  {
    taskId: 'follow_facebook',
    name: 'Follow Facebook Page',
    description: 'Follow our official Facebook page for updates and exclusive offers.',
    pointsReward: 100,
    xpReward: 10,
    type: 'onetime',
    category: 'social',
    link: 'https://facebook.com/spinwin',
  },
  {
    taskId: 'join_telegram',
    name: 'Join Telegram Channel',
    description: 'Join our Telegram channel for instant updates and tips.',
    pointsReward: 150,
    xpReward: 15,
    type: 'onetime',
    category: 'social',
    link: 'https://t.me/spinwin',
  },
  {
    taskId: 'rate_app',
    name: 'Rate App 5 Stars',
    description: 'Rate SpinWin 5 stars on the Play Store to support us!',
    pointsReward: 250,
    xpReward: 25,
    type: 'onetime',
    category: 'social',
    link: 'https://play.google.com/store/apps/details?id=pk.spinwin',
  },
  {
    taskId: 'follow_instagram',
    name: 'Follow Instagram',
    description: 'Follow our Instagram page for daily winner announcements.',
    pointsReward: 120,
    xpReward: 12,
    type: 'onetime',
    category: 'social',
    link: 'https://instagram.com/spinwin',
  },

  // Weekly Tasks
  {
    taskId: 'refer_friend',
    name: 'Refer 1 Friend This Week',
    description: 'Get a friend to sign up using your referral code this week.',
    pointsReward: 200,
    xpReward: 0,
    type: 'weekly',
    category: 'social',
    link: null,
  },
  {
    taskId: 'complete_spins',
    name: 'Complete 20 Spins This Week',
    description: 'Spin the wheel 20 times this week to unlock this bonus.',
    pointsReward: 400,
    xpReward: 0,
    type: 'weekly',
    category: 'spin',
    link: null,
  },
];

// Achievement definitions
const achievements = [
  {
    badgeId: 'first_spin',
    name: 'First Spin',
    description: 'Complete your first spin on the wheel',
    icon: '🎡',
    pointsReward: 50,
    condition: JSON.stringify({ type: 'spins', count: 1 }),
    category: 'spins',
  },
  {
    badgeId: 'first_100',
    name: 'First 100 Points',
    description: 'Earn your first 100 points',
    icon: '⭐',
    pointsReward: 50,
    condition: JSON.stringify({ type: 'points', count: 100 }),
    category: 'general',
  },
  {
    badgeId: 'spin_master',
    name: 'Spin Master',
    description: 'Complete 10 spins on the wheel',
    icon: '🔟',
    pointsReward: 200,
    condition: JSON.stringify({ type: 'spins', count: 10 }),
    category: 'spins',
  },
  {
    badgeId: 'first_cashout',
    name: 'First Cashout',
    description: 'Successfully withdraw 3,000 points or more',
    icon: '💸',
    pointsReward: 500,
    condition: JSON.stringify({ type: 'withdrawal', count: 1 }),
    category: 'withdrawal',
  },
  {
    badgeId: 'referral_king',
    name: 'Referral King',
    description: 'Refer 5 friends who complete signup',
    icon: '👥',
    pointsReward: 1000,
    condition: JSON.stringify({ type: 'referrals', count: 5 }),
    category: 'referral',
  },
  {
    badgeId: 'week_warrior',
    name: 'Week Warrior',
    description: 'Complete a 7-day login streak',
    icon: '🔥',
    pointsReward: 700,
    condition: JSON.stringify({ type: 'streak', count: 7 }),
    category: 'streak',
  },
  {
    badgeId: 'task_champion',
    name: 'Task Champion',
    description: 'Complete 20 tasks',
    icon: '✅',
    pointsReward: 400,
    condition: JSON.stringify({ type: 'tasks', count: 20 }),
    category: 'general',
  },
  {
    badgeId: 'high_roller',
    name: 'High Roller',
    description: 'Win the 500 points jackpot 3 times',
    icon: '🎰',
    pointsReward: 600,
    condition: JSON.stringify({ type: 'jackpot', count: 3 }),
    category: 'spins',
  },
  {
    badgeId: 'social_star',
    name: 'Social Star',
    description: 'Complete all social media tasks',
    icon: '📱',
    pointsReward: 300,
    condition: JSON.stringify({ type: 'social_tasks', count: 4 }),
    category: 'social',
  },
  {
    badgeId: 'loyal_user',
    name: 'Loyal User',
    description: 'Login for 30 consecutive days',
    icon: '📅',
    pointsReward: 2000,
    condition: JSON.stringify({ type: 'streak', count: 30 }),
    category: 'streak',
  },
  {
    badgeId: 'big_spender',
    name: 'Big Spender',
    description: 'Withdraw a total of 10,000 points',
    icon: '💰',
    pointsReward: 1500,
    condition: JSON.stringify({ type: 'total_withdrawn', count: 10000 }),
    category: 'withdrawal',
  },
  {
    badgeId: 'grandmaster',
    name: 'Grandmaster',
    description: 'Reach the highest level (Grandmaster)',
    icon: '🌟',
    pointsReward: 5000,
    condition: JSON.stringify({ type: 'level', count: 7 }),
    category: 'general',
  },
];

async function main() {
  console.log('🌱 Starting seed...');

  // Clear existing data
  await prisma.task.deleteMany({});
  await prisma.achievement.deleteMany({});
  console.log('🗑️ Cleared existing data');

  // Insert tasks
  for (const task of tasks) {
    await prisma.task.create({
      data: task,
    });
    console.log(`✅ Created task: ${task.name}`);
  }

  // Insert achievements
  for (const achievement of achievements) {
    await prisma.achievement.create({
      data: achievement,
    });
    console.log(`🏆 Created achievement: ${achievement.name}`);
  }

  console.log('🌱 Seed completed successfully!');
  console.log(`📊 Total tasks created: ${tasks.length}`);
  console.log(`🏆 Total achievements created: ${achievements.length}`);
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
