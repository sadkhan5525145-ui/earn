import { createServer } from 'http'
import { Server, Socket } from 'socket.io'

const httpServer = createServer()
const io = new Server(httpServer, {
  path: '/',
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  },
  pingTimeout: 60000,
  pingInterval: 25000,
})

// User connection tracking
interface ConnectedUser {
  id: string
  userId: string
  isAdmin: boolean
  socketId: string
  connectedAt: Date
}

const connectedUsers = new Map<string, ConnectedUser>()
const userSocketMap = new Map<string, Set<string>>() // userId -> Set of socketIds

// Helper to get online users count
const getOnlineCount = () => connectedUsers.size

// Helper to check if user is online
const isUserOnline = (userId: string) => userSocketMap.has(userId)

// Helper to get user's sockets
const getUserSockets = (userId: string): Socket[] => {
  const socketIds = userSocketMap.get(userId)
  if (!socketIds) return []
  const sockets: Socket[] = []
  socketIds.forEach(id => {
    const socket = io.sockets.sockets.get(id)
    if (socket) sockets.push(socket)
  })
  return sockets
}

// Broadcast to all connected clients
const broadcastToAll = (event: string, data: any) => {
  io.emit(event, data)
}

// Broadcast to specific user
const broadcastToUser = (userId: string, event: string, data: any) => {
  const sockets = getUserSockets(userId)
  sockets.forEach(socket => socket.emit(event, data))
}

// Broadcast to all admins
const broadcastToAdmins = (event: string, data: any) => {
  connectedUsers.forEach((user) => {
    if (user.isAdmin) {
      const socket = io.sockets.sockets.get(user.socketId)
      if (socket) socket.emit(event, data)
    }
  })
}

io.on('connection', (socket: Socket) => {
  console.log(`[WS] Client connected: ${socket.id}`)
  
  // Send connection acknowledgment
  socket.emit('connected', { 
    socketId: socket.id,
    serverTime: new Date().toISOString()
  })

  // User authentication/identification
  socket.on('authenticate', (data: { userId: string; isAdmin?: boolean }) => {
    const { userId, isAdmin = false } = data
    
    // Store user connection
    const user: ConnectedUser = {
      id: socket.id,
      userId,
      isAdmin,
      socketId: socket.id,
      connectedAt: new Date()
    }
    connectedUsers.set(socket.id, user)
    
    // Update user socket map
    if (!userSocketMap.has(userId)) {
      userSocketMap.set(userId, new Set())
    }
    userSocketMap.get(userId)!.add(socket.id)
    
    console.log(`[WS] User authenticated: ${userId} (Admin: ${isAdmin})`)
    
    // Send acknowledgment
    socket.emit('authenticated', { 
      success: true, 
      userId,
      onlineUsers: getOnlineCount()
    })
    
    // Broadcast online count update
    broadcastToAll('online-count', { count: getOnlineCount() })
  })

  // === SPIN EVENTS ===
  
  // Listen for spin results from backend API (will be emitted via internal call)
  socket.on('spin-result', (data: { 
    userId: string
    pointsWon: number
    xpEarned: number
    newBalance: number
    segmentIndex: number 
  }) => {
    // Broadcast to the specific user
    broadcastToUser(data.userId, 'spin:result', data)
    
    // If big win, announce to all
    if (data.pointsWon >= 300) {
      broadcastToAll('spin:jackpot', {
        userId: data.userId,
        pointsWon: data.pointsWon
      })
    }
  })

  // === WALLET EVENTS ===
  
  // Balance update
  socket.on('balance-update', (data: {
    userId: string
    pointsBalance: number
    rsEquivalent: number
    change: number
    reason: string
  }) => {
    broadcastToUser(data.userId, 'wallet:balance', data)
  })

  // === WITHDRAWAL EVENTS ===
  
  // New withdrawal request (notify admins)
  socket.on('withdrawal-request', (data: {
    withdrawalId: string
    userId: string
    userName: string
    method: string
    pointsRequested: number
    rsAmount: number
    createdAt: string
  }) => {
    broadcastToAdmins('admin:withdrawal:new', data)
  })

  // Withdrawal status update
  socket.on('withdrawal-update', (data: {
    withdrawalId: string
    userId: string
    status: string
    adminNote?: string
    processedAt?: string
  }) => {
    broadcastToUser(data.userId, 'withdrawal:status', data)
  })

  // === TASK EVENTS ===
  
  // Task completed
  socket.on('task-completed', (data: {
    userId: string
    taskId: string
    taskName: string
    pointsAwarded: number
    xpAwarded: number
  }) => {
    broadcastToUser(data.userId, 'task:completed', data)
  })

  // Task added/updated by admin (broadcast to all)
  socket.on('task-updated', (data: {
    action: 'created' | 'updated' | 'deleted' | 'toggled'
    task: any
  }) => {
    broadcastToAll('tasks:refresh', data)
  })

  // === LEADERBOARD EVENTS ===
  
  // Leaderboard update (weekly)
  socket.on('leaderboard-update', (data: {
    leaderboard: Array<{
      rank: number
      userId: string
      name: string
      points: number
    }>
  }) => {
    broadcastToAll('leaderboard:update', data)
  })

  // === ACHIEVEMENT EVENTS ===
  
  // Achievement unlocked
  socket.on('achievement-unlocked', (data: {
    userId: string
    achievementId: string
    achievementName: string
    pointsReward: number
    icon: string
  }) => {
    broadcastToUser(data.userId, 'achievement:unlocked', data)
    
    // Announce rare achievements to all
    if (data.pointsReward >= 500) {
      broadcastToAll('achievement:rare', data)
    }
  })

  // === LEVEL EVENTS ===
  
  // Level up
  socket.on('level-up', (data: {
    userId: string
    newLevel: number
    levelName: string
    rewards: any
  }) => {
    broadcastToUser(data.userId, 'level:up', data)
    
    // Announce high level ups
    if (data.newLevel >= 5) {
      broadcastToAll('level:milestone', data)
    }
  })

  // === REFERRAL EVENTS ===
  
  // New referral
  socket.on('referral-new', (data: {
    referrerId: string
    referredName: string
    status: string
  }) => {
    broadcastToUser(data.referrerId, 'referral:new', data)
  })

  // Referral rewarded
  socket.on('referral-rewarded', (data: {
    referrerId: string
    referredName: string
    pointsEarned: number
  }) => {
    broadcastToUser(data.referrerId, 'referral:rewarded', data)
  })

  // === ADMIN EVENTS ===
  
  // Stats update
  socket.on('admin-stats-update', (data: any) => {
    broadcastToAdmins('admin:stats', data)
  })

  // User action by admin
  socket.on('admin-user-action', (data: {
    action: 'updated' | 'deleted'
    userId: string
    adminId: string
  }) => {
    if (data.action === 'deleted') {
      broadcastToUser(data.userId, 'account:deleted', { reason: 'Account deleted by admin' })
    } else {
      broadcastToUser(data.userId, 'account:updated', {})
    }
  })

  // === CHAT/NOTIFICATION EVENTS ===
  
  // Global announcement from admin
  socket.on('announcement', (data: {
    message: string
    type: 'info' | 'warning' | 'success' | 'error'
    from: string
    timestamp: string
  }) => {
    broadcastToAll('announcement', data)
  })

  // Personal notification
  socket.on('notification', (data: {
    userId: string
    title: string
    message: string
    type: string
    data?: any
  }) => {
    broadcastToUser(data.userId, 'notification', data)
  })

  // === BONUS EVENTS ===
  
  // Daily bonus claimed
  socket.on('bonus-claimed', (data: {
    userId: string
    pointsAwarded: number
    streakDays: number
  }) => {
    broadcastToUser(data.userId, 'bonus:claimed', data)
  })

  // === DISCONNECT ===
  
  socket.on('disconnect', () => {
    const user = connectedUsers.get(socket.id)
    
    if (user) {
      // Remove from connected users
      connectedUsers.delete(socket.id)
      
      // Remove from user socket map
      const socketSet = userSocketMap.get(user.userId)
      if (socketSet) {
        socketSet.delete(socket.id)
        if (socketSet.size === 0) {
          userSocketMap.delete(user.userId)
        }
      }
      
      console.log(`[WS] User disconnected: ${user.userId}`)
      
      // Broadcast online count update
      broadcastToAll('online-count', { count: getOnlineCount() })
    } else {
      console.log(`[WS] Client disconnected: ${socket.id}`)
    }
  })

  socket.on('error', (error) => {
    console.error(`[WS] Socket error (${socket.id}):`, error)
  })
})

// API endpoint for internal services to emit events
// This allows the Next.js API routes to send real-time updates
const PORT = 3003
httpServer.listen(PORT, () => {
  console.log(`[WS] SpinWin Real-time Service running on port ${PORT}`)
})

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('[WS] Received SIGTERM, shutting down...')
  httpServer.close(() => {
    console.log('[WS] Server closed')
    process.exit(0)
  })
})

process.on('SIGINT', () => {
  console.log('[WS] Received SIGINT, shutting down...')
  httpServer.close(() => {
    console.log('[WS] Server closed')
    process.exit(0)
  })
})

export { io, broadcastToAll, broadcastToUser, broadcastToAdmins }
